Hi!

It appears you have downloaded IldaViewer. How brave of you. Well, I'll assume this was entirely your own choice. 



Prerequisites:

-A JRE (Java Runtime Environment) that is sufficiently up to date
-A GPU which supports OpenGL (if not, try updating your video card drivers)

IldaViewer is pretty badly written so make sure you have enough RAM.



Important:

IldaViewer is intended to view/create/export laser art. You should be aware that lasers are dangerous when not used appropriately. The author of this program refuses any responsability for damage resulting in the use of artwork created with this program. 



How to run:

On Windows, double click IldaViewer.exe. Make sure you have Java installed.

If the program fails somehow, like you only get a black screen or nothing at all, try double clicking IldaViewer.bat. If that file isn't included in the install, create a new text file called IldaViewer.bat and with the following text:

@echo off
java -Djava.ext.dirs=lib -Djava.library.path=lib IldaViewer

Make sure it's in the same folder as IldaViewer.exe. Upon double clicking this file you should get a console window where hopefully no error messages appear. If error messages do appear however, you can send them to me. The most frequent error message is related to OpenGL not being available on your system. In this case you can upgrade your graphics card. Look at your graphic's card manufacturers website. Make sure you use the correct graphics card if you have multiple. Make sure you have done this before bugging me.


On OSX or Linux, you'll need to obtain a compiled version for your OS. If you can't find it, you'll need to compile it yourself, which isn't hard. See the How to compile.txt file.



How to use:

IldaViewer has a number of tabs, each with their own capabilities.

ILDAVIEWER TAB

The first tab is the main IldaViewer tab. Upon launching, you get a button to load an ilda file. Clicking this opens a file dialog where you can select an ilda file. You can also drag and drop ilda files into the program window (this is the only way to open multiple ilda files at once). If the import is successful, additional buttons appear. A button removes all frames from the program, another toggles the display of blanked lines. If the imported ilda file is a palette file (format 0 or 1), two buttons appear to choose another palette, if more than one is loaded into the program. If more than one frame is loaded, a player is visible where you can toggle automatic playback of files.

SEQUENCE EDITOR TAB

The second tab has a list of all loaded frames (if no frames are loaded, 