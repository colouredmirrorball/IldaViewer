import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import controlP5.*; 
import peasy.*; 
import sojamo.drop.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class IldaViewer extends PApplet {

/*
 * Hi there. If you read this, it means you are looking at the source code of IldaViewer! Welcome!
 * When I started creating this program, the intent was to create a framework to easily add features
 * and expand functionability. However, I'm not really an experienced programmer. It's very probable
 * that I didn't use the easiest or clearest way to do things. If you spot an improvement, let me know.
 * To help you contribute code, I added comments to most methods. If something isn't clear however,
 * I'd be glad to help you out.
 *
 * See README.txt for a license draft. You can modify and redistribute this program at will, as long 
 * as proper credit is given. Commercial use of this program is permitted, but you can't redistribute
 * and/or modify this program for commercial purposes.
 *
 * -colouredmirrorball
 *
 */


//Libraries: ControlP5 and PeasyCam
 

  //Requires manual install from http://www.sojamo.de/libraries/drop/


ControlP5 cp5;
PeasyCam cam;
SDrop drop;

ArrayList<FileWrapper> files; //All loaded files
ArrayList<Frame> frames;      //All loaded frames
ArrayList<Palette> palettes;  //All used palettes
ArrayList<String> status;     //Text displayed at the bottom; to clear, use status.clear(), to add, use status.add(String)

float depth = 600;            //Cf. width and height

String ildaViewerVersion = "1.1.0 Beta";

/*
 * Most fields and methods are grouped according to which tab they belong to, for clarity.
 * Each tab ("mode") has a class in their IDE tab, with a constructor and an update() method.
 * They are initiated when the user enters a specific tab in the program (in ControlP5's controlEvent() callback method)
 * A boolean checks if they are active. When active, their update() method is called in draw(). 
 * In the future, I hope to automate this, but for now you need to put them there manually.
 * You can put it anywhere in Draw if you want the contents of your tab to rotate with PeasyCam, otherwise you 
 * need to put it in between the cam.beginHUD() and cam.endHUD() methods. If necessary, you can have two update() methods
 * like update3D() and updateGUI() or so.
 * The constructor of the tab class is roughly similar to Processing's setup(), and update() to draw().
 *
 */

// Global and default tab fields:

int activeFrame;              //Which frame is currently displayed?
boolean loading = false;      //Don't display while loading a file
boolean autoplay = false;     //By default, don't start playing frames after each other

int lastTime = 0;             //Controls playback speed
int playbackSpeed = 12;

int activePalette = 0;        //Currently selected palette

boolean showBlanking = true;  //Should blanking points be displayed?
boolean showHeader = true;    //Should the header information be displayed?
//boolean proLaseristMode = false;
boolean laserboyMode = false; //Laserboy mode

int buttoncolour = color(unhex("FF02344D"));  //GUI
int textcolour = color(255, 255, 255);
int activecolour = color(unhex("FF016C9E"));
int mouseovercolour = color(unhex("FF00B4EA"));

int backgroundcolour = color(0, 0, 0);

PFont f8;
PFont f10;
PFont f12;
PFont f16;
PFont f20;
PFont f28;


public void setup()
{
  int size = 600;
  String renderer = OPENGL;
  String defpalette = "Random";
  String font = "";

  //Read the ini file:
  String setupargs[];
  setupargs = loadStrings("IldaViewer.ini");

  for (String setupstring : setupargs)
  {
    String[] q = splitTokens(setupstring);
    if (q.length >= 2)
    {
      if (q[0].equals("size") ) size = PApplet.parseInt(q[1]);
      if (q[0].equals("renderer") ) renderer = q[1];
      if (q[0].equals("font") ) 
      {
        font = "";
        String[] fnt = splitTokens(q[1], "_");
        font = fnt[0];
        if (fnt.length > 1)
        {
          for (int i = 1; i < fnt.length; i++)
          {
            font += " " + fnt[i];
          }
        }
      }
      if (q[0].equals("showinformation") ) showHeader = PApplet.parseBoolean(q[1]);
      if (q[0].equals("showblanking") ) showBlanking = PApplet.parseBoolean(q[1]);
      if (q[0].equals("defaultpalette") ) defpalette = q[1];
      try {
        if (q[0].equals("buttoncolour") ) buttoncolour = unhex(q[1]);
      }
      catch(Exception e) {
      }
      try {
        if (q[0].equals("textcolour") ) textcolour = unhex(q[1]);
      }
      catch(Exception e) {
      }
      try {
        if (q[0].equals("activecolour") ) activecolour = unhex(q[1]);
      }
      catch(Exception e) {
      }
      try {
        if (q[0].equals("mouseovercolour") ) mouseovercolour = unhex(q[1]);
      }
      catch(Exception e) {
      }
      try {
        if (q[0].equals("backgroundcolour") ) backgroundcolour = unhex(q[1]);
      }
      catch(Exception e) {
      }
    }
  }

  if (renderer.equals("OPENGL")) size(size, size, OPENGL);
  if (renderer.equals("P3D")) size(size, size, P3D);
  if (!renderer.equals("OPENGL") && !renderer.equals("P3D") ) size(size, size, OPENGL);

  f8 = createFont(font, 8, false);
  f10 = createFont(font, 10, false);
  f12 = createFont(font, 12, false);
  f16 = createFont(font, 16, false);
  f20 = createFont(font, 20, false);
  f28 = createFont(font, 28, false);
  textFont(f12);  


  colorMode(RGB);
  //frame.setResizable(true);    // Looks like PeasyCam causes trouble
  frame.setTitle("Ilda viewer " + ildaViewerVersion);
  frames = new ArrayList<Frame>();
  //files = new ArrayList<FileWrapper>();
  status = new ArrayList<String>();
  palettes = new ArrayList<Palette>();

  //Palette standardPalette = new Palette(defpalette);  //Build the default palette
  if (defpalette.equals("Random")) palettes.add(new Palette(defpalette));
  defpalette = "Palettes/" + defpalette;
  File imageFile = new File(defpalette);
  if (imageFile != null && !imageFile.getName().equals("Random"))
  {
    try {
      Palette standardPalette = new Palette(imageFile.getName());
      PImage img = loadImage(imageFile.getPath());
      for ( int i = 0; i < min (img.width, 256); i++)
      {
        standardPalette.addColour(img.get(i, 0));
      }
      palettes.add(standardPalette);
      status.add("Default palette loaded: " + imageFile.getName());
    }
    catch(Exception e)
    {
      status.add("Invalid palette file, check IldaViewer.ini");
      palettes.add(new Palette("Random"));
    }
  }




  cp5 = new ControlP5(this);
  cp5.setFont(f10);
  cp5.enableShortcuts(); //Enables keyboard shortcuts of ControlP5 controls
  cp5.setColorLabel(textcolour);
  cp5.setColorBackground(buttoncolour);
  cp5.setColorActive(activecolour);
  cp5.setColorForeground(mouseovercolour);

  cam = new PeasyCam(this, width/2, height/2, depth/2, depth*2);

  drop = new SDrop(this);
  sedl = new SeqeditorDropListener();
  mdl = new MainDropListener();
  bdl = new BufferDropListener();

  drop.addDropListener(sedl);
  drop.addDropListener(mdl);
  drop.addDropListener(bdl);

  smooth();

  initializeControlP5();    // All ControlP5 elements are initiated in this method, which has been transported to the Processing IDE tab "ControlP5" for convenience

  cp5.setAutoDraw(false); //Necessary for use with PeasyCam

  lastTime = millis();    // For autoplay

  StringList hints = new StringList();    //Display some hints on startup.
  hints.append("You can change the window size in the IldaViewer.ini file in the data folder.");
  hints.append("Always look on the bright side of life (without burning you retinas).");
  hints.append("You can move GUI elements around when holding alt should they ever be in your way.");
  hints.append("Drag Ilda files to the program to load them in. You can select more than one, or a whole folder.");
  hints.append("In the sequence editor, the main column contains the frames available in the whole program. Frames in the buffer are only available in the sequence editor.");
  hints.append("Use the right mouse button in the sequence editor to multiselect frames.");
  hints.append("Use shift + right mouse button in the sequence editor to select a sequence of frames.");
  hints.append("You can drag and drop Ilda files to the main or buffer column in the sequence editor from a file browser.");
  hints.append("Use the buffer in the sequence editor for temporary storage of frames.");
  hints.append("Select which editing options you need in the Control Panels menu of the frame editor to tidy up the workspace.");
  hints.append("You can import a raster image in the frame editor to manually trace and recolour ilda frames.");
  hints.append("Hold control in the Frame Editor to rotate the view.");
  hints.append("Create a 256x1 image in an external image editor to easily generate and edit palettes.");
  hints.append("You can import all raster image files as palettes (jpg, png, bmp)");
  hints.append("Drag an image to the palette editor to load in a new palette.");
  hints.append("Most Ilda files use the 64Ilda palette. You can set it as default in the ini file.");
  hints.append("Right clicking on an Input node in Oscillabstract resets the value.");
  hints.append("Use the middle mouse button or control key to drag the Oscillabstract workspace around.");
  hints.append("Drag and drop an ilda file or palette image from a file browser to the Oscillabstract workspace to create a Source or Palette element.");
  hints.append("Don't like a feature or have a suggestion? Leave feedback!");

  status.add("Tip: " + hints.get(min((int) random(hints.size()), hints.size()-1)));
  status.add("Initialized");
  println("Ilda Viewer version " + ildaViewerVersion + " booted in " + millis() + " ms.");
}

public void draw()
{
  background(backgroundcolour);



  if (activeFrame >= 0 && activeFrame < frames.size() && !loading)  //Draw the active frame when not loading in a file
  {
    if (cp5.getWindow().getCurrentTab().getName().equals("default") ) frames.get(activeFrame).drawFrame(showBlanking);    //Only draw in the Default tab

    //If the current frame is ilda V0 or V1, display the Palette buttons:
    if ((frames.get(activeFrame).palette) )
    {
      cp5.getController("previousPalette").setVisible(true);
      cp5.getController("nextPalette").setVisible(true);
    } else
    {
      cp5.getController("previousPalette").setVisible(false);
      cp5.getController("nextPalette").setVisible(false);
    }
  }

  // Modes update3D() methods
  // The cam should also be activated in the mousepressed() method for each tab!
  if (sequenceditor) seqeditor.update3D();
  if (seqcreator) sequenceCreator.update3D();

  hint(DISABLE_DEPTH_TEST); //Necessary so text and controls don't rotate around as well
  cam.beginHUD();



  if (loading) drawLoadingScreen();

  // Modes update() methods:
  if (sequenceditor) seqeditor.update();
  if (frameditor) frameEditor.update();
  if (paletteEditor) paleditor.update();
  if (seqcreator) sequenceCreator.update();
  if (exporting) exporter.update();
  displayStatus();
  cp5.draw();
  cam.endHUD();
  hint(ENABLE_DEPTH_TEST);

  if (autoplay) //Plays and loops all frames in order
  {
    if (playbackSpeed > 0)
    {
      if (millis() - lastTime > 1000/playbackSpeed)
      {
        activeFrame++;
        if (activeFrame >= frames.size() ) activeFrame = 0;
        lastTime = millis();
      }
    }
    if (playbackSpeed < 0)
    {
      if (millis() - lastTime > (-1000/playbackSpeed))
      {
        activeFrame--;
        if (activeFrame < 0 ) activeFrame = frames.size()-1;
        lastTime = millis();
      }
    }
  }
}

public void displayStatus() //Displays some information, such as the strings in the status arraylist, fps, file header etc
{
  fill(255);
  textAlign(LEFT);
  textFont(f16);
  for (int i = 0; i < status.size (); i++)
  {
    if (laserboyMode) fill(color(PApplet.parseInt((sin(PApplet.parseFloat(i)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(i)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(i)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255))); 
    else fill(255);
    if (textWidth(status.get(i)) > width-10) 
    {
      String[] brokenText = splitTokens(status.get(i));
      String str1 = "";
      String str2 = "";
      int k = 0;
      for (int j = 0; j < brokenText.length; j++)
      {      
        if (textWidth(str1 + brokenText[j] + " ") > width-10)
        {
          k = j;
          j = brokenText.length;
        } else str1 += brokenText[j] + " ";
      }
      status.set(i, str1);
      for (int j = k; j < brokenText.length; j++)
      {      
        str2 += brokenText[j] + " ";
      }
      status.add(i+1, str2);
    }
    text(status.get(i), 10, height-20*status.size()+20*i);
  }
  if (!showHeader) return;
  textAlign(RIGHT);
  if (laserboyMode) fill(color(PApplet.parseInt((sin(PApplet.parseFloat(1)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(1)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(1)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255))); 
  else fill(255);
  text("FPS: " + PApplet.parseInt(frameRate), width-10, 135);
  if (laserboyMode) fill(color(PApplet.parseInt((sin(PApplet.parseFloat(2)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(2)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(2)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255))); 
  else fill(255);
  text("Total frames: " + (frames.size()), width-10, 160);
  if ( activeFrame >= 0 && activeFrame < frames.size() && !loading)
  {
    if (laserboyMode) fill(color(PApplet.parseInt((sin(PApplet.parseFloat(3)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(3)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(3)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255))); 
    else fill(255);
    text("Point count: " + frames.get(activeFrame).getPointCount(), width-10, 185);
    displayHeader(frames.get(activeFrame).hoofding);
  }
}

public void displayHeader(StringList hdr)
{

  textAlign(RIGHT);
  text("Frame information: ", width-10, 220);
  for (int i = 0; i < hdr.size (); i++)
  {
    if (laserboyMode) fill(color(PApplet.parseInt((sin(PApplet.parseFloat(i)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(i)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(i)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255))); 
    else fill(255);
    text(hdr.get(i), width-10, 240+20*i);
  }
}

public void mousePressed()
{
  //Don't interact with PeasyCam while using the GUI
  if (cp5.getWindow().getMouseOverList().isEmpty() && (cp5.getWindow().getCurrentTab().getName().equals("default") || cp5.getWindow().getCurrentTab().getName().equals("seqeditor") ))
  {
    cam.setActive(true);
  } else
  {
    cam.setActive(false);
  }

  // In the Palette Editor tab, check if you clicked on a colour
  if (paletteEditor) paleditor.editPalette(mouseX, mouseY);

  // In the Sequence Creator tab, interact with the non-ControlP5 GUI elements
  if (seqcreator) sequenceCreator.mousePressed();
}

public void keyPressed()
{
  /*
  //for PL wiki
   if(key == 'p')
   {
   int i = 0;
   for(PaletteColour c : getActivePalette().colours)
   {
   println("|-");
   println("| " + (i++) + " || " + c.red + " || " + c.green + " || " + c.blue);
   }
   }
   */

  /*
  //for DJDan's javascript based ilda reader
   if (key == 'p')
   {
   for (PaletteColour c : getActivePalette ().colours)
   {
   println("'#" + hex(c.red).charAt(6) + hex(c.green).charAt(6) + hex(c.blue).charAt(6)+"'");
   }
   }
   */

  /*
  //For the Processing library
   if (key == 'p')
   {
   for (PaletteColour c : getActivePalette ().colours)
   {
   println("addColour(" + c.getRed() + "," + c.getGreen() + "," + c.getBlue() + ");");
   }
   }
   */

  if (key == 's')
  {
    if (frameditor && frameEditor != null)
    {
      EditingFrame frame = new EditingFrame();
      for (int i = 0; i < 500; i++)
      {
        frame.points.add( new EditingPoint(new Point(width*0.5f*(1+0.75f*sin(PApplet.parseFloat(i)*5*PI/500)*PApplet.parseFloat(i)/500), height*0.5f*(1+0.75f*cos(PApplet.parseFloat(i)*5*PI/500)*PApplet.parseFloat(i)/500), 0, 255, 255, 255, false)));
      }
      frameEditor.frame = frame;
    }
  }

  if (key == 'c')
  {
    if (frameditor && frameEditor != null)
    {
      if (frameEditor.frame == null) frameEditor.frame = new EditingFrame();
      EditingFrame frame = frameEditor.frame;
      for (int i = 0; i < 50; i++)
      {
        frame.points.add( new EditingPoint(new Point(width*0.5f*(0.15f*sin(PApplet.parseFloat(i)*2*PI/50))+mouseX, height*0.5f*(0.15f*cos(PApplet.parseFloat(i)*2*PI/50))+mouseY, 0, 255, 255, 255, false)));
      }
      println("circle at " + mouseX + " " + mouseY);
    }
  }
}



/*
 * All ControlP5 actions get forwarded to this callback method.
 * Some elements don't have a specific callback method, so we have to deal with them here.
 * One such element is the Tab, so initiating a tab or mode class happens here (the "setup" of each tab).
 * 
 *
 */

public void controlEvent(ControlEvent theControlEvent) {
  if (theControlEvent.isTab()) {

    //Hide header outside the default tab:
    if (theControlEvent.getTab().getName().equals("default") )
    {
      enterDefaultTab();
    } else
    {
      showHeader = false;
    }

    // Observe the syntax and add your own!
    // When going to a new tab, its corresponding mode boolean should be set to true.
    // When exiting, it should be set to false.

    //Sequence editor tab
    if (theControlEvent.getTab().getName().equals("seqeditor") )
    {
      beginSeqEditor();
    }

    //Exiting Sequence editor tab 
    if (sequenceditor && !theControlEvent.getTab().getName().equals("seqeditor") )
    {
      exitSeqEditor();
    }

    //Frame editor tab
    if (theControlEvent.getTab().getName().equals("framed"))
    {
      beginFrameEditor();
    }

    //Exiting Frame editor tab
    if (frameditor && !theControlEvent.getTab().getName().equals("framed"))
    {
      exitFrameEditor();
    }


    //Palette tab
    if (theControlEvent.getTab().getName().equals("palettes") )
    {
      beginPalettes();
    }

    //Exiting Palette tab 
    if (paletteEditor && !theControlEvent.getTab().getName().equals("palettes") )
    {
      exitPalettes();
    }

    //Sequence Creator tab
    if (theControlEvent.getTab().getName().equals("deluxe") )
    {
      sequenceCreator();
    }

    //Exiting Sequence Creator tab
    if (seqcreator && !theControlEvent.getTab().getName().equals("deluxe") )
    {
      exitSequenceCreator();
    }


    //Sequence creator tab: split into modes
    if (theControlEvent.isFrom(seqMode))
    {
    }


    //Exporter tab
    if (theControlEvent.getTab().getName().equals("export") )
    {
      beginExporter();
    }

    //Exiting exporter tab
    if (exporting && !theControlEvent.getTab().getName().equals("export") )
    {
      endExporter();
    }
  }

  //Sequence editor copy mode
  if (theControlEvent.isFrom(copyBehaviour))
  {
    if (copyBehaviour.getValue() == 3) copiedElements.setVisible(true);
    else copiedElements.setVisible(false);
  }

  //Frame editor visible controls
  if (theControlEvent.isFrom(controlsVisible))
  {
    setFrameEditorControls();
  }

  //Palette picker
  if (theControlEvent.isGroup() && theControlEvent.name().equals("myList")) {
    int index = (int)theControlEvent.group().value();
    paleditor.setActivePalette(index);
    activePalette = index;
  }

  //Palette colour picker
  if (theControlEvent.isFrom(cp)) {
    int r = PApplet.parseInt(theControlEvent.getArrayValue(0));
    int g = PApplet.parseInt(theControlEvent.getArrayValue(1));
    int b = PApplet.parseInt(theControlEvent.getArrayValue(2));
    int a = PApplet.parseInt(theControlEvent.getArrayValue(3));
    int col = color(r, g, b, a);
    if (!paleditor.dontChangeColourMoron)
      paleditor.setActiveColour(col);
  }

  //Sequence creator mode selector
  if (theControlEvent.isFrom(seqMode))
  {
    initiateSeqCreatorMode((int) seqMode.getValue());
    //seqMode.setOpen(!seqMode.isOpen());
    seqMode.setMouseOver(false);
  }

  //Export ilda file version
  if (theControlEvent.isFrom(r)) {
    exportVersion = PApplet.parseInt(theControlEvent.getValue());
    if (exportVersion == 0 || exportVersion == 1)
    {
      cp5.getController("includePalette").setVisible(true);
      if (includePalette)
      {
        cp5.getController("nextPaletteExp").setVisible(true);
        cp5.getController("previousPaletteExp").setVisible(true);
        cp5.getController("findBestColour").setVisible(true);
      } else
      {
        cp5.getController("nextPaletteExp").setVisible(false);
        cp5.getController("previousPaletteExp").setVisible(false);
        cp5.getController("findBestColour").setVisible(false);
      }
    } else
    {
      cp5.getController("includePalette").setVisible(false);
      cp5.getController("nextPaletteExp").setVisible(false);
      cp5.getController("previousPaletteExp").setVisible(false);
      cp5.getController("findBestColour").setVisible(false);
    }
  }
}

public void enterDefaultTab()
{
  showHeader = PApplet.parseBoolean(PApplet.parseInt(cp5.getController("showHeader").getValue()));
  cp5.getController("showBlanking").setValue(PApplet.parseFloat(PApplet.parseInt(showBlanking)));
  if (frames.size() > 1) cp5.getGroup("framePlayer").setVisible(true);
  if (frames.size() > 0)
  {
    cp5.getController("clearFrames").setVisible(true);
    cp5.getController("showBlanking").setVisible(true);
  }
}

// Convenience method to get the currently active palette

public Palette getActivePalette()
{
  if (activePalette >= 0  && activePalette < palettes.size())
  {
    return palettes.get(activePalette);
  } else 
  {
    println("Warning: nonexisting palette selected. (index: " + activePalette + ")" );
    return null;
  }
}


//      === DEFAULT TAB CP5 CALLBACKS ===

public void previousFrame() //manually skip to previous frame
{
  if (activeFrame <= 0)
  {
    activeFrame = frames.size()-1;
    status.clear();
    status.add("Frame: " + (activeFrame+1));
  } else 
  {
    activeFrame--;
    status.clear();
    status.add("Frame: " + (activeFrame+1));
  }
}

public void nextFrame() //manually skip to next frame
{
  if (activeFrame >= frames.size()-1 )
  {
    activeFrame = 0;
    status.clear();
    status.add("Frame: " + (activeFrame+1));
  } else
  {
    activeFrame++;
    status.clear();
    status.add("Frame: " + (activeFrame+1));
  }
}

public void firstFrame()
{
  activeFrame = 0;
  status.clear();
  status.add("Frame: " + (activeFrame+1));
}

public void lastFrame()
{
  if (! frames.isEmpty())
  {
    activeFrame = frames.size()-1;
  } else
  {
    activeFrame = 0;
  }
  status.clear();
  status.add("Frame: " + (activeFrame+1));
}

public void autoPlay(boolean autoPLay)
{
  autoplay = !autoplay;
}

public void previousPalette() //manually set previous palette active
{
  if (activePalette <= 0)
  {
    activePalette = palettes.size()-1;
  } else 
  {
    activePalette--;
  }
  status.clear();
  status.add("Palette: " + activePalette + " - " + palettes.get(activePalette).name);

  if (activeFrame >= 0 && activeFrame < frames.size())
  {
    frames.get(activeFrame).palettePaint(palettes.get(activePalette));
  }
}

public void nextPalette() //manually set next palette active
{
  if (activePalette >= palettes.size()-1)
  {
    activePalette = 0;
  } else
  {
    activePalette++;
  }

  status.clear();
  status.add("Palette: " + activePalette + " - " + palettes.get(activePalette).name);

  if (activeFrame >= 0 && activeFrame < frames.size())
  {
    frames.get(activeFrame).palettePaint(palettes.get(activePalette));
  }
}



public void clearFrames()    //Clear all frames and set some controls invisible
{
  frames.clear();
  cp5.getController("clearFrames").setVisible(false);
  cp5.getController("clearFrames").setMouseOver(false);

  cp5.getGroup("framePlayer").setVisible(false);
  cp5.getController("previousPalette").setVisible(false);
  cp5.getController("nextPalette").setVisible(false);
  cp5.getController("showBlanking").setVisible(false);
  activeFrame = 0;

  System.gc();    // Try to get the frames out of your system
  status.clear();
  status.add("All frames cleared.");
}


//Gets called when the load ilda file button is pressed:
public void LoadIldaFile()
{
  //loading = true;    //It's possible frame displaying is in a separate thread, and you can't load and display at the same time
  thread("getIldaFile");
}

public void getIldaFile()
{
  selectInput("Load an Ilda file", "selFile");
}

//Gets called when an ilda file is selected in the previous method
public void selFile(File selection) {

  //Check if file is valid
  if (selection == null) {
    loading = false;
    status.clear();
    status.add("Window was closed or the user hit cancel.");
    return;
  } else {
    //Check if file exists
    if (!selection.exists())
    {
      loading = false;
      status.clear();
      status.add("Error when trying to read file " + selection.getAbsolutePath());
      status.add("File does not exist.");
      return;
    }
    status.clear();
    status.add("Loading file:");
    status.add(selection.getAbsolutePath());
    //File should be all good now, load it in!
    loading = true;
    loadIldaFile(selection.getAbsolutePath());
  }
}

//Load in the file
public void loadIldaFile(String path)
{
  loading = true;    //It's possible frame displaying is in a separate thread, and you can't load and display at the same time
  FileWrapper file = new FileWrapper(path);  //Create a new FileWrapper, this constructor automatically reads the file and adds the frames to the current framelist
  //files.add(file);  //For now, don't store the file
  loading = false;
  if (frames.size() > 1) cp5.getGroup("framePlayer").setVisible(true);
  cp5.getController("clearFrames").setVisible(true);
  cp5.getController("showBlanking").setVisible(true);
}

public void drawLoadingScreen()
{
  if (laserboyMode) fill(color(PApplet.parseInt((sin(PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin(PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255)));
  else fill(255);
  textFont(f20);
  text("Loading", width/2, height/2);
}

public void laserboyMode(boolean lbMode)
{
  laserboyMode = lbMode;
  if (lbMode)
  {
    int i = 0;
    for (ControllerInterface conrl : cp5.getAll ())
    {
      if (conrl.getName() != null )
      {
        //Got some weird errors. Looks like try and catch actually works
        try
        {
          conrl.setColorBackground(color(PApplet.parseInt((sin(PApplet.parseFloat(++i)/30+PI/2)*0.5f+0.5f)*255), PApplet.parseInt((cos(PApplet.parseFloat(i)/15+PI)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(i)/30+3*PI/2)*0.5f+0.5f)*255)));
          conrl.setColorLabel(color(PApplet.parseInt((sin(PApplet.parseFloat(++i)/30+PI/2)*0.5f+0.5f)*255), PApplet.parseInt((cos(PApplet.parseFloat(i)/15+PI+PI)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(i)/30+3*PI/2-PI)*0.5f+0.5f)*255)));
          conrl.setColorActive(color(PApplet.parseInt((sin(PApplet.parseFloat(++i)/30+PI/2)*0.5f+0.5f)*255), PApplet.parseInt((cos(PApplet.parseFloat(i)/15+PI)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(i)/30+3*PI/2)*0.5f+0.5f)*255)));
          conrl.setColorForeground(color(PApplet.parseInt((sin(PApplet.parseFloat(++i)/30+PI/2+PI)*0.5f+0.5f)*255), PApplet.parseInt((cos(PApplet.parseFloat(i)/15+PI+PI)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(i)/30+3*PI/2+PI)*0.5f+0.5f)*255)));
        }
        catch(Exception e)
        {
        }
      }
    }

    status.clear();
    status.add("Embrace the rainbow!");
  }

  //else, for, if, try? What's left, while?
  else
  {
    for (ControllerInterface conrl : cp5.getAll ())
    {
      if (conrl.getName() != null )
      {
        try
        {
          conrl.setColorBackground(buttoncolour);
          conrl.setColorLabel(textcolour);
          conrl.setColorActive(activecolour);
          conrl.setColorForeground(mouseovercolour);
        }
        catch(Exception e)
        {
        }
      }
    }
  }

  cp5.getController("playbackSpeed").getCaptionLabel().setVisible(false);
  cp5.getController("playbackSpeed").getValueLabel().setVisible(true);
}

/*
 * Drop support for Ilda files in the main tab:
 */

public void dropEvent(DropEvent evt)
{
  if (cp5.getWindow().getCurrentTab().getName().equals("default"))
  {
    if (evt.isFile())
    {
      File f = evt.file();

      if (f.isDirectory())
      {
        status.clear();
        //Load in all the files it can find.
        for (File file : f.listFiles ())
        {
          if (file != null) loadIldaFile(file.getAbsolutePath());
        }
        loading = false;
      }
      if (f.isFile())
      {
        status.clear();
        if (f != null) loadIldaFile(f.getAbsolutePath());
        loading = false;
      }
    }
    if (frames.size() > 1) cp5.getGroup("framePlayer").setVisible(true);
    else cp5.getGroup("framePlayer").setVisible(false);
  }
  if (cp5.getWindow().getCurrentTab().getName().equals("palettes") && evt.isImage())
  {
    File f = evt.file();
    paletteSelected(f);
  }
  if (cp5.getWindow().getCurrentTab().getName().equals("deluxe") && creatorMode == 1)
  {
    if (evt.isImage())
    {
      status.clear();
      File f = evt.file();
      if (paleditor == null) paleditor = new PalEditor();
      paletteSelected(f);
      Oscipalette p = new Oscipalette(mouseX, mouseY);
      sequenceCreator.osc.elements.add(p);

      return;
    }
    File f = evt.file();

    if (f.isDirectory())
    {
      status.clear();
      //Load in all the files it can find.
      for (File file : f.listFiles ())
      {
        if (file != null) 
        {
          FileWrapper fw = new FileWrapper(file.getAbsolutePath());
          Oscisource s = new Oscisource(mouseX, mouseY);
          s.firstFrame = frames.size()-1;
          s.sources = fw.getFramesFromBytes();
          s.lastFrame = frames.size()-1;
          sequenceCreator.osc.elements.add(s);
        }
      }
      loading = false;
    }
    if (f.isFile())
    {
      status.clear();
      if (f != null) 
      {
        FileWrapper fw = new FileWrapper(f.getAbsolutePath());
        Oscisource s = new Oscisource(mouseX, mouseY);
        s.firstFrame = frames.size()-1;
        s.sources = fw.getFramesFromBytes();
        s.lastFrame = frames.size()-1;
        sequenceCreator.osc.elements.add(s);
      }
      loading = false;
    }
  }
}


/*
 * Pro laserist mode no longer supported.
 * Turns out labels might be useful sometimes.
 * http://www.photonlexicon.com/forums/showthread.php/20949-Z-5-Analog-Abstract-Generator?p=272922#post272922
 *
 */

/*
void proLaseristMode(boolean proMode)
 {
 proLaseristMode = proMode;
 if (proMode)
 {
 for (ControllerInterface conrl : cp5.getAll())
 {
 if (conrl.getName() != null )
 {
 //Got some weird errors. Looks like try and catch actually works
 try
 {
 String thename = conrl.getName();
 
 Label theLabel = cp5.getController(thename).getCaptionLabel();
 if (theLabel != null) theLabel.setVisible(false);
 }
 catch(Exception e)
 {
 }
 }
 }
 
 status.clear();
 status.add("Level up!");
 }
 
 //else, for, if, try? What's left, while?
 else
 {
 for (ControllerInterface conrl : cp5.getAll())
 {
 if (conrl.getName() != null )
 {
 try
 {
 String thename = conrl.getName();
 if (!thename.equals("picker-red") && !thename.equals("picker-green") && !thename.equals("picker-blue") && !thename.equals("picker-alpha"))
 {
 Label theLabel = cp5.getController(thename).getCaptionLabel();
 if (theLabel != null) theLabel.setVisible(true);
 }
 }
 catch(Exception e)
 {
 }
 }
 }
 }
 
 cp5.getController("playbackSpeed").getCaptionLabel().setVisible(false);
 cp5.getController("playbackSpeed").getValueLabel().setVisible(true);
 }
 
 */
/*
 * In this method all GUI elements are added.
 * For more information, see the ControlP5 documentary.
 * Callback methods for elements who have them are placed in the main tab.
 *
 * In short, you can add elements (buttons, toggles, lists, ...) to ControlP5. 
 * Each element has a name in the form of a String. In some cases, this can correspond
 * to a variable. For example, if you add a Toggle called "theToggle", and you have a
 * boolean theToggle in the program, the boolean will automatically get the value of the
 * Toggle that is being displayed on screen. (Reverse is not true, when some program element
 * changes the value of the boolean theToggle, the Toggle GUI button doesn't automatically
 * update. You need to manually set this by doing something like cp5.getController("theToggle").setValue(boolean(int(theToggle))); )
 * 
 * All GUI elements are grouped in Tabs. 
 */




public void initializeControlP5()
{

  //Mouseover help delay:
  cp5.getTooltip().setDelay(500);

  //Add all ControlP5 elements:

  //      === TAB: DEFAULT ===

  cp5.getTab("default")       //No need to initiate this tab
      .activateEvent(true)
      .setLabel("IldaViewer")
        .getCaptionLabel().setFont(f10);


  cp5.addButton("LoadIldaFile")
    .setPosition(10, 25)
      .moveTo("default")
        .setSize(100, 25)
          .setMoveable(true)
            .setLabel("Load an Ilda file")
              .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.getTooltip().register("LoadIldaFile", "Load an Ilda file and add it at the end of the existing frame list").getLabel().toUpperCase(false);

  cp5.addButton("clearFrames")
    .setPosition(width-130, 25)
      .setSize(120, 25)
        .moveTo("default")
          .setVisible(false)
            .setMoveable(true)
              .setLabel("Clear all frames")
                .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.getTooltip().register("clearFrames", "Remove all frames").getLabel().toUpperCase(false);

  Group framePlayer = cp5.addGroup("framePlayer") //A group, for convenience
    .setPosition(width-240, 35)
      .setVisible(false)
        .moveTo("default")
          ;

  PImage[] previmgs = {
    loadImage("Images/previousframedefault.png"), loadImage("Images/previousframeactive.png"), loadImage("Images/previousframemouseover.png")
    };

    cp5.addBang("previousFrame")
      .setPosition(20, 5)
        .setImages(previmgs)
          .updateSize()
            .setTriggerEvent(Bang.RELEASE)
              .setLabel("<")
                .setGroup(framePlayer)
                  ;

  PImage[] nextimgs = {
    loadImage("Images/nextframedefault.png"), loadImage("Images/nextframeactive.png"), loadImage("Images/nextframemouseover.png")
    };

    cp5.addBang("nextFrame")
      .setPosition(60, 5)
        .setImages(nextimgs)
          .updateSize()
            .setGroup(framePlayer)
              .setTriggerEvent(Bang.RELEASE)
                .setLabel(">")
                  ;

  PImage[] firstimgs = {
    loadImage("Images/firstframedefault.png"), loadImage("Images/firstframeactive.png"), loadImage("Images/firstframemouseover.png")
    };

    cp5.addBang("firstFrame")
      .setPosition(0, 5)
        .setImages(firstimgs)
          .updateSize()
            .setGroup(framePlayer)
              .setTriggerEvent(Bang.RELEASE)
                .setLabel("<<")
                  ;

  PImage[] lastimgs = {
    loadImage("Images/lastframedefault.png"), loadImage("Images/lastframeactive.png"), loadImage("Images/lastframemouseover.png")
    };

    cp5.addBang("lastFrame")
      .setPosition(80, 5)
        .setImages(lastimgs)
          .updateSize()
            .setGroup(framePlayer)
              .setTriggerEvent(Bang.RELEASE)
                .setLabel(">>")
                  ;

  PImage[] playimgs = {
    loadImage("Images/playdefault.png"), loadImage("Images/playmouseover.png"), loadImage("Images/playactive.png")
    };

    cp5.addButton("autoPlay")      //This is supposed to be a Toggle, but images won't work for some reason
        .setPosition(40, 5)
        .setImages(playimgs)
          .setSwitch(true)
            .setGroup(framePlayer)
              .updateSize()
                .setLabel("Autoplay");



  cp5.addSlider("playbackSpeed")    //There is no callback method, as playback speed is stored in the variable playbackSpeed
    .setPosition(00, 30)
      .setSize(100, 20)
        .setRange(-60, 60)
          .setValue(12)
            .setGroup(framePlayer)
              .setValueLabel("Playback speed")
                ;

  cp5.getController("playbackSpeed").getCaptionLabel().setVisible(false);


  cp5.addBang("previousPalette")
    .setPosition(10, 60)
      .setSize(30, 30)
        .moveTo("default")
          .setTriggerEvent(Bang.RELEASE)
            .setLabel("< pal")
              .setVisible(false)
                ;

  cp5.getTooltip().register("previousPalette", "Recolour frame with previous palette in the palette list").getLabel().toUpperCase(false);

  cp5.addBang("nextPalette")
    .setPosition(42, 60)
      .setSize(30, 30)
        .moveTo("default")
          .setTriggerEvent(Bang.RELEASE)
            .setLabel("ette >")
              .setVisible(false)
                ;

  cp5.getTooltip().register("nextPalette", "Recolour frame with next palette in the palette list").getLabel().toUpperCase(false);

  cp5.addToggle("showBlanking")
    .setPosition(width-130, 60)
      .setSize(120, 25)
        .moveTo("default")
          .setVisible(false)
            .setMoveable(true)
              .setValueLabel("Show blanking lines")
                .setCaptionLabel("Show blanking")
                  .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.getTooltip().register("showBlanking", "Toggle the display of blanked lines").getLabel().toUpperCase(false);

  cp5.addToggle("showHeader")
    .setPosition(width-130, 106)
      .setSize(120, 12)
        .moveTo("default")
          .setVisible(true)
            .setMoveable(true)
              .setValueLabel("Show information")
                .setCaptionLabel("Show information")
                  .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.getTooltip().register("showHeader", "Show additional information about the program and frame").getLabel().toUpperCase(false);

  cp5.addToggle("laserboyMode")
    .setPosition(width-130, 90)
      .setSize(120, 12)
        .moveTo("default")
          .setValue(laserboyMode)
            .setVisible(true)
              .setMoveable(true)
                .setValueLabel("Show information")
                  .setCaptionLabel("Laserboy mode")
                    .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.getTooltip().register("laserboyMode", "And unicorns. Rainbows and unicorns.").getLabel().toUpperCase(false);

  //      === TAB: SEQUENCE EDITOR ===

  cp5.addTab("seqeditor")
    .activateEvent(true)
      .setLabel("Sequence Editor")
        .setId(1);



  cp5.addBang("insertFrame")
    .setPosition(width-300, 30)
      .setSize(85, 40)
        .moveTo("seqeditor")
          .setVisible(true)          
            .setMoveable(true)
              .setLabel("New frame")
                .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.addTextfield("nrOfInsertedFrames")
    .setPosition(width-300, 75)
      .setSize(85, 20)
        .setFocus(true)
          .setText(nrOfInsertedFrames)
            .moveTo("seqeditor")
              .setVisible(true)
                .setMoveable(true)
                  .setLabel("Amount")
                    .setAutoClear(false);


  cp5.addButton("deleteFrame")
    .setPosition(width-300, 125)
      .setSize(85, 85)
        .moveTo("seqeditor")
          .setVisible(true)
            .setMoveable(true)
              .setLabel("Delete frame")
                .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.addButton("editorLoadIldaFile")
    .setPosition(width-300, 335)
      .moveTo("seqeditor")
        .setSize(85, 40)
          .setMoveable(true)
            .setLabel("Load Ilda file")
              .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.addButton("sfx")
    .setPosition(width-300, 230)
      .moveTo("seqeditor")
        .setSize(85, 85)
          .setMoveable(true)
            .setLabel("SFX")
              .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.addButton("editorClearFrames")
    .setPosition(width-300, 440)
      .setSize(85, 40)
        .moveTo("seqeditor")
          .setVisible(true)
            .setMoveable(true)
              .setLabel("Clear")
                .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.addButton("editorClearBuffer")
    .setPosition(width-300, 510)
      .setSize(85, 40)
        .moveTo("seqeditor")
          .setVisible(true)
            .setMoveable(true)
              .setLabel("Clear")
                .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.addButton("editorFitPalette")
    .setPosition(width-190, 30)
      .setSize(120, 40)
        .moveTo("seqeditor")
          .setVisible(true)
            .setMoveable(true)
              .setLabel("Fit RGB to palette")
                .getCaptionLabel().alignY(CENTER).alignX(CENTER);


  copyBehaviour = cp5.addRadioButton("copyBehaviour")
    .setPosition(width-190, 85)
      .moveTo("seqeditor")
        .setSize(25, 25)
          .setItemsPerRow(1)
            .setSpacingColumn(5)
              .setSpacingRow(4)
                .setNoneSelectedAllowed(false)
                  .addItem("Insert", 0)
                    .addItem("Overwrite", 1)
                      .addItem("Merge", 2)
                        .addItem("Copy frame data", 3)
                          .activate(0);


  copiedElements = cp5.addCheckBox("copiedElements")
    .setPosition(width-190, 210)
      .setSize(20, 20)
        .moveTo("seqeditor")
          .setVisible(false)
            .setItemsPerRow(2)
              .setSpacingColumn(75)
                .setSpacingRow(4)
                  .addItem("Frame header", 1)
                    .addItem("Point number", 1)
                      .addItem("X", 1)
                        .addItem("R", 1)
                          .addItem("Y", 1)
                            .addItem("G", 1)
                              .addItem("Z", 1)
                                .addItem("B", 1)
                                  .addItem("Blanking", 1)
                                    .addItem("Palette index", 1);

  cp5.addButton("editorSelectFrames")
    .setPosition(width-200, 440)
      .setSize(85, 40)
        .moveTo("seqeditor")
          .setVisible(true)
            .setMoveable(true)
              .setLabel("Select all")
                .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.addButton("editorSelectBuffer")
    .setPosition(width-200, 510)
      .setSize(85, 40)
        .moveTo("seqeditor")
          .setVisible(true)
            .setMoveable(true)
              .setLabel("Select all")
                .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.addButton("editorDeselectFrames")
    .setPosition(width-100, 440)
      .setSize(85, 40)
        .moveTo("seqeditor")
          .setVisible(true)
            .setMoveable(true)
              .setLabel("Deselect all")
                .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.addButton("editorDeselectBuffer")
    .setPosition(width-100, 510)
      .setSize(85, 40)
        .moveTo("seqeditor")
          .setVisible(true)
            .setMoveable(true)
              .setLabel("Deselect all")
                .getCaptionLabel().alignY(CENTER).alignX(CENTER);


  /*
  cp5.addToggle("editHeader")
   .setPosition(width-90, 88)
   .setSize(85, 10)
   .moveTo("seqeditor")
   .setVisible(true)
   .setMoveable(true)
   .setValueLabel("Edit")
   .setCaptionLabel("Edit")
   .getCaptionLabel().alignY(CENTER).alignX(CENTER);
   */

  //      === TAB: FRAME EDITOR ===


  cp5.addTab("framed")
    .activateEvent(true)
      .setLabel("Frame Editor")
        .setId(2);

  Group visibleControls = cp5.addGroup("visiblecontrols")
    .setPosition(10, 35)
      .setSize(120, 20)
        .setVisible(true)
          .setLabel("Control panels")
            .moveTo("framed");

  //This checkbox determines which GUI groups are visible
  //You need to program this in the setFrameEditorControls() method in the FrameEditor tab!

  ctrlsVis = new int[6];  //Total number of control groups

  controlsVisible = cp5.addCheckBox("visibleControls")
    .setPosition(0, 5)
      .setSize(15, 15)
        .setGroup(visibleControls)
          .setMoveable(true)
            .setItemsPerRow(1)
              .setSpacingColumn(17)
                .setSpacingRow(2)
                  .addItem("Frame picker", 1)
                    .addItem("Raster image", 10)
                      .addItem("View Rotation", 100)
                        .addItem("View Scale", 1000)
                          .addItem("View position", 10000)
                            .addItem("View Perspective", 100000);

  controlsVisible.activate(0);



  Group framePicker = cp5.addGroup("framePicker") //A group, for convenience
    .setPosition(150, 35)
      .setSize(120, 20)
        .setVisible(false)
          .moveTo("framed")
            ;

  cp5.addBang("previousFrameEd")
    .setPosition(20, 5)
      .setImages(previmgs)
        .updateSize()
          .setTriggerEvent(Bang.RELEASE)
            .setLabel("<")
              .setGroup(framePicker)
                ;

  cp5.addBang("nextFrameEd")
    .setPosition(80, 5)
      .setImages(nextimgs)
        .updateSize()
          .setGroup(framePicker)
            .setTriggerEvent(Bang.RELEASE)
              .setLabel(">")
                ;

  cp5.addBang("firstFrameEd")
    .setPosition(0, 5)
      .setImages(firstimgs)
        .updateSize()
          .setGroup(framePicker)
            .setTriggerEvent(Bang.RELEASE)
              .setLabel("<<")
                ;

  cp5.addBang("lastFrameEd")
    .setPosition(100, 5)
      .setImages(lastimgs)
        .updateSize()
          .setGroup(framePicker)
            .setTriggerEvent(Bang.RELEASE)
              .setLabel(">>")
                ;

  cp5.addToggle("listFrameEd")
    .setPosition(40, 5)
      .setSize(37, 20)
        .setGroup(framePicker)
          .setCaptionLabel("List")
            .getCaptionLabel().alignX(CENTER).alignY(CENTER)
              ;



  Group rasterImage = cp5.addGroup("rasterImage") //A group, for convenience
    .setPosition(300, 35)
      .setSize(120, 20)
        .setVisible(false)
          .setLabel("Raster image")
            .moveTo("framed")
              ;

  cp5.addButton("openFramedImage")
    .setPosition(0, 5)
      .setSize(57, 20)
        .setGroup(rasterImage)
          .setCaptionLabel("Open")
            .getCaptionLabel().alignX(CENTER);

  cp5.addToggle("hideFramedImage")
    .setPosition(63, 5)
      .setSize(57, 20)
        .setGroup(rasterImage)
          .setCaptionLabel("Hide")
            .getCaptionLabel().alignX(CENTER).alignY(CENTER);

  cp5.addButton("recolourFramedImage")
    .setPosition(0, 30)
      .setSize(120, 20)
        .setGroup(rasterImage)
          .setCaptionLabel("Colour to points")
            .getCaptionLabel().alignX(CENTER);

  cp5.addButton("positionFramedImage")
    .setPosition(0, 55)
      .setSize(57, 20)
        .setGroup(rasterImage)
          .setCaptionLabel("Position")
            .getCaptionLabel().alignX(CENTER);

  cp5.addToggle("sizeFramedImage")
    .setPosition(63, 55)
      .setSize(57, 20)
        .setGroup(rasterImage)
          .setCaptionLabel("Size")
            .getCaptionLabel().alignX(CENTER).alignY(CENTER);

  cp5.addSlider("sizeXYFramedImage")
    .setPosition(0, 80)
      .setSize(120, 20)
        .setGroup(rasterImage)
          .setRange(-1.5f, 1.5f)
            .setValue(1)
              .setVisible(false)
                .setSliderMode(Slider.FLEXIBLE)
                  .setCaptionLabel("Size")
                    .getCaptionLabel().alignX(CENTER)
                      ;


  cp5.addSlider("sizeXFramedImage")
    .setPosition(0, 105)
      .setSize(120, 20)
        .setGroup(rasterImage)
          .setRange(-1.5f, 1.5f)
            .setValue(1)
              .setVisible(false)
                .setSliderMode(Slider.FLEXIBLE)
                  .setCaptionLabel("Size X")
                    .getCaptionLabel().alignX(CENTER)
                      ;

  cp5.addSlider("sizeYFramedImage")
    .setPosition(0, 130)
      .setSize(120, 20)
        .setGroup(rasterImage)
          .setRange(-1.5f, 1.5f)
            .setValue(1)
              .setVisible(false)
                .setSliderMode(Slider.FLEXIBLE)
                  .setCaptionLabel("Size Y")
                    .getCaptionLabel().alignX(CENTER)
                      ;




  Group rotationControl = cp5.addGroup("rotationControl")
    .setPosition(450, 35)
      .setSize(120, 20)
        .setVisible(false)
          .setLabel("View Rotation")
            .moveTo("framed")
              ;

  cp5.addSlider("rotationX")
    .setPosition(0, 5)
      .setSize(120, 20)
        .setGroup(rotationControl)
          .setRange(-1, 1)
            .setSliderMode(Slider.FLEXIBLE)
              .setCaptionLabel("X")
                .getCaptionLabel().alignX(CENTER)
                  ;

  cp5.addSlider("rotationY")
    .setPosition(0, 30)
      .setSize(120, 20)
        .setGroup(rotationControl)
          .setRange(-1, 1)
            .setSliderMode(Slider.FLEXIBLE)
              .setCaptionLabel("Y")
                .getCaptionLabel().alignX(CENTER)
                  ;

  cp5.addSlider("rotationZ")
    .setPosition(0, 55)
      .setSize(120, 20)
        .setGroup(rotationControl)
          .setRange(-1, 1)
            .setSliderMode(Slider.FLEXIBLE)
              .setCaptionLabel("Z")
                .getCaptionLabel().alignX(CENTER)
                  ;

  Group sizeControl = cp5.addGroup("sizeControl")
    .setPosition(1, 1)
      .setSize(120, 20)
        .setVisible(false)
          .setLabel("View Scale")
            .moveTo("framed")
              ;

  cp5.addSlider("zoom")
    .setPosition(0, 5)
      .setSize(120, 20)
        .setGroup(sizeControl)
          .setRange(-0.1f, 0.1f)
            .setValue(0)
              .setVisible(true)
                .setSliderMode(Slider.FLEXIBLE)
                  .setCaptionLabel("Zoom")
                    .getCaptionLabel().alignX(CENTER)
                      ;


  cp5.addButton("resetZoom")
    .setPosition(0, 30)
      .setSize(120, 20)
        .setGroup(sizeControl)
          .setCaptionLabel("Reset")
            .getCaptionLabel().alignX(CENTER);

  Group positionControl = cp5.addGroup("positionControl")
    .setPosition(1, 1)
      .setSize(120, 20)
        .setVisible(false)
          .setLabel("View Position")
            .moveTo("framed")
              ;

  Group perspective = cp5.addGroup("perspective")
    .setPosition(1, 1)
      .setSize(120, 20)
        .setVisible(false)
          .setLabel("View Perspective")
            .moveTo("framed")
              ;

  cp5.addSlider("viewPerspective")
    .setPosition(0, 5)
      .setSize(120, 20)
        .setGroup(perspective)
          .setRange(0, 10)
            .setValue(0)
              .setVisible(true)
                .setSliderMode(Slider.FLEXIBLE)
                  .setCaptionLabel("Perspective")
                    .getCaptionLabel().alignX(CENTER)
                      ;



  //      === TAB: PALETTES ===

  cp5.addTab("palettes")
    .activateEvent(true)
      .setLabel("Palette editor")
        .setId(4);

  paletteList = cp5.addListBox("myList")
    .setPosition(10, 150)
      .setSize(145, 300)
        .moveTo("palettes")
          .setLabel("All palettes")
            .setItemHeight(15)
              .setBarHeight(15)
                ;

  paletteList.captionLabel().toUpperCase(true);
  paletteList.captionLabel().style().marginTop = 3;
  paletteList.toUpperCase(false);
  paletteList.valueLabel().style().marginTop = 3;

  cp = cp5.addColorPicker("picker")
    .setPosition(width-425, 450)
      .moveTo("palettes")
        ;

  cp5.addButton("recolourFrames")
    .setPosition(10, 25)
      .setSize(145, 25)
        .moveTo("palettes")
          .setCaptionLabel(" Recolour all  palette  frames")
            .setVisible(true)
              .getCaptionLabel().alignX(CENTER);


  cp5.addButton("addPalette")
    .setPosition(10, 60)
      .setSize(70, 25)
        .moveTo("palettes")
          .setCaptionLabel("New")
            .setVisible(true)
              .getCaptionLabel().alignX(CENTER);

  cp5.addButton("removePalette")
    .setPosition(85, 60)
      .setSize(70, 25)
        .moveTo("palettes")
          .setCaptionLabel("Delete")
            .setVisible(true)
              .getCaptionLabel().alignX(CENTER);

  cp5.addButton("importPalette")
    .setPosition(10, 90)
      .setSize(70, 25)
        .moveTo("palettes")
          .setCaptionLabel("Import")
            .setVisible(true)
              .getCaptionLabel().alignX(CENTER);

  cp5.addButton("exportPalette")
    .setPosition(85, 90)
      .setSize(70, 25)
        .moveTo("palettes")
          .setCaptionLabel("Export")
            .setVisible(true)
              .getCaptionLabel().alignX(CENTER);

  PFont font = createFont("arial", 12);

  cp5.addTextfield("input")
    .setPosition(width-150, 490)
      .setSize(120, 20)
        .setFont(font)
          .moveTo("palettes")
            .setCaptionLabel("Rename")
              .setFocus(true)
                // .setColor(color(255, 0, 0))
                ;

  cp5.addTextfield("numberOfColours")
    .setPosition(width-425, 515)
      .setSize(120, 20)
        .setFont(font)
          .moveTo("palettes")
            .setCaptionLabel("Number of colours (< 256)")
              .setFocus(true)
                // .setColor(color(255, 0, 0))
                ;




  //      === TAB: SEQUENCE CREATOR ===



  cp5.addTab("deluxe")        //Initiating the tab to go to the Deluxe Paint mode
    .activateEvent(true)
      .setLabel("Sequence creator")
        .setId(5)
          //.setColorBackground(color(0, 0, 100))
          //  .setColorLabel(color(255))
          //    .setColorActive(color(0, 150, 255))
          ;

  Group seqControlsVisible = cp5.addGroup("seqControlsVisible")
    .setPosition(10, 65)
      .setSize(150, 10)
        .setVisible(true)
          .setLabel("Select a sequence mode")
            .moveTo("deluxe");

  seqMode = cp5.addRadioButton("seqMode")
    .setGroup(seqControlsVisible)
      .setSize(150, 25)
        .setPosition(0, 1)
          .setItemsPerRow(1)
            .setSpacingRow(1)
              .addItem("Deluxe Paint", 0)
                .addItem("Oscillabstract", 1);

  for (Toggle t : seqMode.getItems ())
  {
    t.getCaptionLabel().alignY(CENTER).alignX(CENTER);
  }

  cp5.addButton("clearSeqCreatorFrames")
    .setPosition(width-90, 25)
      .setSize(85, 25)
        .moveTo("deluxe")
          .setMoveable(true)
            .setLabel("Clear all frames")
              .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.getTooltip().register("clearDeluxeFrames", "Reset the current sequence").getLabel().toUpperCase(false);

  cp5.addButton("finishSeqCreator")
    .setPosition(10, 25)
      .setSize(150, 25)
        .moveTo("deluxe")      //Only visible in Deluxe Paint tab
          .setMoveable(true)
            .setLabel("Import in IldaViewer")
              .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.getTooltip().register("finishDeluxePaint", "Import sequence to frame list").getLabel().toUpperCase(false);

  cp5.addToggle("showSQBlanking")
    .setPosition(width-90, 55)
      .setSize(85, 25)
        .moveTo("deluxe")
          .setValue(showBlanking)
            .setMoveable(true)
              .setValueLabel("Show blanking lines")
                .setCaptionLabel("Show blanking")
                  .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.addButton("emptyOscElements")
    .setPosition(width-90, 25)
      .setSize(85, 25)
        .moveTo("deluxe")
          .setMoveable(true)
            .setVisible(false)
              .setLabel("Clear")
                .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.addButton("loadElements")
    .setPosition(width-90, 55)
      .setSize(85, 25)
        .moveTo("deluxe")
          .setMoveable(true)
            .setVisible(false)
              .setLabel("Load")
                .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.addButton("saveElements")
    .setPosition(width-90, 85)
      .setSize(85, 25)
        .moveTo("deluxe")
          .setMoveable(true)
            .setVisible(false)
              .setLabel("Save")
                .getCaptionLabel().alignY(CENTER).alignX(CENTER);



  //      === TAB: EXPORT ===

  cp5.addTab("export")
    .activateEvent(true)
      .setLabel("Export to file")
        .setId(4);

  cp5.addButton("exportFile")
    .setPosition(10, 25)
      .setSize(100, 100)
        .moveTo("export")      //Only visible in Deluxe Paint tab
          .setMoveable(true)
            .setLabel("Export Ilda file")
              .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  r = cp5.addRadioButton("radioButton")
    .setPosition(120, 25)
      .moveTo("export")
        .setSize(22, 22)
          .setItemsPerRow(1)
            .setSpacingColumn(5)
              .setSpacingRow(4)
                .setNoneSelectedAllowed(false)
                  .addItem("0: 3D, palette", 0)
                    .addItem("1: 2D, palette", 1)
                      .addItem("4: 3D, BGR (true colour)", 4)
                        .addItem("5: 2D, BGR (true colour)", 5)
                          .activate(2);

  cp5.addTextfield("firstExportFrame")
    .setPosition(10, 185)
      .setSize(47, 20)
        .setFont(font)
          .setVisible(false)
            .moveTo("export")
              .setCaptionLabel("First frame")
                .setFocus(true)
                  ;

  cp5.addTextfield("lastExportFrame")
    .setPosition(63, 185)
      .setSize(47, 20)
        .setFont(font)
          .setVisible(false)
            .moveTo("export")
              .setCaptionLabel("Last frame")
                .setFocus(true)
                  ;

  cp5.addToggle("exportWholeFile")
    .setPosition(10, 135)
      .setSize(100, 25)
        .moveTo("export")
          .setValue(exportWholeFile)
            .setMoveable(true)
              .setValueLabel("Show blanking lines")
                .setCaptionLabel("Export all frames")
                  .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  exportingFrames = cp5.addTextlabel("labelExportingFrames")
    .setText("Exporting from to")
      .setPosition(7, 165)
        .moveTo("export")
          .setVisible(false)
            .setFont(font)
              ;

  cp5.addButton("previousPaletteExp")
    .setPosition(width-325, 85)
      .setSize(145, 25)
        .moveTo("export")
          .setLabel("< Previous palette")
            .setVisible(false)
              ;

  cp5.addButton("nextPaletteExp")
    .setPosition(width-170, 85)
      .setSize(145, 25)
        .moveTo("export")
          .setLabel("Next palette >")
            .setVisible(false)
              .getCaptionLabel().alignX(RIGHT)
                ;

  cp5.addToggle("findBestColour")
    .setPosition(width-325, 55)
      .setSize(300, 25)
        .setVisible(false)
          .moveTo("export")
            .setValue(includePalette)
              .setMoveable(true)
                .setCaptionLabel("Find best fitting colour for RGB frames")
                  .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  cp5.addToggle("includePalette")
    .setPosition(width-325, 25)
      .setSize(300, 25)
        .setVisible(false)
          .moveTo("export")
            .setValue(includePalette)
              .setMoveable(true)
                .setCaptionLabel("Include palette in file")
                  .getCaptionLabel().alignY(CENTER).alignX(CENTER);

  /*
    
   //Pro laserist mode no longer supported. Complaints can be sent to the nearest mirror.
   
   //Placed after all Controllers, otherwise nullpointererrors galore
   cp5.addToggle("proLaseristMode")
   .setPosition(width-90, 90)
   .setSize(85, 10)
   .moveTo("default")
   .setValue(proLaseristMode)
   .setVisible(true)
   .setMoveable(true)
   .setValueLabel("Show information")
   .setCaptionLabel("Pro Laserist Mode")
   .getCaptionLabel().alignY(CENTER).alignX(CENTER);
   */
}


// Fields for Export tab:

RadioButton r;                //ControlP5 radio button (export file format selection)
int exportVersion = 4;        //Create Ilda V4 file by default
FileExport exporter;
boolean exporting = false;    //Exporting mode
Textlabel exportingFrames;    //Some ControlP5 text
boolean includePalette = true;//Should the palette be included in the file?
boolean exportWholeFile = true;//Export all frames by default
boolean findBestColour = true; //RGB points get automatically a fitting palette index

//      === EXPORT TAB METHODS AND CALLBACKS ===

public void beginExporter()
{
  exporting = true;
  exporter = new FileExport();

  if (includePalette && (exportVersion == 0 || exportVersion == 1))
  {
    cp5.getController("nextPaletteExp").setVisible(true);
    cp5.getController("previousPaletteExp").setVisible(true);
    cp5.getController("findBestColour").setVisible(true);
  } else
  {
    cp5.getController("nextPaletteExp").setVisible(false);
    cp5.getController("previousPaletteExp").setVisible(false);
    cp5.getController("findBestColour").setVisible(false);
  }

  status.clear();
  status.add("Choose your options then click the big button.");
}

public void endExporter()
{
  exporting = false;
  status.clear();
  status.add("Exporter exited");
}

public void exportFile()
{
  String pathname;
  if (frames.isEmpty()) pathname = ".ild";
  else pathname = frames.get(frames.size()-1).frameName + ".ild";
  File theFile = new File(pathname);
  status.clear();
  status.add("Select where to write a file");
  selectOutput("Select an ilda file", "ildaOutput", theFile);
}

public void ildaOutput(File selection)
{
  if (selection == null)
  {
    status.clear();
    status.add("Ilda file exporting aborted.");
    return;
  }
  status.clear();

  String location = selection.getAbsolutePath();
  char[] test = new char[4];  //Test if it already has the extension .ild:
  for (int i = 0; i < 4; i++)
  {
    test[i] = location.charAt(i+location.length()-4);
  }
  String testing = new String(test);
  if ( !testing.equals(".ild") )
  {
    location += ".ild";
  }

  ArrayList<Frame> expframes = new ArrayList<Frame>();

  // You found me! Cheater!
  if (frames.isEmpty() )
  {
    Frame easterEggFrame = new Frame();
    float redPhase = random(0, TWO_PI);      //Colour modulation parameters
    float greenPhase = random(0, TWO_PI);
    float bluePhase = random(0, TWO_PI);
    int xFreq = PApplet.parseInt(random(1, 15));
    int yFreq = PApplet.parseInt(random(1, 15));
    int zFreq = PApplet.parseInt(random(1, 3));
    int redFreq = PApplet.parseInt(random(1, xFreq*zFreq));
    int greenFreq = PApplet.parseInt(random(1, yFreq*zFreq));
    int blueFreq = PApplet.parseInt(random(1, xFreq*yFreq/(5*zFreq)));
    int maxPoints = 499;
    for (int i = 0; i <= maxPoints; i++)
    {
      PVector position = new PVector(
      width*(sin(PApplet.parseFloat(i)*TWO_PI*PApplet.parseFloat(xFreq)/maxPoints)*cos(PApplet.parseFloat(i)*TWO_PI*PApplet.parseFloat(yFreq)/maxPoints)*0.35f+0.5f), 
      height*(sin(PApplet.parseFloat(i)*TWO_PI*PApplet.parseFloat(xFreq)/maxPoints)*sin(PApplet.parseFloat(i)*TWO_PI*PApplet.parseFloat(yFreq)/maxPoints)*0.35f+0.5f), 
      depth*(sin(PApplet.parseFloat(i)*TWO_PI*PApplet.parseFloat(xFreq*zFreq)/maxPoints)*cos(PApplet.parseFloat(i)*TWO_PI*2*PApplet.parseFloat(yFreq*zFreq)/maxPoints)*0.35f+0.5f)
        );

      Point thepoint = new Point(position, PApplet.parseInt((sin(PApplet.parseFloat(i)*TWO_PI*PApplet.parseFloat(redFreq)/maxPoints+redPhase)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(i)*TWO_PI*PApplet.parseFloat(greenFreq)/maxPoints+greenPhase)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(i)*TWO_PI*PApplet.parseFloat(blueFreq)/maxPoints+bluePhase)*0.5f+0.5f)*255), false);
      easterEggFrame.points.add(thepoint);
    }
    easterEggFrame.ildaVersion = 4;
    easterEggFrame.frameName = "EastrEgg";
    easterEggFrame.companyName = "IldaView";
    easterEggFrame.pointCount = 500;
    easterEggFrame.frameNumber = 1;
    easterEggFrame.totalFrames = 1;
    easterEggFrame.scannerHead = 9001;
    easterEggFrame.fitColourIndexWithPalette(getActivePalette());
    expframes.add(easterEggFrame);
    status.add("Laid an egg.");
  } else
  {
    //Only include selected frames:
    if (exporter.firstFrame >= 0 && exporter.lastFrame < frames.size())
    {
      if (exportWholeFile) expframes = frames;
      else
      {
        for (int i = exporter.firstFrame; i <= exporter.lastFrame; i++)
        {
          expframes.add(frames.get(i));
        }
      }
    }
  }

  if (findBestColour)
  {
    for (Frame frame : expframes)
    {
      frame.fitColourIndexWithPalette(getActivePalette());
    }
  }

  if (includePalette && (exportVersion == 0 || exportVersion == 1)) 
  {
    FileWrapper theFile = new FileWrapper(location, expframes, getActivePalette(), exportVersion);
  } else 
  {
    FileWrapper theFile = new FileWrapper(location, expframes, exportVersion);
  }


  status.add("Ilda file succesfully exported on location:");
  status.add(location);
}


public void exportWholeFile(boolean shouldIt)
{
  if (cp5.getWindow().getCurrentTab().getName().equals("export"))
  {
    if (shouldIt  )
    {
      exporter.firstFrame = 0;
      exporter.lastFrame = frames.size()-1;
      if (frames.isEmpty() ) exporter.lastFrame = 0;
      cp5.getController("firstExportFrame").setVisible(false);
      cp5.getController("lastExportFrame").setVisible(false);
      cp5.getController("exportWholeFile").setCaptionLabel("Export all frames");
      exportingFrames.setVisible(false);
    } else
    {
      cp5.getController("firstExportFrame").setVisible(true);
      cp5.getController("lastExportFrame").setVisible(true);
      exportingFrames.setVisible(true);
      exportingFrames.setText("Exporting from " + (exporter.firstFrame+1) + " to " + (exporter.lastFrame+1));
      cp5.getController("exportWholeFile").setCaptionLabel("Export selected frames");
    }
    exporter.exportAllFrames = shouldIt;
    exportWholeFile = shouldIt;
  }
}

public void firstExportFrame(String theText)
{
  int firstFr = PApplet.parseInt(theText)-1;
  if (firstFr < 0) firstFr = 0;
  if (firstFr >frames.size()-1) firstFr =frames.size()-1;
  if (frames.isEmpty() ) firstFr = 0;
  if (firstFr >= exporter.lastFrame) exporter.lastFrame = firstFr;
  exporter.firstFrame = firstFr;
  exportingFrames.setText("Exporting from " +( exporter.firstFrame +1)+ " to " + (exporter.lastFrame+1));
}

public void lastExportFrame(String theText)
{

  int lastFr = PApplet.parseInt(theText)-1;
  if (lastFr < 0) lastFr = 0;
  if (lastFr > frames.size()-1) lastFr = frames.size()-1;
  if (frames.isEmpty() ) lastFr = 0;
  if (lastFr < exporter.firstFrame) lastFr = exporter.firstFrame;
  exporter.lastFrame = lastFr;
  exportingFrames.setText("Exporting from " +( exporter.firstFrame +1)+ " to " + (exporter.lastFrame+1));
}

public void includePalette(boolean shouldWe)
{
  includePalette = shouldWe;
  if (shouldWe)
  {
    cp5.getController("nextPaletteExp").setVisible(true);
    cp5.getController("previousPaletteExp").setVisible(true);
    cp5.getController("findBestColour").setVisible(true);
    cp5.getController("includePalette").getCaptionLabel().setText("Include palette in file");
  } else
  {
    cp5.getController("nextPaletteExp").setVisible(false);
    cp5.getController("previousPaletteExp").setVisible(false);
    cp5.getController("findBestColour").setVisible(false);
    cp5.getController("includePalette").getCaptionLabel().setText("Don't include palette in file");
  }
}

public void previousPaletteExp() //manually skip to previous active palette
{
  if (activePalette <= 0)
  {
    activePalette = palettes.size()-1;
  } else 
  {
    activePalette--;
  }
}

public void nextPaletteExp() //manually skip to next active palette
{
  if (activePalette >= palettes.size()-1)
  {
    activePalette = 0;
  } else
  {
    activePalette++;
  }
}

public void findBestColour(boolean doIttt)
{
  if (doIttt) cp5.getController("findBestColour").getCaptionLabel().setText("Find best fitting colour for RGB frames");
  else cp5.getController("findBestColour").getCaptionLabel().setText("Don't find best fitting colour for RGB frames");
}



class FileExport
{
  int firstFrame = 0;
  int lastFrame = 0;
  boolean exportAllFrames = true;

  FileExport()
  {
  }

  public void update()
  {
    if (includePalette && (exportVersion == 0 || exportVersion == 1))
    {
      if (activePalette >= 0  || activePalette < palettes.size())
      {
        displayPalette(palettes.get(activePalette));
      }
      fill(255);
      text(palettes.get(activePalette).name, width-325, 433);
    }
  }

  public void displayPalette(Palette palette)
  {
    int i = 0;
    for (PaletteColour colour : palette.colours)
    {
      stroke( color(50, 50, 50));
      strokeWeight(1);

      colour.displayColour(width-325+19*(i%16), 115+19*PApplet.parseInt(i/16), 15);
      i++;
    }
  }
}

/*
 * This class reads a file and passes the data to frames and points. 
 * It's advised to not store instances of this class if not necessary, as it can get quite voluminous
 * after loading in large files. 
 * 
 * Ilda files are explained here: http://www.laserist.org/StandardsDocs/IDTF05-finaldraft.pdf
 * This document only mentions Ilda V0, 1, 2 and 3, no V4 and V5 so here's a breakdown:
 * ILDA V0 is 3D and uses palettes
 * ILDA V1 is 2D and uses palettes
 * ILDA V2 is a palette
 * ILDA V3 is a 24-bit palette, but was discontinued and is not a part of the official standard anymore
 * ILDA V4 is 3D with true-colour information in BGR format
 * ILDA V5 is 2D with true-colour information in BGR format
 *
 * An Ilda file is composed of headers that always start with "ILDA", followed by three zeros and the version number.
 * A complete header is 32 bytes.
 * After the header, the data follows. In case of a palette (V2), each data point has three bytes: R, G and B.
 * In case of a frame (V0/1/4/5), the X, Y and Z (for 3D frames) values are spread out over two bytes
 * They can be joined together with the unsignedShortToInt() method heroic graciously made in the PL IRC channel.
 * Then either two status bytes follow with a blanking bit and palette colour number, or BGR values.
 * 
 */


class FileWrapper
{
  String location;         //Absolute path to the file
  byte[] b;                //Array with bits readed from the file
  IntList framePositions;  //IntList with indices in b[] where a new ILDA header has been found
  String name = "";


  FileWrapper(String _location)    //Constructor, automatically reads file
  {
    location = _location;
    try { 
      b = loadBytes(location);
      readFile();
    }
    catch(Exception e)
    {
      status.add("Could not read file");
      if (e.getMessage() != null) status.add(e.getMessage());
    }
  }

  FileWrapper(String _location, ArrayList<Frame> frames, Palette _palette, int ildVersion)    //Constructor, automatically writes file with provided palette
  {

    location = _location;
    b = framesToBytes(frames, ildVersion);
    writeFile(_palette);
  }

  FileWrapper(String _location, ArrayList<Frame> dframes, int ildVersion)    //Constructor, automatically writes file
  {

    location = _location;
    b = framesToBytes(dframes, ildVersion);
    writeFile();
  }

  FileWrapper(String _location, boolean notEvenUsedBecauseISuckAtProgramming)
  {
    b = loadBytes(_location);
  }

  //Cascade of writeFiles():
  public void writeFile(Palette _palette)
  {
    writeFile(location, b, _palette);
  }

  public void writeFile()
  {
    writeFile(location, b);
  }

  //Merge a palette table with an existing array of bytes (the palette is placed at the beginning of the file)
  public void writeFile(String location, byte[] _b, Palette aPalette)
  {
    byte[] pbytes = aPalette.paletteToBytes();
    /*
    int totalLength = _b.length + pbytes.length;
     byte[] merged = new byte[totalLength];
     for (int i = 0; i < pbytes.length; i++)
     {
     merged[i] = pbytes[i];
     }
     for (int i = 0; i < _b.length; i++)
     {
     merged[i+pbytes.length] = _b[i];
     }
     */
    byte[] merged = concat(pbytes, _b);

    writeFile(location, merged);
  }

  //Ah finally, a writeFile() that actually writes to a file!
  public void writeFile(String location, byte[] _b)
  {
    saveBytes(location, _b);
  }

  //Convert an ArrayList of Frames to ilda-compliant bytes:
  public byte[] framesToBytes(ArrayList<Frame> frames, int ildVersion)
  {
    ArrayList<Byte> theBytes;
    theBytes = new ArrayList<Byte>();
    int frameNum = 0;

    if (frames.isEmpty() ) return null;

    for (Frame frame : frames)
    {
      theBytes.add(PApplet.parseByte('I'));
      theBytes.add(PApplet.parseByte('L'));
      theBytes.add(PApplet.parseByte('D'));
      theBytes.add(PApplet.parseByte('A'));
      theBytes.add(PApplet.parseByte(0));
      theBytes.add(PApplet.parseByte(0));
      theBytes.add(PApplet.parseByte(0));

      if (ildVersion == 0 || ildVersion == 1 || ildVersion == 2 || ildVersion == 4 || ildVersion == 5 ) theBytes.add(PApplet.parseByte(ildVersion));
      else
      {
        status.clear();
        status.add("Error: invalid ilda version");
        return null;
      }

      for (int i = 0; i < 8; i++)    //Bytes 9-16: Name
      {
        char letter;
        if (frame.frameName.length() < i+1) letter = ' ';
        else letter = frame.frameName.charAt(i);
        theBytes.add(PApplet.parseByte(letter));
      }

      if (frame.companyName.length() == 0)   //Bytes 17-24: Company Name
      {
        theBytes.add(PApplet.parseByte('I'));     //If empty: call it "IldaView"
        theBytes.add(PApplet.parseByte('l'));
        theBytes.add(PApplet.parseByte('d'));
        theBytes.add(PApplet.parseByte('a'));
        theBytes.add(PApplet.parseByte('V'));
        theBytes.add(PApplet.parseByte('i'));
        theBytes.add(PApplet.parseByte('e'));
        theBytes.add(PApplet.parseByte('w'));
      } else
      {
        for (int i = 0; i < 8; i++)  
        {
          char letter;
          if (frame.companyName.length() < i+1) letter = ' ';
          else letter = frame.companyName.charAt(i);
          theBytes.add(PApplet.parseByte(letter));
        }
      }

      //Bytes 25-26: Total point count
      theBytes.add(PApplet.parseByte((frame.points.size()>>8)&0xff));    //This better be correct
      theBytes.add(PApplet.parseByte(frame.points.size()&0xff));


      //Bytes 27-28: Frame number (automatically increment each frame)
      theBytes.add(PApplet.parseByte((++frameNum>>8)&0xff));    //This better be correct
      theBytes.add(PApplet.parseByte(frameNum&0xff));


      //Bytes 29-30: Number of frames
      theBytes.add(PApplet.parseByte((frames.size()>>8)&0xff));    //This better be correct
      theBytes.add(PApplet.parseByte(frames.size()&0xff));

      theBytes.add(PApplet.parseByte(frame.scannerHead));    //Byte 31 is scanner head
      theBytes.add(PApplet.parseByte(0));                    //Byte 32 is future

      // Ilda V0: 3D, palette
      if (ildVersion == 0)
      {
        for (Point point : frame.points)
        {
          int posx = PApplet.parseInt(constrain(map(point.position.x, 0, width, -32768, 32767), -32768, 32768));
          theBytes.add(PApplet.parseByte((posx>>8)&0xff));   
          theBytes.add(PApplet.parseByte(posx & 0xff));

          int posy = PApplet.parseInt(constrain(map(point.position.y, height, 0, -32768, 32767), -32768, 32768));
          theBytes.add(PApplet.parseByte((posy>>8)&0xff));   
          theBytes.add(PApplet.parseByte(posy & 0xff));

          int posz = PApplet.parseInt(constrain(map(point.position.z, 0, depth, -32768, 32767), -32768, 32768));    
          theBytes.add(PApplet.parseByte((posz>>8)&0xff));   
          theBytes.add(PApplet.parseByte(posz & 0xff));

          if (point.blanked)
          {
            theBytes.add(PApplet.parseByte(unbinary("01000000")));
          } else
          {
            theBytes.add(PApplet.parseByte(0));
          }
          theBytes.add(PApplet.parseByte(point.paletteIndex));
        }
      }

      //Ilda V1: 2D, palettes
      if (ildVersion == 1)
      {
        for (Point point : frame.points)
        {
          int posx = PApplet.parseInt(constrain(map(point.position.x, 0, width, -32768, 32767), -32768, 32768));
          theBytes.add(PApplet.parseByte((posx>>8)&0xff));   
          theBytes.add(PApplet.parseByte(posx & 0xff));

          int posy = PApplet.parseInt(constrain(map(point.position.y, height, 0, -32768, 32767), -32768, 32768));
          theBytes.add(PApplet.parseByte((posy>>8)&0xff));   
          theBytes.add(PApplet.parseByte(posy & 0xff));

          if (point.blanked)
          {
            theBytes.add(PApplet.parseByte(unbinary("01000000")));
          } else
          {
            theBytes.add(PApplet.parseByte(0));
          }
          theBytes.add(PApplet.parseByte(point.paletteIndex));
        }
      }

      //Huh? This isn't supposed to be here. Oh well, better be prepared.
      if (ildVersion == 2)
      {
        byte[] sfq = getActivePalette().paletteToBytes();
        for (int i = 0; i < sfq.length; i++)
        {
          theBytes.add(sfq[i]);
        }
      }

      //Ilda V4: 3D, BGR (why not RGB? Because reasons)
      if (ildVersion == 4)
      {
        for (Point point : frame.points)
        {
          int posx = PApplet.parseInt(constrain(map(point.position.x, 0, width, -32768, 32767), -32768, 32768));
          theBytes.add(PApplet.parseByte((posx>>8)&0xff));   
          theBytes.add(PApplet.parseByte(posx & 0xff));

          int posy = PApplet.parseInt(constrain(map(point.position.y, height, 0, -32768, 32767), -32768, 32768));
          theBytes.add(PApplet.parseByte((posy>>8)&0xff));   
          theBytes.add(PApplet.parseByte(posy & 0xff));

          int posz = PApplet.parseInt(constrain(map(point.position.z, 0, depth, -32768, 32767), -32768, 32768));    
          theBytes.add(PApplet.parseByte((posz>>8)&0xff));   
          theBytes.add(PApplet.parseByte(posz & 0xff));

          if (point.blanked) theBytes.add(PApplet.parseByte(unbinary("01000000")));
          else theBytes.add(PApplet.parseByte(0));

          int c = point.colour;
          if (point.blanked) c = color(0, 0, 0);  //some programs only use colour information to determine blanking

          int red = (c >> 16) & 0xFF;  // Faster way of getting red(argb)
          int green = PApplet.parseInt((c >> 8) & 0xFF);   // Faster way of getting green(argb)
          int blue = PApplet.parseInt(c & 0xFF);          // Faster way of getting blue(argb)

          theBytes.add(PApplet.parseByte(blue));
          theBytes.add(PApplet.parseByte(green));
          theBytes.add(PApplet.parseByte(red));
        }
      }

      //Ilda V5: 2D, BGR
      if (ildVersion == 5)
      {
        for (Point point : frame.points)
        {
          int posx = PApplet.parseInt(constrain(map(point.position.x, 0, width, -32768, 32767), -32768, 32768));  
          theBytes.add(PApplet.parseByte((posx>>8)&0xff));   
          theBytes.add(PApplet.parseByte(posx & 0xff));

          int posy = PApplet.parseInt(constrain(map(point.position.y, height, 0, -32768, 32767), -32768, 32768));
          theBytes.add(PApplet.parseByte((posy>>8)&0xff));   
          theBytes.add(PApplet.parseByte(posy & 0xff));



          if (point.blanked) theBytes.add(PApplet.parseByte(unbinary("01000000")));
          else theBytes.add(PApplet.parseByte(0));

          int c = point.colour;
          if (point.blanked) c = color(0, 0, 0);    //some programs only use colour information to determine blanking

          int red = (c >> 16) & 0xFF;  // Faster way of getting red(argb)
          int green = PApplet.parseInt((c >> 8) & 0xFF);   // Faster way of getting green(argb)
          int blue = PApplet.parseInt(c & 0xFF);          // Faster way of getting blue(argb)

          theBytes.add(PApplet.parseByte(blue));
          theBytes.add(PApplet.parseByte(green));
          theBytes.add(PApplet.parseByte(red));
        }
      }
    }

    //File should always end with a header

    theBytes.add(PApplet.parseByte('I'));
    theBytes.add(PApplet.parseByte('L'));
    theBytes.add(PApplet.parseByte('D'));
    theBytes.add(PApplet.parseByte('A'));
    theBytes.add(PApplet.parseByte(0));
    theBytes.add(PApplet.parseByte(0));
    theBytes.add(PApplet.parseByte(0));
    theBytes.add(PApplet.parseByte(ildVersion));

    theBytes.add(PApplet.parseByte('L'));
    theBytes.add(PApplet.parseByte('A'));
    theBytes.add(PApplet.parseByte('S'));
    theBytes.add(PApplet.parseByte('T'));
    theBytes.add(PApplet.parseByte(' '));
    theBytes.add(PApplet.parseByte('O'));
    theBytes.add(PApplet.parseByte('N'));
    theBytes.add(PApplet.parseByte('E'));

    theBytes.add(PApplet.parseByte('I'));     
    theBytes.add(PApplet.parseByte('l'));
    theBytes.add(PApplet.parseByte('d'));
    theBytes.add(PApplet.parseByte('a'));
    theBytes.add(PApplet.parseByte('V'));
    theBytes.add(PApplet.parseByte('i'));
    theBytes.add(PApplet.parseByte('e'));
    theBytes.add(PApplet.parseByte('w'));

    theBytes.add(PApplet.parseByte(0));
    theBytes.add(PApplet.parseByte(0));

    theBytes.add(PApplet.parseByte(0));
    theBytes.add(PApplet.parseByte(0));

    theBytes.add(PApplet.parseByte(0));
    theBytes.add(PApplet.parseByte(0));

    theBytes.add(PApplet.parseByte(0));

    theBytes.add(PApplet.parseByte(0));




    byte [] bt = new byte[theBytes.size()]; //Ugh!
    for (int i = 0; i<theBytes.size (); i++)
    {
      bt[i] = theBytes.get(i);
    }


    return bt;
  }

  public ArrayList<Frame> getFramesFromBytes()
  {
    ArrayList<Frame> theFrames = new ArrayList<Frame>();
    if (b == null) return null;

    if (b.length < 32)
    {
      //There isn't even a complete header here!
      status.add("Invalid file");
      println("invalid file");
      return null;
    }

    //Check if the first four bytes read ILDA:

    char[] theHeader = new char[4];
    for (int i = 0; i < 4; i++) {
      theHeader[i] = PApplet.parseChar(abs(b[i]));
    }
    String hdr = new String(theHeader);
    if ( !hdr.equals("ILDA") )
    {
      status.add("Error: file not an Ilda file. Loading cancelled.");
      status.add("Expected \"ILDA\", found \"" + hdr + "\"");
      b = new byte[0];
      return null;
    }

    //Retrieve where "ILDA" is found inside the file:

    framePositions = getFramePositions();
    //This actually returns the number of headers, and is normally one more than the real number of frames


      //This should never be true, because there was already a check if the file starts with an Ilda string
    if (framePositions == null)
    {
      status.add("No frames found.");
      return null;
    }

    Frame frame = new Frame();

    //If there is only one header, read until the end
    if (framePositions.size() == 1)
    {
      frame = readFrame(0, b.length-1);
      if (frame != null) theFrames.add(frame);
    } else
    {
      //In case of multiple headers, read from current to next header
      //This is actually a bad way to do it because "ILDA" can occur by accident inside the data
      //Though as this chance is rare I decided to take the risk
      //And by "rare" I mean one in 72 quadrillion (1/256^7) for each byte
      //If you ever encounter such a frame, I'll send you a cookie
      for (int i = 1; i<framePositions.size (); i++) 
      {
        //Skip to next ILDA occurence when ILDA occurs in the header
        if (framePositions.get(i) - framePositions.get(i-1) <= 32 && (i+1) < framePositions.size())
        {
          frame = readFrame(framePositions.get(i-1), framePositions.get(i+1));
          if (frame != null) theFrames.add(frame);
        } else
        {
          //Read the frame between this and the next header
          frame = readFrame(framePositions.get(i-1), framePositions.get(i));
          if (frame != null) theFrames.add(frame);
        }
      }
    }
    return theFrames;
  }

  //Read the file and convert them to Frames, which get added to the frames ArrayList
  public void readFile()
  {
    ArrayList<Frame> newFrames = getFramesFromBytes();
    for (Frame frame : newFrames)
    {
      frames.add(frame);
    }

    status.add("Loaded file. " + framePositions.size() + " ILDA header(s) detected.");
  }

  //Where can "ILDA" be found in the file?

  public IntList getFramePositions()
  {
    IntList positions = new IntList();
    for (int j=0; j<b.length-6; j++)
    {
      if (PApplet.parseChar(b[j]) == 'I' && PApplet.parseChar(b[j+1]) == 'L' && PApplet.parseChar(b[j+2]) == 'D' && PApplet.parseChar(b[j+3]) == 'A' && b[j+4] == 0 && b[j+5] == 0 && b[j+5] == 0)
      {
        positions.append(j);
      }
    }
    return positions;
  }

  //Read the file between the indices offset and end

  public Frame readFrame(int offset, int end)
  {

    if (offset > end-32)
    {
      println("Invalid frame");
      return null;
    }
    if (offset >= b.length - 32)
    {
      return null;
    }

    if (end >= b.length)
    {
      return null;
    }

    //Check if it does read ILDA (if it doesn't, check getFramePositions() ):
    char[] theHeader = new char[4];
    for (int i = 0; i < 4; i++) {
      theHeader[i] = PApplet.parseChar(abs(b[i]));
    }
    String hdr = new String(theHeader);
    if ( !hdr.equals("ILDA") )
    {
      status.add("Error: file not an Ilda file. Loading cancelled.");
      status.add("Expected \"ILDA\", found \"" + hdr + "\"");
      return null;
    }

    //Read header data:

    //Bytes 8-15: frame name
    char[] name = new char[8];
    for (int i = 0; i < 8; i++) {
      name[i] = PApplet.parseChar(abs(b[i+8+offset]));
    } 

    //Bytes 16-23: company name
    char[] company = new char[8];
    for (int i = 0; i < 8; i++) {
      company[i] = PApplet.parseChar(abs(b[i+16+offset]));
    } 

    //Bytes 24-25: point count in frames or total colours in palettes
    byte[] pointCountt = new byte[2];
    pointCountt[0] = b[24+offset];
    pointCountt[1] = b[25+offset];

    //Bytes 26-27: frame number in frames or palette number in palettes
    byte[] frameNumber = new byte[2];
    frameNumber[0] = b[26+offset];
    frameNumber[1] = b[27+offset];

    //Unsupported format detection:
    if (PApplet.parseInt(b[7+offset]) != 0 && PApplet.parseInt(b[7+offset]) != 1 && PApplet.parseInt(b[7+offset]) != 2 && PApplet.parseInt(b[7+offset]) != 4 && PApplet.parseInt(b[7+offset]) != 5)
    {
      status.add("Unsupported file format: " + PApplet.parseInt(b[7+offset]));
      return null;
    }

    //Is this a palette or a frame? 2 = palette, rest = frame
    if ( PApplet.parseInt(b[7+offset]) == 2)
    {
      status.add("Palette included");
      Palette palette = new Palette();

      palette.name = new String(name);
      palette.companyName = new String(company);
      palette.totalColors = unsignedShortToInt(pointCountt);

      //Byte 30: scanner head.
      palette.scannerHead = PApplet.parseInt(b[30+offset]);

      palette.formHeader();

      // ILDA V2: Palette information

      for (int i = 32+offset; i<end; i+=3)
      {
        palette.addColour(PApplet.parseInt(b[i]), PApplet.parseInt(b[i+1]), PApplet.parseInt(b[i+2]));
      }


      palettes.add(palette);
      activePalette = palettes.size()-1;
      return null;
    } else
    {
      Frame frame = new Frame();  //Frame(this);      <- remains here as a symbol of how not to program

      //Byte 7 = Ilda file version
      frame.ildaVersion = PApplet.parseInt(b[7+offset]);

      //Information previously read out (because palettes also have them):
      frame.frameName = new String(name);
      frame.companyName = new String(company);
      frame.pointCount = unsignedShortToInt(pointCountt);
      frame.frameNumber = unsignedShortToInt(frameNumber);

      if (frame.frameName.equals("EastrEgg") && frame.companyName.equals("IldaView")) status.add("Congratulations, you found an egg!");

      //Bytes 28-29: total number of frames (not used in palettes)
      byte[] numberOfFrames = new byte[2];
      numberOfFrames[0] = b[28+offset];
      numberOfFrames[1] = b[29+offset];
      frame.totalFrames = unsignedShortToInt(numberOfFrames);

      //Byte 30: scanner head. 
      frame.scannerHead = PApplet.parseInt(b[30+offset]);

      frame.formHeader();

      // Read the points:

      // ILDA V0 (3D, Palettes)
      if (b[7+offset] == 0)
      {
        frame.palette = true;
        for (int i = 32+offset; i < end; i += 8)
        {
          if (!(i >= b.length-8))
          {
            byte[] x = new byte[2];
            x[0] = b[i];
            x[1] = b[i+1];
            float X = PApplet.parseFloat(unsignedShortToInt(x));
            byte[] y = new byte[2];
            y[0] = b[i+2];
            y[1] = b[i+3];
            float Y = PApplet.parseFloat(unsignedShortToInt(y));
            byte[] z = new byte[2];
            z[0] = b[i+4];
            z[1] = b[i+5];
            float Z = PApplet.parseFloat(unsignedShortToInt(z));

            X = map(X, -32768, 32767, 0, width);
            Y = map(Y, 32768, -32767, 0, height);
            Z = map(Z, 32768, -32768, 0, depth);

            String statusString = binary(b[i+6])+binary(b[i+7]);
            boolean bl = false;
            if (statusString.charAt(1) == '1') bl = true;

            Point point = new Point(X, Y, Z, PApplet.parseInt(b[i+7]), bl);
            frame.points.add(point);
          }
        }

        frame.palettePaint(getActivePalette());
      }


      // ILDA V1: 2D, Palettes
      if (b[7+offset] == 1)
      {
        frame.palette = true;
        for (int i = 32+offset; i < end; i+=6)
        {
          if (!(i >= b.length-6))
          {
            byte[] x = new byte[2];
            x[0] = b[i];
            x[1] = b[i+1];
            float X = PApplet.parseFloat(unsignedShortToInt(x));
            byte[] y = new byte[2];
            y[0] = b[i+2];
            y[1] = b[i+3];
            float Y = PApplet.parseFloat(unsignedShortToInt(y));
            X = map(X, -32768, 32767, 0, width);
            Y = map(Y, 32768, -32767, 0, height);

            String statusString = binary(b[i+4])+binary(b[i+5]);
            boolean bl = false;
            if (statusString.charAt(1) == '1') bl = true;


            Point point = new Point(X, Y, depth/2, PApplet.parseInt(b[i+5]), bl);
            frame.points.add(point);
          }
        }

        frame.palettePaint(getActivePalette());
      }

      // ILDA V4: 3D, BGR
      if (b[7+offset] == 4)
      {
        for (int i = 32+offset; i < end; i+=10)
        {
          if (!(i >= b.length-10))
          {
            byte[] x = new byte[2];
            x[0] = b[i];
            x[1] = b[i+1];
            float X = PApplet.parseFloat(unsignedShortToInt(x));
            byte[] y = new byte[2];
            y[0] = b[i+2];
            y[1] = b[i+3];
            float Y = PApplet.parseFloat(unsignedShortToInt(y));
            byte[] z = new byte[2];
            z[0] = b[i+4];
            z[1] = b[i+5];
            float Z = PApplet.parseFloat(unsignedShortToInt(z));

            X = map(X, -32768, 32767, 0, width);
            Y = map(Y, 32768, -32767, 0, height);
            Z = map(Z, -32768, 32767, 0, depth);

            String statusString = binary(b[i+6]);
            boolean bl = false;
            if (statusString.charAt(1) == '1') bl = true;



            Point point = new Point(X, Y, Z, abs(PApplet.parseInt(b[i+9])), abs(PApplet.parseInt(b[i+8])), abs(PApplet.parseInt(b[i+7])), bl);
            frame.points.add(point);
          }
        }
      }

      //ILDA V5: 2D, BGR values
      //Why not RGB? Because reasons
      if (b[7+offset] == 5)
      {
        for (int i = 32+offset; i < end; i+=8)
        {
          if (!(i >= b.length-8))
          {
            byte[] x = new byte[2];
            x[0] = b[i];
            x[1] = b[i+1];
            float X = PApplet.parseFloat(unsignedShortToInt(x));
            byte[] y = new byte[2];
            y[0] = b[i+2];
            y[1] = b[i+3];
            float Y = PApplet.parseFloat(unsignedShortToInt(y));

            X = map(X, -32768, 32767, 0, width);
            Y = map(Y, 32768, -32767, 0, height);

            String statusString = binary(b[i+4]);
            boolean bl = false;
            if (statusString.charAt(1) == '1') bl = true;

            Point point = new Point(X, Y, depth/2, abs(PApplet.parseInt(b[i+7])), abs(PApplet.parseInt(b[i+6])), abs(PApplet.parseInt(b[i+5])), bl);
            frame.points.add(point);
          }
        }
      }

      return frame;
    }
  }

  //Thanks heroic!

  public final int unsignedShortToInt(byte[] b)
  {

    /*
  [02:02]  heroic  | is bitwise or
     [02:02]  heroic  << is bitwise shift left
     [02:06]  heroic  cmb: the & 0xff in the code I pasted (the method version) is defeating sign extension and causing your negative values to disappear
     */
    if ( b.length != 2)
    {
      throw new IllegalArgumentException();
    }
    int i = 0;
    i |= b[0] ;
    i <<= 8;
    i |= b[1] & 0xff;
    return i;
  }
}


class Frame
{

  /*
   * A Frame stores all its Points and has some methods to display them
   * and to save header data
   */

  ArrayList<Point> points = new ArrayList<Point>();
  ;          //The Points in the Frame


  int ildaVersion;    //Data retrieved from header
  String frameName;
  String companyName;
  int pointCount;
  int frameNumber;
  int totalFrames;
  int scannerHead;
  StringList hoofding = new StringList(); //Data now in a nice StringList to display 
  boolean palette = false;

  Frame()
  {
  }

  Frame(Frame frame)
  {
    this.points = new ArrayList<Point>(frame.points.size());
    for (Point point : frame.points)
    {
      this.points.add(point.clone(point));
    }
    this.ildaVersion = frame.ildaVersion;
    if (frame.frameName != null) this.frameName = new String(frame.frameName);
    else frameName = "";
    if (frame.companyName != null) this.companyName = new String(frame.companyName);
    else companyName = "IldaViewer";
    this.pointCount = frame.pointCount;
    this.frameNumber = frame.frameNumber;
    this.totalFrames = frame.totalFrames;
    this.scannerHead = frame.scannerHead;
    this.palette = frame.palette;
  }

  public Frame clone()
  {
    Frame frame = new Frame(this);
    return frame;
  }


  //This method changes the colour of each point according to the active palette
  public void palettePaint(Palette palette)
  {
    for ( Point point : points)
    {
      point.setColourFromPalette(palette);
    }
  }

  //This puts all the header information inside the hoofding StringList

  public void formHeader()
  {
    hoofding.clear();
    hoofding.append("Ilda version " + ildaVersion);
    hoofding.append("Frame: " + frameName);
    hoofding.append("Company: " + companyName);
    hoofding.append("Point count: " + pointCount);
    hoofding.append("Frame number: " + frameNumber);
    hoofding.append("Total frames: " + totalFrames);
    hoofding.append("Scanner head: " + scannerHead);
  }

  //Returns the real point count

  public int getPointCount()
  {
    return points.size();
  }

  //By default, draw the frame with visible blanking points
  public void drawFrame()
  {
    drawFrame(true);
  }

  //Displays all the points inside this frame with a line in between them:



  public void drawFrame(boolean showBlankedPoints)
  {

    if (!loading)
    {
      boolean firstPoint = true;
      float oldpositionx = 0; 
      float oldpositiony = 0;
      float oldpositionz = 0;
      for (Point point : points)
      {
        if (showBlankedPoints || !point.blanked) point.displayPoint();


        PVector position = point.getPosition();

        if (!firstPoint)
        {
          strokeWeight(1);  
          if (!showBlankedPoints && point.blanked) stroke(0);   
          else
          {   
            line(position.x, position.y, position.z, oldpositionx, oldpositiony, oldpositionz);
          }
          oldpositionx = position.x;
          oldpositiony = position.y;
          oldpositionz = position.z;
        } else
        {
          firstPoint = false;
          oldpositionx = position.x;
          oldpositiony = position.y;
          oldpositionz = position.z;
        }
      }
    } else println("Warning: tried to display while loading file");
  }

  public void drawFrame(float offX, float offY, float offZ, float sizeX, float sizeY, float sizeZ)
  {
    drawFrame(offX, offY, offZ, sizeX, sizeY, sizeZ, true, true);
  }



  public void drawFrame(float offX, float offY, float offZ, float sizeX, float sizeY, float sizeZ, boolean showBlankedPoints, boolean clipping)
  {
    boolean firstPoint = true;
    float oldpositionx = 0; 
    float oldpositiony = 0;
    float oldpositionz = 0;
    for (Point point : points)
    {
      PVector position = point.getPosition();

      float x = map(position.x, 0, width, 0, sizeX) + offX;
      float y = map(position.y, 0, height, 0, sizeY) + offY;
      float z = map(position.z, 0, depth, 0, sizeZ) + offZ;

      if (clipping)
      {
        if (x < offX) x = offX;
        if (y < offY) y = offY;
        if (z < offZ) z = offZ;
        if (x > offX + sizeX) x = offX + sizeX;
        if (y > offY + sizeY) y = offY + sizeY;
        if (z > offZ + sizeZ) z = offZ + sizeZ;
      }

      if (showBlankedPoints || !point.blanked)
      {
        strokeWeight(3);
        stroke(point.colour);
        if (point.blanked) stroke(75, 75, 75);
        point(x, y, z);
      }



      if (!firstPoint)
      {
        strokeWeight(1);  
        if (!showBlankedPoints && point.blanked) stroke(0);   
        else
        {   
          line(x, y, z, oldpositionx, oldpositiony, oldpositionz);
        }
        oldpositionx = x;
        oldpositiony = y;
        oldpositionz = z;
      } else
      {
        firstPoint = false;
        oldpositionx = x;
        oldpositiony = y;
        oldpositionz = z;
      }
    }
  }

  //Translates all points with a PVector
  public void translate(PVector newposition)
  {
    for (Point point : points)
    {
      point.position.add(newposition);
    }
  }
  
  public void fitColourIndexWithPalette(Palette palette)
  {
    for (Point point : points)
        {
          point.paletteIndex = point.getBestFittingPaletteColourIndex(palette);
        }
  }

  public void merge(Frame frame)
  {
    points.addAll(frame.points);
  }

  public void merge(Frame frame, float[] mergedInformation)
  {
    if (mergedInformation.length != 10) return;

    // 0: frame header
    if (mergedInformation[0] != 0)
    {
      ildaVersion = frame.ildaVersion;
      frameName = frame.frameName;
      companyName = frame.companyName;
      frameNumber = frame.frameNumber;
      scannerHead = frame.scannerHead;
    }

    // 1: Point number
    if (mergedInformation[1] != 0)
    {
      if (points.size() < frame.points.size())
      {
        for (int i = points.size(); i < frame.points.size(); i++)
        {
          points.add(frame.points.get(i));
        }
      } else
      {
        for (int i = points.size()-1; i >= frame.points.size(); i--)
        {
          points.remove(i);
        }
      }
    }

    // 2: X
    if (mergedInformation[2] != 0)
    {
      for (int i = 0; i < min(points.size(), frame.points.size()); i++)
      {
        points.get(i).position.x = frame.points.get(i).position.x;
      }
    }

    // 3: R
    if (mergedInformation[3] != 0)
    {
      for (int i = 0; i < min(points.size(), frame.points.size()); i++)
      {
        points.get(i).colour = color((frame.points.get(i).colour >> 16) & 0xFF, (points.get(i).colour >> 8) & 0xFF, points.get(i).colour & 0xFF);
      }
    }

    // 4: Y
    if (mergedInformation[4] != 0)
    {
      for (int i = 0; i < min(points.size(), frame.points.size()); i++)
      {
        points.get(i).position.y = frame.points.get(i).position.y;
      }
    }

    // 5: G
    if (mergedInformation[5] != 0)
    {
      for (int i = 0; i < min(points.size(), frame.points.size()); i++)
      {
        points.get(i).colour = color((points.get(i).colour >> 16) & 0xFF, (frame.points.get(i).colour >> 8) & 0xFF, points.get(i).colour & 0xFF);
      }
    }

    // 6: Z
    if (mergedInformation[6] != 0)
    {
      for (int i = 0; i < min(points.size(), frame.points.size()); i++)
      {
        points.get(i).position.z = frame.points.get(i).position.z;
      }
    }

    // 7: B
    if (mergedInformation[7] != 0)
    {
      for (int i = 0; i < min(points.size(), frame.points.size()); i++)
      {
        points.get(i).colour = color((points.get(i).colour >> 16) & 0xFF, (points.get(i).colour >> 8) & 0xFF, frame.points.get(i).colour & 0xFF);
      }
    }

    // 8: blanking
    if (mergedInformation[8] != 0)
    {
      for (int i = 0; i < min(points.size(), frame.points.size()); i++)
      {
        points.get(i).blanked = frame.points.get(i).blanked;
      }
    }

    // 9: palette index
    if (mergedInformation[9] != 0)
    {
      for (int i = 0; i < min(points.size(), frame.points.size()); i++)
      {
        points.get(i).paletteIndex = frame.points.get(i).paletteIndex;
      }
    }

    pointCount = points.size();
    formHeader();
  }

  public String toString()
  {
    return "Name: " + frameName + "  | Company: " + companyName + "  | Points: " + pointCount;
  }
}

public float[][] calculateRotationMatrix(float theta, float phi, float psi)
  {
    float[][] R = new float[3][3]; //Rotation matrix

    //First row:
    R[0][0] = cos(phi)*cos(psi);
    R[0][1] = cos(phi)*sin(psi);
    R[0][2] = -sin(phi);

    //Second row:
    R[1][0] = sin(theta)*sin(phi)*cos(psi) - cos(theta)*sin(psi);
    R[1][1] = sin(theta)*sin(phi)*sin(psi) + cos(theta)*cos(psi);
    R[1][2] = sin(theta)*cos(phi);

    //Third row:
    R[2][0] = cos(theta)*sin(phi)*cos(psi) + sin(theta)*sin(psi);
    R[2][1] = cos(theta)*sin(phi)*sin(psi) - sin(theta)*cos(psi);
    R[2][2] = cos(theta)*cos(phi);

    return R;
  }



// Fields for Frame Editor tab:

boolean frameditor = false;   //Frame editor mode
FrameEditor frameEditor;
CheckBox controlsVisible;
int[] ctrlsVis;

public void beginFrameEditor()
{
  frameditor = true;
  if (frameEditor == null) frameEditor = new FrameEditor();
  setFrameEditorControls();
}

public void exitFrameEditor()
{
  frameditor = false;
}

public void setFrameEditorControls()
{
  try
  {
    if (ctrlsVis.length != controlsVisible.getArrayValue().length) println("Error: control panel number mismatch");
    float[] cV = controlsVisible.getArrayValue();

    for (int i = 0; i < ctrlsVis.length; i++)
    {
      if ((int) cV[i] != ctrlsVis[i])
      {
        PVector pos = findEmptyGuiSpot();
        switch(i)
        {

        case 0:
          cp5.getGroup("framePicker").setPosition(pos.x, pos.y);
          cp5.getGroup("framePicker").setVisible(PApplet.parseBoolean((int) cV[i]));
          break;
        case 1:
          cp5.getGroup("rasterImage").setPosition(pos.x, pos.y);
          cp5.getGroup("rasterImage").setVisible(PApplet.parseBoolean((int) cV[i]));
          break;
        case 2:
          cp5.getGroup("rotationControl").setPosition(pos.x, pos.y);
          cp5.getGroup("rotationControl").setVisible(PApplet.parseBoolean((int) cV[i]));
          break;
        case 3:
          cp5.getGroup("sizeControl").setPosition(pos.x, pos.y);
          cp5.getGroup("sizeControl").setVisible(PApplet.parseBoolean((int) cV[i]));
          break;
        case 4:
          cp5.getGroup("positionControl").setPosition(pos.x, pos.y);
          cp5.getGroup("positionControl").setVisible(PApplet.parseBoolean((int) cV[i]));
          break;
        case 5:
          cp5.getGroup("perspective").setPosition(pos.x, pos.y);
          cp5.getGroup("perspective").setVisible(PApplet.parseBoolean((int) cV[i]));
          break;
        }
        ctrlsVis[i] = (int) cV[i];
      }
    }
  }
  catch(Exception e)  //necessary because this method gets called upon startup before the GUI elements are initialized
  {
  }
}

public PVector findEmptyGuiSpot()
{
  //Ugh! Why can't things be simple! But it works :)
  Object[] crls = cp5.getAll().toArray();
  PVector currPos = new PVector(150, 35);
  for (int i = 0; i < crls.length; i++)
  {
    ControllerInterface conrl;
    if (crls[i] instanceof ControllerInterface)  
    {
      conrl = (ControllerInterface) crls[i];

      if (conrl.getName() != null )
      {
        try
        {
          if (conrl.getTab().getName().equals("framed"))
          {
            if (abs(conrl.getPosition().x -currPos.x) < 20 && abs(conrl.getPosition().y -currPos.y ) < 20  && conrl.isVisible())
            {
              //Position is already taken!
              currPos.x += 130;
              if (currPos.x > width - 140) 
              {
                currPos.y += 100;
                currPos.x = 150;
              }
              i = 0;
            }
          }
        }
        catch(Exception e)
        {
        }
      }
    }
  }
  return currPos;
}

public void openFramedImage()
{
  status.clear();
  status.add("Select an image to load in as a background image");
  selectInput("Select an image file to load in as a background image", "backgroundImageSelected");
}

public void backgroundImageSelected(File selection) {
  PImage img;


  if (selection == null) {
    status.clear();
    status.add("Window was closed or the user hit cancel.");
    return;
  } else {
    if (!selection.exists())
    {
      status.clear();
      status.add("Error when trying to read file " + selection.getAbsolutePath());
      status.add("File does not exist.");
      return;
    }
    status.add("Loading image " + selection.getAbsolutePath());
    try {
      img = loadImage(selection.getAbsolutePath());
    }
    catch(Exception e)
    {
      status.add("Invalid file");
      return;
    }
    if (img == null) 
    {
      status.add("Error when opening file");
      return;
    }



    if (frameEditor != null) 
    {
      frameEditor.sourceBackgroundImage = img;
      frameEditor.backgroundImage = img;
      thread("setSizeBackgroundFrameEd");
    }
  }
}

public void setSizeBackgroundFrameEd()
{
  if (frameEditor.backgroundImage.width < frameEditor.backgroundImage.height && frameEditor.backgroundImage.height > height) frameEditor.backgroundImage.resize(0, height);
  if (frameEditor.backgroundImage.width > frameEditor.backgroundImage.height && frameEditor.backgroundImage.width > width) frameEditor.backgroundImage.resize(width, 0);

  frameEditor.imgsx = frameEditor.backgroundImage.width;
  frameEditor.imgsy = frameEditor.backgroundImage.height;
  frameEditor.imgx = (int) (width*0.5f-frameEditor.backgroundImage.width*0.5f);
  frameEditor.imgy = (int) (height*0.5f-frameEditor.backgroundImage.height*0.5f);
}

public void hideFramedImage(boolean value)
{
  frameEditor.showBackground = !value;
}

public void positionFramedImage()
{
  cursor(MOVE);
  frameEditor.moveImage = true;
}

public void listFrameEd(boolean value)
{
  frameEditor.listFrames = value;
  if (value)
  {

    if (!frames.isEmpty())
    {
      frameEditor.frame = new EditingFrame(frames.get(activeFrame));
    }
  }
  int emptySpot = (int) findEmptyGuiSpot().y+150;
  if (emptySpot > height-150) emptySpot = height-150;
  frameEditor.pickerY = emptySpot;
}

public void sizeFramedImage(boolean value)
{

  cp5.getController("sizeXFramedImage").setVisible(value);
  cp5.getController("sizeYFramedImage").setVisible(value);
  cp5.getController("sizeXYFramedImage").setVisible(value);
}

public void sizeXYFramedImage(float value)
{
  if (frameEditor == null) return;

  if (value> frameEditor.maxs)
  {
    Slider sl = (Slider) cp5.getController("sizeXYFramedImage");
    sl.setRange(sl.getMin(), sl.getMax()+0.01f);
    frameEditor.maxs = sl.getMax()*0.9f;
    sl.getCaptionLabel().alignX(CENTER);
  }
  if (value < frameEditor.mins)
  {
    Slider sl = (Slider) cp5.getController("sizeXYFramedImage");
    sl.setRange(sl.getMin()-0.01f, sl.getMax());
    frameEditor.mins = sl.getMin()*0.9f;
    sl.getCaptionLabel().alignX(CENTER);
  }

  frameEditor.resizeBackground();
}

public void sizeXFramedImage(float value)
{
  if (frameEditor == null) return;

  if (value> frameEditor.maxsx)
  {
    Slider sl = (Slider) cp5.getController("sizeXFramedImage");
    sl.setRange(sl.getMin(), sl.getMax()+0.01f);
    frameEditor.maxsx = sl.getMax()*0.9f;
    sl.getCaptionLabel().alignX(CENTER);
  }
  if (value < frameEditor.minsx)
  {
    Slider sl = (Slider) cp5.getController("sizeXFramedImage");
    sl.setRange(sl.getMin()-0.01f, sl.getMax());
    frameEditor.minsx = sl.getMin()*0.9f;
    sl.getCaptionLabel().alignX(CENTER);
  }

  frameEditor.resizeBackground();
}

public void sizeYFramedImage(float value)
{
  if (frameEditor == null) return;

  if (value> frameEditor.maxsy)
  {
    Slider sl = (Slider) cp5.getController("sizeYFramedImage");
    sl.setRange(sl.getMin(), sl.getMax()+0.01f);
    frameEditor.maxsy = sl.getMax()*0.9f;
    sl.getCaptionLabel().alignX(CENTER);
  }
  if (value < frameEditor.minsy)
  {
    Slider sl = (Slider) cp5.getController("sizeYFramedImage");
    sl.setRange(sl.getMin()-0.01f, sl.getMax());
    frameEditor.minsy = sl.getMin()*0.9f;
    sl.getCaptionLabel().alignX(CENTER);
  }

  frameEditor.resizeBackground();
}

public void recolourFramedImage()
{
  if (frameEditor == null) return;
  frameEditor.recolourFromImage();
}

public void previousFrameEd() //manually skip to previous frame
{
  previousFrame();
  frameEditor.frame = new EditingFrame(frames.get(activeFrame));
}

public void nextFrameEd() //manually skip to next frame
{
  nextFrame();
  frameEditor.frame = new EditingFrame(frames.get(activeFrame));
}

public void firstFrameEd()
{
  firstFrame();
  frameEditor.frame = new EditingFrame(frames.get(activeFrame));
}

public void lastFrameEd()
{
  lastFrame();
  frameEditor.frame = new EditingFrame(frames.get(activeFrame));
}

public void rotationX(float value)
{
  if (frameEditor != null) frameEditor.rotX = value;
}

public void rotationY(float value)
{
  if (frameEditor != null) frameEditor.rotY = value;
}

public void rotationZ(float value)
{
  if (frameEditor != null) frameEditor.rotZ = value;
}

public void zoom(float value)
{
  if (frameEditor != null) 
  {
    frameEditor.zoomFactor = value;
    frameEditor.zooming = true;
  }
}

public void resetZoom()
{
  if (frameEditor != null) frameEditor.scale = 1;
  cp5.getController("zoom").setValue(0);
}

public void viewPerspective(float value)
{
  if (frameEditor != null)
  {
    status.clear();
    if (value == 0) status.add("Orthographic mode");
    else status.add("Perspective mode");

    frameEditor.perspective = value;
  }
}

class FrameEditor
{
  EditingFrame frame;
  PImage backgroundImage, sourceBackgroundImage;
  boolean showBackground = true;
  boolean moveImage = false;
  boolean movingImage = false;
  int movingImageOffX, movingImageOffY, imgx, imgy, imgsx, imgsy;
  float maxsx = 1.25f;
  float maxsy = 1.25f;
  float minsx = -1.25f;
  float minsy = -1.25f;
  float maxs = 1.25f;
  float mins = -1.25f;
  boolean listFrames = false;
  int frameSize = 100;
  int xoffset = 5;
  int visibleFrames = PApplet.parseInt(width/frameSize);
  int pickedFrame = activeFrame;
  boolean scrolling = false;
  int prevX = 0;
  boolean startscrolling = true;
  int pickerY = 150;
  float rotX, rotY, rotZ;
  float scale = 1;
  float zoomFactor = 0;
  boolean zooming = false;
  float perspective = 0;
  boolean rotating = false;
  float prevRotX, prevRotY;


  FrameEditor()
  {
  }

  FrameEditor(Frame frame)
  {
    this.frame = (EditingFrame) frame;
  }

  public void update()
  {
    if (moveImage && mousePressed && !movingImage) 
    {
      movingImage = true;
      movingImageOffX = mouseX - imgx;
      movingImageOffY = mouseY - imgy;
    }
    if (movingImage && !mousePressed)
    {
      movingImage = false;
      moveImage = false;
      cursor(ARROW);
    }
    if (movingImage)
    {
      imgx = mouseX - movingImageOffX;
      imgy = mouseY - movingImageOffY;
    }
    if (backgroundImage != null && showBackground && !listFrames) image(backgroundImage, imgx, imgy);
    if (frame != null && !listFrames) frame.display(0, 0, scale, scale, rotX, rotY, rotZ, perspective);
    if (listFrames)
    {
      listFrames();
    }
    if (zooming) scale += zoomFactor;
    if (zooming && !mousePressed) 
    {
      zooming = false;
      cp5.getController("zoom").setValue(0);
    }
    if (mousePressed && keyPressed && keyCode == CONTROL && !rotating)
    {
      rotating = true;
      prevRotX = mouseY-rotX*width;
      prevRotY = mouseX-rotY*height;
    }
    if (rotating && !mousePressed) rotating = false;
    if (rotating)
    {
      rotX = (mouseY - prevRotX)/width;
      rotY = (mouseX - prevRotY)/height;
      cp5.getController("rotationX").setValue(rotX);
      cp5.getController("rotationY").setValue(rotY);
    }
  }


  public void resizeBackground()
  {
    if (sourceBackgroundImage == null) return;

    int newSizeX = (int) (imgsx*cp5.getController("sizeXYFramedImage").getValue()*cp5.getController("sizeXFramedImage").getValue());
    int newSizeY = (int) (imgsy*cp5.getController("sizeXYFramedImage").getValue()*cp5.getController("sizeYFramedImage").getValue());

    imgx += (backgroundImage.width-abs(newSizeX))*0.5f;
    imgy += (backgroundImage.height-abs(newSizeY))*0.5f;

    int sx = min(0, imgx);
    int sy = min(0, imgy);

    int ssx = min(sourceBackgroundImage.width, width);
    int ssy = min(sourceBackgroundImage.height, height);

    backgroundImage = createImage(abs(newSizeX), abs(newSizeY), RGB);
    backgroundImage.copy(sourceBackgroundImage, sx, sy, ssx, ssy, 0, 0, abs(newSizeX), abs(newSizeY));

    if (newSizeX < 0)
    {
      PImage throwaway = createImage(backgroundImage.width, backgroundImage.height, RGB);
      throwaway.copy(backgroundImage, 0, 0, backgroundImage.width, backgroundImage.height, 0, 0, backgroundImage.width, backgroundImage.height);

      throwaway.loadPixels();
      backgroundImage.loadPixels();

      for (int j = 0; j < backgroundImage.height; j++)
      {
        for (int i = 0; i < backgroundImage.width; i++)
        {

          backgroundImage.pixels[backgroundImage.width-i-1 + j*backgroundImage.width] = throwaway.pixels[i+j*backgroundImage.width];
        }
      }
    }

    if (newSizeY < 0)
    {
      PImage throwaway = createImage(backgroundImage.width, backgroundImage.height, RGB);
      throwaway.copy(backgroundImage, 0, 0, backgroundImage.width, backgroundImage.height, 0, 0, backgroundImage.width, backgroundImage.height);

      throwaway.loadPixels();
      backgroundImage.loadPixels();

      for (int j = 0; j < backgroundImage.height; j++)
      {
        for (int i = 0; i < backgroundImage.width; i++)
        {

          backgroundImage.pixels[i + (backgroundImage.height-1-j)*backgroundImage.width] = throwaway.pixels[i+j*backgroundImage.width];
        }
      }
    }

    backgroundImage.updatePixels();
  }

  public void recolourFromImage()
  {
    //println(imgx, imgy);

    backgroundImage.loadPixels();
    println(backgroundImage.pixels.length + " " + backgroundImage.width + " " + backgroundImage.height + " " + imgx + " " + imgy);
    for (EditingPoint point : frame.points)
    {

      //println((int) (point.position.x+imgx+width*(point.position.y+imgy)));
      try
      {
        PVector position = point.position;
        PVector positionInImage = new PVector(point.position.x - imgx, point.position.y - imgy);
        int index = (int) (point.position.x+width*(point.position.y ));
        println("index " + index + " of " + backgroundImage.pixels.length + " at " + positionInImage.x + " " + positionInImage.y);
        point.colour = backgroundImage.pixels[index];
        backgroundImage.pixels[index] = 0;
      }
      catch(Exception e)
      {
        point.colour = 0;
      }
    }
    backgroundImage.updatePixels();
  }

  public void listFrames()
  {

    textAlign(LEFT);
    fill(50);
    noStroke();
    rect(0, pickerY, width, 150);
    if (!frames.isEmpty())
    {
      for (int i = max ( (int) -xoffset/frameSize, 0); i < min(frames.size(), (int) -xoffset/frameSize+visibleFrames+1); i++)
      {
        fill(0);
        noStroke();
        if (i == pickedFrame)
        {
          fill(0);
          strokeWeight(3);
          stroke(255, 255, 0);
        }

        fill(0);
        rect(xoffset+frameSize*i, pickerY+10, 90, 90);
        frames.get(i).drawFrame((float)xoffset+frameSize*i, pickerY+10, 0.0f, 90.0f, 90.0f, 0.0f, false, true);
        if (i == pickedFrame)
        {
          fill(255, 50);
          textFont(f16);
          text("Editing", xoffset + frameSize*i+5, pickerY+30);
        }
      }
    } else
    {
      textFont(f16);
      fill(255, 50);
      text("No frames", 50, pickerY+40);
    }

    if (mousePressed && mouseY > pickerY && mouseY < pickerY+100)
    {
      int chosenFrame = (int) (mouseX-xoffset)/frameSize;
      if (mouseButton == LEFT) 
      {
        pickedFrame = chosenFrame;
        activeFrame = chosenFrame;
        if (activeFrame >= 0 && activeFrame < frames.size()) frame = new EditingFrame(frames.get(activeFrame));
      }
      if (mouseButton == CENTER && !scrolling) 
      {
        scrolling = true;
        prevX = -xoffset + mouseX;
        cursor(MOVE);
      }
    }

    if (!mousePressed && scrolling)
    {
      scrolling = false;
      cursor(ARROW);
    }

    if (scrolling)
    {
      xoffset = mouseX - prevX;
    }

    noStroke();
    textAlign(CENTER);

    fill(127);  
    rect(10, pickerY+110, 35, 25);
    fill(0);
    textFont(f20);
    text("<<", 25, pickerY+128);
    if (mousePressed && mouseX > 10 && mouseX < 45 && mouseY > pickerY+110 && mouseY <pickerY+135) xoffset = 5;

    fill(127);  
    rect(50, pickerY+110, 35, 25);
    fill(0);
    textFont(f20);
    text("<", 65, pickerY+128);
    if (mousePressed && mouseX > 50 && mouseX < 85 && mouseY > pickerY+110 && mouseY <pickerY+135) xoffset += 5;

    fill(127);  
    rect(width-85, pickerY+110, 35, 25);
    fill(0);
    textFont(f20);
    text(">", width-67, pickerY+128);
    if (mousePressed && mouseX > width-85 && mouseX < width-50 && mouseY > pickerY+110 && mouseY <pickerY+135) xoffset -= 5;

    fill(127);  
    rect(width-45, pickerY+110, 35, 25);
    fill(0);
    textFont(f20);
    text(">>", width-27, pickerY+128);
    if (mousePressed && mouseX > width-45 && mouseX < width-10 && mouseY > pickerY+110 && mouseY <pickerY+135) xoffset = -frames.size() * frameSize + frameSize * visibleFrames;

    fill(127);
    float scrollX = map(xoffset, 0, -frames.size()*frameSize, 100, width-100);
    rect(scrollX, pickerY+110, 10, 25);      
    if (mousePressed && mouseX > scrollX && mouseX < scrollX+10 && mouseY > pickerY+110 && mouseY <pickerY+135) startscrolling = true;
    if (startscrolling)
    {
      xoffset = (int) map(mouseX, 100, width-100, 0, (float)-frames.size()*frameSize);
      if (xoffset > 5) xoffset = 5;
      if (xoffset < -frames.size()*frameSize+ frameSize * visibleFrames) xoffset = -frames.size()*frameSize+ frameSize * visibleFrames;
    }

    if (startscrolling && !mousePressed) startscrolling = false;
  }
}


class EditingFrame extends Frame
{
  ArrayList<EditingPoint> points = new ArrayList<EditingPoint>();
  EditingFrame()
  {
  }

  EditingFrame(Frame frame)
  {
    super(frame);
    for (int i = 0; i< frame.points.size (); i++)
    {
      points.add(new EditingPoint(frame.points.get(i)));
    }
  }

  public void display()
  {
    display(0, 0, width, height, 0, 0, 0, 1);
  }

  public void display(int x, int y, float sizex, float sizey, float rotx, float roty, float rotz, float projection)
  {
    //Rescale the angles
    rotx = rotx*TWO_PI;
    roty = roty*TWO_PI;
    rotz = rotz*TWO_PI;

    boolean firstPoint = true;
    float oldpositionx = 0; 
    float oldpositiony = 0;

    float[][] R = calculateRotationMatrix(rotx, roty, rotz);


    for (EditingPoint point : points)
    {
      float xind = point.position.x-width*0.5f;
      float yind = point.position.y-height*0.5f;
      float zind = point.position.z-depth*0.5f;

      float xnew = sizex*(R[0][0]*xind + R[0][1]*yind + R[0][2]*zind);
      float ynew = sizey*(R[1][0]*xind + R[1][1]*yind + R[1][2]*zind);
      if (projection != 0)    //perspective
      {
        float znew = R[2][0]*xind + R[2][1]*yind + R[2][2]*zind;  
        znew = znew / depth;
        xnew *= znew/(projection);
        ynew *= znew/(projection);
      }  

      xnew += width*0.5f;
      ynew += height*0.5f;

      point.displayPoint(xnew, ynew, 0);

      if (!firstPoint)
      {
        strokeWeight(1);  
        line(xnew, ynew, 0, oldpositionx, oldpositiony, 0);
      } else
      {
        firstPoint = false;
      }
      oldpositionx = xnew;
      oldpositiony = ynew;
    }
  }
}

class EditingPoint extends Point
{
  boolean selected = false;

  EditingPoint(Point point)
  {
    super(point);
  }

  public void displayPoint(int x, int y, int z)
  {
    setPointColour();
    point(x, y, z);
  }

  public void displayPoint(float x, float y, float z)
  {
    setPointColour();
    point(x, y, z);
  }

  public void displayPoint()
  {
    displayPoint(position.x, position.y, position.z);
  }

  public void setPointColour()
  {
    //Colour:
    strokeWeight(3);
    int red, green, blue;
    int x, y;
    if (blanked)
    {
      red = 75;
      blue = 75;
      green = 75;
    } else
    {
      red = (colour >> 16) & 0xFF;  // Faster way of getting red(argb)
      green = (colour >> 8) & 0xFF;   // Faster way of getting green(argb)
      blue = colour & 0xFF;          // Faster way of getting blue(argb)
    }

    if (selected) 
    {
      red = PApplet.parseInt(sin(PApplet.parseFloat(frameCount)/5)*127+128);
      strokeWeight(6);
    }
    stroke(red, green, blue);
  }
}

// Fields for Palette Editor tab:

boolean paletteEditor = false;//Palette editor mode
ListBox paletteList;          //ControlP5 selection list 
PalEditor paleditor;
ColorPicker cp;               //ControlP5 colour picker


//      === PALETTE TAB METHODS AND CP5 CALLBACKS ===

// A beginMode() method should always get called upon entering a tab
public void beginPalettes()
{
  paletteEditor = true;    // A mode should always have a boolean set to true in the beginMode() method
  paleditor = new PalEditor();  // A mode preferrably has a class of which an object is initiated in the beginMode() method

  //Rest are specific methods:
  paleditor.setActivePalette(activePalette);
  cp.setColorValue(palettes.get(paleditor.activePal).colours.get(0).getColour());
  cp5.getController("picker-alpha").setVisible(false);
  status.clear();
  status.add("Palette editor entered");
}

// An exitMode() method should always get called upon leaving a tab, while the corresponding boolean is true
public void exitPalettes()
{
  // The mode boolean should be set to false in here
  paletteEditor = false;
  status.clear();
  status.add("Palette editor exited");
}

public void recolourFrames()
{
  for (Frame frame : frames)
  {
    frame.palettePaint(getActivePalette());
  }
}

public void input(String theText) {
  palettes.get(activePalette).name = theText;
  paleditor.updatePaletteList();
}

public void addPalette()
{
  Palette newPalette = new Palette();
  newPalette.name = " ";
  palettes.add(newPalette);
  paleditor.activePal = palettes.size()-1;
  activePalette = palettes.size()-1;
  paleditor.updatePaletteList();
}

public void removePalette()
{
  if (palettes.size() > 1)
  {
    String thename = palettes.get(activePalette).name;
    palettes.remove(activePalette);
    status.clear();
    status.add("Palette " + thename + " removed.");
  } else 
  {
    status.clear(); 
    status.add("Can't remove all palettes");
  }
  if (activePalette >=palettes.size() ) 
  {
    activePalette = palettes.size()-1;
    paleditor.activePal = palettes.size()-1;
  }
  paleditor.updatePaletteList();
}

public void importPalette()
{
  status.clear();
  selectInput("Select an image file to load in as a palette", "paletteSelected");
}

public void exportPalette()
{
  String pathname = trim(palettes.get(activePalette).name) + ".png";
  File theFile = new File(pathname);
  selectOutput("Select a file to save a palette as image", "paletteOutput", theFile);
}

public void paletteOutput(File selection)
{
  if (selection == null)
  {
    status.clear();
    status.add("Palette export aborted.");
    return;
  }
  String location = selection.getAbsolutePath();
  char[] test = new char[4];
  for (int i = 0; i < 4; i++)
  {
    test[i] = location.charAt(i+location.length()-4);
  }
  String testing = new String(test);
  if ( !testing.equals(".png") )
  {
    location += ".png";
  }
  PImage img = paleditor.getPaletteAsImage();
  img.save(location);

  status.clear(); 
  status.add("Palette succesfully exported on location:");
  status.add(location);
}

public void paletteSelected(File selection) {
  PImage img;


  if (selection == null) {
    status.clear();
    status.add("Window was closed or the user hit cancel.");
    return;
  } else {
    if (!selection.exists())
    {
      status.clear();
      status.add("Error when trying to read file " + selection.getAbsolutePath());
      status.add("File does not exist.");
      return;
    }
    status.add("Loading palette " + selection.getAbsolutePath());
    try {
      img = loadImage(selection.getAbsolutePath());
    }
    catch(Exception e)
    {
      status.add("Invalid file");
      return;
    }
    String fixName = selection.getName();
    char[] fix = new char[fixName.length()];
    for (int i = 0; i < fixName.length (); i++)
    {
      fix[i] = fixName.charAt(i);
    }

    String fixedName = fixName;    
    if ( fix[fixName.length()-4] == '.' && (fix[fixName.length()-3] == 'p' || fix[fixName.length()-3] == 'j') && (fix[fixName.length()-2] == 'n' || fix[fixName.length()-2] == 'p')&& fix[fixName.length()-1] == 'g' )
    {
      String[] outOfNames = split(fixName, '.');
      fixedName = outOfNames[0];
    }
    paleditor.importImageAsPalette(img, fixedName);
    paleditor.activePal = palettes.size()-1;
    activePalette = palettes.size()-1;
  }
}

public void numberOfColours(String theText)
{
  int maxNum = PApplet.parseInt(theText);
  if (maxNum > 256) maxNum = 256;
  if (maxNum < 0) maxNum = 0;
  palettes.get(activePalette).resizePalette(maxNum);

  status.clear();
  status.add("Resized palette "+palettes.get(activePalette).name+" to " + maxNum + " colours.");
}


class PalEditor
{

  int activePal = 0;     //There is already an activePalette global field, maybe this one was a bit redundant.
  int activeCol = 0;     //The colour that was being selected with the mouse
  boolean dontChangeColourMoron=false;    //Getting frustrated when bug fixing

  PalEditor()
  {
    updatePaletteList();
  }

  public void update()
  {
    if (activePal >= 0  || activePal < palettes.size())
    {
      displayPalette(palettes.get(activePal));
    }
    fill(255);
    text(palettes.get(activePal).name, width-150, 460);
  }

  public void updatePaletteList()
  {
    paletteList.clear();
    int i = 0;
    for (Palette palette : palettes)
    {
      paletteList.addItem(palette.name, i++);
    }
  }

  public PImage getPaletteAsImage()
  {
    PImage pg = createImage(palettes.get(activePal).colours.size(), 1, RGB);
    for (int i = 0; i < palettes.get (activePal).colours.size(); i++)
    {
      pg.pixels[i] = palettes.get(activePal).colours.get(i).getColour();
    }
    return pg;
  }

  public void importImageAsPalette(PImage img, String theName)
  {
    if (img == null)
    {
      status.add("Failed to load palette " + theName);
      return;
    }
    Palette palette = new Palette(theName);

    for ( int i = 0; i < min (img.width, 256); i++)
    {
      if (palette.colours.size() < 256) palette.addColour(img.get(i, 0));
    }
    palettes.add(palette);
    activePal = palettes.size()-1;
    status.add("Palette " + palette.name + " loaded.");
    updatePaletteList();
  }

  //A bit of a bad name, should be called "select colour"
  //It checks if you clicked on a colour square in the palette display
  //then sets that colour active
  public void editPalette(int x, int y)
  {
    int activeX = -1;
    int activeY = -1;
    for (int i = 0; i < 16; i++)
    {
      if (x >= width-425+25*i && x <= width-425+25*i+20)
      {
        activeX = i;
      }
    }

    for (int i = 0; i < 16; i++)
    {
      if (y >= 25+25*i && y <= 25+25*i +20)
      {
        activeY = i;
      }
    }

    if ( activeX == -1 || activeY == -1)
    {
      return;
    } else
    {
      int activeColr = activeX + activeY*16;
      if (activeColr >= 0 && activeColr < palettes.get(activePal).colours.size()) 
      {
        dontChangeColourMoron=true;
        cp.setColorValue(palettes.get(activePal).colours.get(activeColr).getColour());
        dontChangeColourMoron=false;
        activeCol = activeColr;
      }
    }
  }

  public void setActiveColour(int colour)
  {
    if (activePal >= 0 && activePal < palettes.size() )
    {
      if (activeCol >= 0 && activeCol < palettes.get(activePal).colours.size() )
      {
        //int alpha = (colour >> 24) & 0xff;
        //int red = (colour >> 16) & 0xFF;
        //int green = (colour >> 8) & 0xFF;
        //int blue = colour & 0xFF;
        //color colr = color( alpha*red, alpha *green, alpha*blue);
        if (!dontChangeColourMoron) palettes.get(activePal).colours.get(activeCol).changeColour(colour);
      }
    }
  }


  public void setActivePalette(int ind)
  {
    activePal = ind;
  }

  public void displayPalette(Palette palette)
  {
    int i = 0;
    for (PaletteColour colour : palette.colours)
    {
      strokeWeight(0);
      if (i == activeCol) 
      {
        int c = color( PApplet.parseInt(sin(PApplet.parseFloat(frameCount)/5)*127+128), 50, 50);
        stroke(c);
        strokeWeight(5);
      } else
      {
        stroke( color(50, 50, 50));
        strokeWeight(1);
      }
      colour.displayColour(width-425+25*(i%16), 25+25*PApplet.parseInt(i/16), 20);
      i++;
    }
  }
}


class Palette
{

  /*
   * A Palette is some horrible contraption that stores colours.
   * Unfortunately the majority of ilda files needs them.
   */

  String name;
  String companyName;
  int totalColors;
  int paletteNumber;
  int scannerHead;
  StringList hoofding; //Data now in a nice StringList to display 

  ArrayList<PaletteColour> colours;     //A list of PaletteColours. Not sure what you expected in a Palette class.

  Palette()
  {
    hoofding = new StringList();
    colours = new ArrayList<PaletteColour>();
  }

  Palette(Palette palette)
  {
    this.name = new String(palette.name);
    this.companyName = new String(palette.companyName);
    this.totalColors = palette.totalColors;
    this.paletteNumber = palette.paletteNumber;
    this.scannerHead = palette.scannerHead;
    this.colours = new ArrayList<PaletteColour>(palette.colours);
  }

  Palette(String _name)
  {
    hoofding = new StringList();
    name = _name;
    colours = new ArrayList<PaletteColour>();
    if (name.equals("Random") )
    {
      for (int i = 0; i < 256; i++)
      {
        PaletteColour paletteColour = new PaletteColour();
        colours.add(paletteColour);
      }
      companyName = "IldaView";
    }
  }

  public byte[] paletteToBytes()
  {

    ArrayList<Byte> theBytes;
    theBytes = new ArrayList<Byte>();

    theBytes.add(PApplet.parseByte('I'));       //Bytes 1-4: "ILDA"
    theBytes.add(PApplet.parseByte('L'));
    theBytes.add(PApplet.parseByte('D'));
    theBytes.add(PApplet.parseByte('A'));
    theBytes.add(PApplet.parseByte(0));         //Bytes 5-8: Format Code 2
    theBytes.add(PApplet.parseByte(0));
    theBytes.add(PApplet.parseByte(0));
    theBytes.add(PApplet.parseByte(2));



    for (int i = 0; i < 8; i++)    //Bytes 9-16: Name
    {
      char letter;
      if (name.length() < i+1) letter = ' ';
      else letter = name.charAt(i);
      theBytes.add(PApplet.parseByte(letter));
    }



    if (companyName == null)   //Bytes 17-24: Company Name
    {
      theBytes.add(PApplet.parseByte('I'));     //If empty: call it "IldaView"
      theBytes.add(PApplet.parseByte('l'));
      theBytes.add(PApplet.parseByte('d'));
      theBytes.add(PApplet.parseByte('a'));
      theBytes.add(PApplet.parseByte('V'));
      theBytes.add(PApplet.parseByte('i'));
      theBytes.add(PApplet.parseByte('e'));
      theBytes.add(PApplet.parseByte('w'));
    }
    else
    {
      for (int i = 0; i < 8; i++)  
      {
        char letter;
        if (companyName.length() < i+1) letter = ' ';
        else letter = companyName.charAt(i);
        theBytes.add(PApplet.parseByte(letter));
      }
    }

    int totalSize = colours.size();
    if (totalSize < 1) return null;
    if (totalSize > 255) totalSize = 256;

    theBytes.add(PApplet.parseByte((totalSize>>8) & 0xff));              //Bytes 25-26: total colours 
    theBytes.add(PApplet.parseByte(totalSize&0xff)); //Limited to 256 so byte 25 is redundant


    //Bytes 27-28: Palette number (just return activePalette)
    theBytes.add(PApplet.parseByte((activePalette>>8) & 0xff));    //This better be correct
    theBytes.add(PApplet.parseByte(activePalette & 0xff));

    theBytes.add(PApplet.parseByte(0));    //Bytes 29-30: Future
    theBytes.add(PApplet.parseByte(0));
    theBytes.add(PApplet.parseByte(scannerHead)); //Byte 31: Scanner head
    theBytes.add(PApplet.parseByte(0));    //Also Future



    for (int i = 0; i < min(256, colours.size()); i++)    //Rest: colour data
    {
      PaletteColour colour = colours.get(i);
      theBytes.add(PApplet.parseByte(colour.getRed()));
      theBytes.add(PApplet.parseByte(colour.getGreen()));
      theBytes.add(PApplet.parseByte(colour.getBlue()));
    }

    byte [] bt = new byte[theBytes.size()];
    for (int i = 0; i<theBytes.size(); i++)
    {
      bt[i] = theBytes.get(i);
    }

    return bt;
  }

  public void resizePalette(int newSize)
  {
    //Delete all colours that are above the new size:
    if (newSize < colours.size() && newSize >=0)
    {
      int blargh = colours.size();
      for (int i = newSize; i < blargh; i++)
      {
        colours.remove(newSize);
      }
    }

    //Add new random colours if the new size is bigger than the previous one:
    else
    {
      int blargh = colours.size();
      for (int i = blargh; i < newSize; i++)
      {
        PaletteColour newColour = new PaletteColour();
        colours.add(newColour);
      }
    }
  }

  public void addColour(int r, int g, int b)
  {
    PaletteColour theColour = new PaletteColour(r, g, b);
    colours.add(theColour);
  }

  public void addColour(int colour)
  {
    PaletteColour theColour = new PaletteColour(colour);
    colours.add(theColour);
  }

  public PaletteColour getPaletteColour(int index)
  {
    if (index < colours.size() && index >= 0)
    {
      return colours.get(index);
    }
    else
    {
      println("Invalid colour");
      return null;
    }
  }

  public int getColour(int index)
  {
    if ( index < colours.size() && index >= 0)
    {
      return colours.get(index).getColour();
    }
    else
    {

      return color(0, 0, 0);
    }
  }

  public void formHeader()
  {
    hoofding.clear();
    hoofding.append("Frame: " + name);
    hoofding.append("Company: " + companyName);
    hoofding.append("Amount of colours: " + totalColors);
    hoofding.append("Palette number: " + paletteNumber);
    hoofding.append("Scanner head: " + scannerHead);
  }
}


class PaletteColour
{
  /*
   * "Color" is not a Processing class, but is a protected name, so we had to find an alternative!
   */

  int red;
  int green;
  int blue;
  int yellow;
  int cyan;
  int dblue;

  PaletteColour()
  {
    red = PApplet.parseInt(random(0, 255));
    green = PApplet.parseInt(random(0, 255));
    blue = PApplet.parseInt(random(0, 255));
  }

  PaletteColour(int r, int g, int b)
  {
    red = r;
    green = g;
    blue = b;
  }

  PaletteColour(int r, int g, int b, int y, int c, int db)
  {
    red = r;
    green = g;
    blue = b;
    yellow = y;
    cyan = c;
    dblue = db;
  }

  PaletteColour( int colour)
  {
    red = (colour >> 16) & 0xFF;  // Faster way of getting red(argb)
    green = (colour >> 8) & 0xFF;   // Faster way of getting green(argb)
    blue = colour & 0xFF;          // Faster way of getting blue(argb)
  }


  public void changeColour(int colour)
  {
    //int a = (colour >> 24) & 0xFF;
    red = (colour >> 16) & 0xFF;  // Faster way of getting red(argb)
    green = (colour >> 8) & 0xFF;   // Faster way of getting green(argb)
    blue = colour & 0xFF;          // Faster way of getting blue(argb)
  }

  public void displayColour(int x, int y, int size)
  {
    fill(color(red, green, blue));
    rect(x, y, size, size);
  }

  public int getRed()
  {
    return red;
  }

  public int getGreen()
  {
    return green;
  }

  public int getBlue()
  {
    return blue;
  }

  public int getYellow()
  {
    return yellow;
  }

  public int getCyan()
  {
    return cyan;
  }

  public int getDarkBlue()
  {
    return dblue;
  }

  public int getColour()
  {
    return color(red, green, blue);
  }
}


class Point
{

  /* 
   * Points are always 3D and with RGB colour variables.
   */

  PVector position;
  int colour;
  boolean blanked;
  int paletteIndex;
  //boolean palette;

  //Not sure why but this one didn't appear to work...
  /*
  Point(PVector _position, color _colour, boolean _blanked)
   {
   position = _position;
   colour = color(red(_colour), green(_colour), blue(_colour));
   blanked = _blanked;
   if (blanked) colour = color(75, 75, 75);
   palette = false;
   }
   */

  Point( PVector _position, int red, int green, int blue, boolean _blanked)
  {
    position = _position;
    colour = color(red, green, blue);
    blanked = _blanked;
    //palette = false;
  }
  Point(float x, float y, float z, int red, int green, int blue, boolean _blanked)
  {
    position = new PVector(x, y, z);
    colour = color(red, green, blue);
    blanked = _blanked;
    //palette = false;
  }

  Point(float x, float y, float z, int _paletteIndex, boolean _blanked)
  {
    position = new PVector(x, y, z);
    paletteIndex = _paletteIndex;
    blanked = _blanked;
    //palette = true;
  }

  //        !!! Notice how this constructor is different from the previous ones, 
  //            this is because "color" is actually an int and otherwise 
  //            there would be two Point(PVector,int,boolean) constructors...

  Point(PVector _position, boolean _blanked, int _paletteIndex)
  {
    position = _position;
    paletteIndex = _paletteIndex;
    blanked = _blanked;
    //palette = true;
  }

  Point(int x, int y, int z, int _paletteIndex, boolean _blanked)
  {
    position = new PVector(x, y, z);
    paletteIndex = _paletteIndex;
    blanked = _blanked;
  }

  Point(float x, float y, float z, boolean _blanked, int theColour)
  {
    position = new PVector(x, y, z);
    colour = theColour;
    blanked = _blanked;
    //palette = false;
  }

  Point(Point point)
  {
    this.position = new PVector(point.position.x, point.position.y, point.position.z);
    this.colour = point.colour;
    this.blanked = point.blanked;
    this.paletteIndex = point.paletteIndex;
  }

  public Point clone()
  {
    Point point = new Point(this);
    return point;
  }

  public Point clone(Point point)
  {
    Point newPoint = new Point(point);
    return newPoint;
  }

  public void displayPoint()
  {
    strokeWeight(3);
    stroke(colour);
    if (blanked) stroke(75, 75, 75);
    point(position.x, position.y, position.z);
  }

  public int getBestFittingPaletteColourIndex(Palette palette)
  {
    int index = 0;
    float distance = 1000;
    PVector colourPos = new PVector((colour >> 16) & 0xFF, (colour >> 8) & 0xFF, colour & 0xFF);
    int i = 0;
    for (PaletteColour theColour : palette.colours)
    {
      PVector palColourPos = new PVector(theColour.red, theColour.green, theColour.blue);
      float d = colourPos.dist(palColourPos);
      if ( d < distance)
      {
        distance = d;
        index = i;
      }
      i++;
    }
    return index;
  }

  public PVector getPosition()
  {
    return position;
  }

  public void setColourFromPalette(Palette palette)
  {
    setColourFromPalette(palette, paletteIndex);
  }

  public void setColourFromPalette(Palette palette, int index)
  {
    colour = palette.getColour(index);
  }
}


// Fields for Sequence Creator tab:

RadioButton seqMode;         //Pick a mode
boolean seqcreator = false;  //Deluxe Paint mode
int creatorMode = -1;        //Which mode is currently active
SequenceCreator sequenceCreator;

//      === SEQUENCE CREATOR TAB METHODS AND CP5 CALLBACKS ===

//Enter the Sequence Creator tab:
public void sequenceCreator()
{
  seqcreator = true;
  if (sequenceCreator == null) sequenceCreator = new SequenceCreator();
  status.clear();
  status.add("Select a mode");
}

//Exit the Sequence Creator tab:
public void exitSequenceCreator()
{
  seqcreator = false;
}

//Click the Import button:
public void finishSeqCreator()
{
  if (sequenceCreator != null) frames.addAll(sequenceCreator.getFrames());
  exitSequenceCreator();

  cp5.getWindow().activateTab("default");
  enterDefaultTab();

  cp5.getController("finishSeqCreator").setMouseOver(false);
}

//Clicked the clear button:
public void clearSeqCreatorFrames()
{
  if (sequenceCreator != null) sequenceCreator.clearFrames();
}

public void showSQBlanking(boolean theBlank)
{
  showBlanking = theBlank;
}

public void initiateSeqCreatorMode(int mode)
{
  if (sequenceCreator != null) 
  {
    if (mode != creatorMode && mode != -1)
    {
      switch(creatorMode)
      {
      case 0 : 
        exitDeluxePaint();
        break;
      case 1 : 
        exitOscillabstract();
        break;
      }
      switch (mode)
      {
      case 0 : 
        deluxePaint();
        break;
      case 1 : 
        oscillAbstract();
        break;
      }
      creatorMode = mode;
    }
  }
}


//SequenceCreator class:
//I guess the reason this is a class is that it doesn't use the memory when it's not used
class SequenceCreator
{
  DeluxePaint deluxe;    
  Oscillabstract osc;

  int numberOfFrames;

  SequenceCreator()
  {
    numberOfFrames = 20;
  }

  public void update()
  {
    switch(creatorMode)
    {
    case 0 : 
      if (deluxe != null) deluxe.update();
      break;
    case 1 :
      if (osc != null) osc.update();
      break;
    }
  }

  public void update3D()
  {
    switch(creatorMode)
    {
    case 0 : 
      //if (deluxe != null) deluxe.update();
      break;
    case 1 : 
      break;
    }
  }

  public void clearFrames()
  {
    if (creatorMode == 0)
    {
      for (Frame frame : deluxe.theFrames)
      {
        frame.points.clear();
      }
    }
  }

  public ArrayList<Frame> getFrames()
  {
    ArrayList<Frame> theFrames = new ArrayList<Frame>();
    switch(creatorMode)
    {
    case 0: 
      theFrames = deluxe.theFrames;
      break;
    case 1:
      theFrames = osc.outFrames;


      for (int i = 0; i < theFrames.size (); i++)
      {
        Frame frame = theFrames.get(i);
        frame.ildaVersion = 4;
        frame.frameName = "Oscillabstract";
        frame.companyName = "IldaViewer";
        frame.pointCount = frame.points.size();
        frame.frameNumber = i;
        frame.totalFrames = theFrames.size();
        frame.scannerHead = 123;
        frame.formHeader();
      }

      break;
    }
    return theFrames;
  }

  //Forward the Mouse event:
  public void mousePressed()
  {
    if (creatorMode == 1)
    {
      if (osc != null) osc.mousePressed();
    }
  }
}

//           === DELUXE PAINT ===

public void deluxePaint()
{
  cam.setActive(false);
  sequenceCreator.deluxe = new DeluxePaint();
  cp5.getController("showSQBlanking").setVisible(true);
  cp5.getController("clearSeqCreatorFrames").setVisible(true);

  status.clear();
  status.add("Mode Deluxe Paint entered. Drag around with the mouse.");
}

public void exitDeluxePaint()
{
  frameRate(60);

  if (frames.size() > 1) cp5.getGroup("framePlayer").setVisible(true);
  if (frames.size()>0)
  {
    cp5.getController("clearFrames").setVisible(true);
    cp5.getController("showBlanking").setVisible(true);
    cp5.getController("showBlanking").setValue(PApplet.parseFloat(PApplet.parseInt(showBlanking)));
  } else
  {
    cp5.getController("clearFrames").setVisible(false);
    cp5.getController("showBlanking").setVisible(false);
    cp5.getController("showBlanking").setValue(PApplet.parseFloat(PApplet.parseInt(showBlanking)));
  }

  status.clear();
  status.add("Mode Deluxe Paint exited.");
}


class DeluxePaint
{

  /*
   * Inspired by http://hamoid.tumblr.com/post/65383946931/a-small-loop-drawing-processing-program-inspired
   */


  float redPhase = random(0, TWO_PI);      //Colour modulation parameters
  float greenPhase = random(0, TWO_PI);
  float bluePhase = random(0, TWO_PI);
  float redFreq = random(0.1f, 2);
  float greenFreq = random(0.1f, 2);
  float blueFreq = random(0.1f, 2);

  ArrayList<Frame> theFrames = new ArrayList<Frame>();

  boolean firstpoint = true;

  //Constructor
  DeluxePaint()
  {
    for (int i = 0; i < sequenceCreator.numberOfFrames; i++)
    {
      Frame aFrame = new Frame();
      aFrame.ildaVersion = 5;
      aFrame.frameName = "Frame " + i;
      aFrame.companyName = "IldaView";
      aFrame.frameNumber = i+1;
      aFrame.totalFrames = sequenceCreator.numberOfFrames;
      aFrame.scannerHead = 9000;
      theFrames.add(aFrame);
    }

    firstpoint = true;  //The CP5 mouseover check method is apparently not very accurate?

    frameRate(120);
  }


  //Not entirely unlike draw()
  public void update()
  {
    if (!theFrames.isEmpty())
    {

      int currFrame = frameCount % sequenceCreator.numberOfFrames;
      if (mousePressed )
      {

        if (cp5.getWindow().getMouseOverList().isEmpty() && !firstpoint)
        {
          Frame theFrame = theFrames.get(currFrame);
          int colour = color(PApplet.parseInt((sin(PApplet.parseFloat(theFrame.points.size())*redFreq/sequenceCreator.numberOfFrames+redPhase)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(theFrame.points.size())*greenFreq/sequenceCreator.numberOfFrames+greenPhase)*0.5f+0.5f)*255), PApplet.parseInt((sin(PApplet.parseFloat(theFrame.points.size())*blueFreq/sequenceCreator.numberOfFrames+bluePhase)*0.5f+0.5f)*255));
          theFrame.points.add(new Point(min(max(0, pmouseX), width), min(max(0, pmouseY), height), 0, true, colour ));    //Notice the slightly different constructor!
          theFrame.points.add(new Point(min(max(0, mouseX), width), min(max(0, mouseY), height), 0, false, colour ));
          theFrame.pointCount = theFrame.points.size();
        }

        if (firstpoint) firstpoint = false;
      }
      theFrames.get(currFrame).drawFrame(showBlanking);
    }
  }
}


//            === OSCILLABSTRACT ===

public void oscillAbstract()
{
  if (sequenceCreator.osc == null) sequenceCreator.osc = new Oscillabstract();
  cp5.getController("showSQBlanking").setVisible(false);
  cp5.getController("clearSeqCreatorFrames").setVisible(false);
  cp5.getController("emptyOscElements").setVisible(true);
  cp5.getController("loadElements").setVisible(true);
  cp5.getController("saveElements").setVisible(true);

  status.clear();
  status.add("Mode Oscillabstract entered. Click to add an element and connect the nodes by dragging.");
}

public void exitOscillabstract()
{
  cp5.getController("emptyOscElements").setVisible(false);
  cp5.getController("loadElements").setVisible(false);
  cp5.getController("saveElements").setVisible(false);
}

public void emptyOscElements()
{
  cp5.getController("emptyOscElements").setLabel("Confirm... (enter)");
  sequenceCreator.osc.resetWorkspace = true;
  status.clear();
  status.add("Confirm resetting by pressing Enter. This will remove all elements and connections.");
}

//Load workspace cascade:
public void loadElements()
{
  thread("loadOscWorkspace");
}

public void loadOscWorkspace()
{
  status.clear();
  status.add("Warning: this will overwrite the current workspace!");
  selectInput("Load a workspace (.osc file)", "oscFileLoad");
}

public void oscFileLoad(File selection)
{
  String[] input;

  //Checks:
  if (selection == null)
  {
    status.clear();
    status.add("Error when trying to read file:" );
    status.add("Aborted import or file does not exist.");
    return;
  }

  sequenceCreator.osc.openedLocation = selection;

  try
  {
    input = loadStrings(selection);
  }
  catch(Exception e)
  {
    status.clear();
    status.add("Error when trying to read file " + selection.getAbsolutePath());
    status.add("Could not read file");
    return;
  }

  if (input.length<6 || !input[0].equals("Oscillabstract workspace") || !(splitTokens(input[1])[0].equals("IldaViewer")) || !(splitTokens(input[2])[1].equals("colouredmirrorball")))
  {
    status.clear();
    status.add("Error when trying to read file " + selection.getAbsolutePath());
    status.add("Invalid, modified or unsupported file");
    return;
  }

  //Seems like a correct file, let's load it in!

  //Clear the workspace before adding elements:
  sequenceCreator.osc.elements.clear();
  sequenceCreator.osc.connections.clear();

  //Loop through the text file and search for key words:
  for (int i = 6; i < input.length; i++)
  {
    String arg = input[i];
    String[] blah = splitTokens(arg);
    if (blah.length > 0)
    {
      if (blah[0].equals("Element")) 
      {
        String name = "";
        //We're dealing with an Element here, skip ahead and search for the end of this Element section:
        for (int j = i+1; j < input.length; j++)
        {

          String[] test = splitTokens(input[j]);

          boolean create = false;
          if (test.length > 0)
          {
            if (test[0].equals("Element") || test[0].equals("Connection") )  //Element and Connection are two key words, so let's create an element later on!
            {
              create = true;
            }
            if (test[0].equals("Name")) name = test[1];    //we need the name soon
            if (test[0].equals("Index"))    //This is important, the currentIndex value is used for identifying the elements so make sure it has a different value
            {
              int index = PApplet.parseInt(test[1]);
              if (index >= sequenceCreator.osc.currentIndex) sequenceCreator.osc.currentIndex = index + 1;
            }
          }
          if (j == input.length-1) create = true;
          if (create)
          {
            StringList its3AmAndIHaveClassTomorrowMorningButImFixingThisAnyway = new StringList();
            for (int k = 0; k < j-i; k++)
            {
              if (input[k+i] != null) its3AmAndIHaveClassTomorrowMorningButImFixingThisAnyway.append(input[k+i]);
            }

            String[] elArg = its3AmAndIHaveClassTomorrowMorningButImFixingThisAnyway.array();                  //  <-----   Add new elements here!
            if (name.equals("Source")) sequenceCreator.osc.elements.add(new Oscisource(elArg));
            if (name.equals("Output")) sequenceCreator.osc.elements.add(new Oscilloutput(elArg));
            if (name.equals("Merge")) sequenceCreator.osc.elements.add(new Oscimerger(elArg));
            if (name.equals("Breakout")) sequenceCreator.osc.elements.add(new Oscibreakout(elArg));
            if (name.equals("Breakin")) sequenceCreator.osc.elements.add(new Oscibreakin(elArg));
            if (name.equals("RGB")) sequenceCreator.osc.elements.add(new Oscicolour(elArg));
            if (name.equals("Palette")) sequenceCreator.osc.elements.add(new Oscipalette(elArg));
            if (name.equals("Palettifier")) sequenceCreator.osc.elements.add(new Oscipalettifier(elArg));
            if (name.equals("Translate")) sequenceCreator.osc.elements.add(new Oscitranslate(elArg));
            if (name.equals("Rotate")) sequenceCreator.osc.elements.add(new Oscirotate(elArg));
            if (name.equals("Scale")) sequenceCreator.osc.elements.add(new Osciscale(elArg));
            if (name.equals("Oscillator")) sequenceCreator.osc.elements.add(new Oscillator(elArg));
            if (name.equals("Constant")) sequenceCreator.osc.elements.add(new Oscilloconstant(elArg));
            if (name.equals("Adder")) sequenceCreator.osc.elements.add(new Oscilladder(elArg));
            if (name.equals("Multiplier")) sequenceCreator.osc.elements.add(new Osciplier(elArg));

            if (name.equals("Clock")) sequenceCreator.osc.elements.add(new Oscilloclock(elArg));
            if (name.equals("Inspect")) sequenceCreator.osc.elements.add(new Oscinspect(elArg));
            j = input.length;
          }
        }
      }

      if (blah[0].equals("Connection"))
      {
        //This is a Connection, see where its section ends:
        for (int j = i+1; j < input.length; j++)
        {
          String[] test = splitTokens(input[j]);
          boolean create = false;
          if (test.length > 0)
          {
            if (test[0].equals("Element") || test[0].equals("Connection") )
            {
              create = true;
            }
          }
          if (j == input.length-1) create = true;
          if (create)
          {
            StringList its3AmAndIHaveClassTomorrowMorningButImFixingThisAnyway = new StringList();
            for (int k = 0; k < j-i; k++)
            {
              if (input[k+i] != null) its3AmAndIHaveClassTomorrowMorningButImFixingThisAnyway.append(input[k+i]);
            }
            String[] connArg = its3AmAndIHaveClassTomorrowMorningButImFixingThisAnyway.array();
            sequenceCreator.osc.connections.add(new Connection(connArg));
            j = input.length;
          }
        }
      }
    }
  }


  status.clear();
  status.add("Loaded in workspace:");
  status.add(selection.getAbsolutePath());
}

//Save workspace cascade:
public void saveElements()
{
  thread("saveOscWorkspace");
}

public void saveOscWorkspace()
{
  String pathname;
  pathname = ".osc";
  File theFile = new File(pathname);
  status.clear();
  status.add("Select where to save the workspace");
  selectOutput("Save the current wokspace...", "oscFileSave", theFile);
}

public void oscFileSave(File selection)
{
  if (selection == null)
  {
    status.clear();
    status.add("Workspace not saved.");
    return;
  }
  status.clear();

  sequenceCreator.osc.openedLocation = selection;    //Save this so it knows where to save the ilda files

  String location = selection.getAbsolutePath();
  char[] test = new char[4];  //Test if it already has the extension .osc:
  for (int i = 0; i < 4; i++)
  {
    test[i] = location.charAt(i+location.length()-4);
  }
  String testing = new String(test);
  if ( !testing.equals(".osc") )
  {
    location += ".osc";
  }


  StringList output = new StringList();  //This is the actual StringList that will get written to the file

  //Add some junk in the beginning:
  output.append("Oscillabstract workspace");
  output.append("IldaViewer version " + ildaViewerVersion);
  output.append("Author: colouredmirrorball");
  output.append("Visit http://www.photonlexicon.com/forums/showthread.php/21601-Another-Ilda-view-tool");
  output.append("Modify this file at your own risk.");
  output.append("");
  output.append("*************************************************************************************");
  output.append("");
  output.append("");

  //Retrieve the state of each Element as a String[]
  for (Oscillelement element : sequenceCreator.osc.elements)
  {
    output.append("Element");
    String[] elementStrings = element.getElementAsString();  //A Source will also export its content as an ilda file
    for (String arg : elementStrings)
    {
      output.append(arg);
    }
    output.append("");
  }

  //Retrieve the state of each Connection as a String[]
  for (Connection connection : sequenceCreator.osc.connections)
  {
    output.append("Connection");
    String[] connectionString = connection.getConnectionAsString();
    for (String arg : connectionString)
    {
      output.append(arg);
    }
    output.append("");
  }

  saveStrings(location, output.array());

  status.add("Workspace was saved to:");
  status.add(location);
}

boolean checkMouseOver = true;
boolean deleteOscillelement = false;
float   deletingElementIndex = -1;

//I apologise in advance for what follows. Try to keep up!

class Oscillabstract
{
  ArrayList<Oscillelement> elements = new ArrayList<Oscillelement>();
  NewElement theElement;    //This Element is the new Element dialog that pops up when you click somewhere
  boolean addNewElement = false;  //accompagnying booleans
  boolean showAddDialog = true;
  int dialogX;      //position of new element dialog
  int dialogY;
  boolean hideElements = false;    //Should be set to true if a big dialog "window" (= rectangle) is active to avoid overlap
  int currentIndex = 0;
  ArrayList<Connection> connections = new ArrayList<Connection>();
  ArrayList<Frame> outFrames = new ArrayList<Frame>();
  boolean resetWorkspace = false;
  File openedLocation;      //for saving/loading ilda files
  boolean dragWorkspace = false;

  Oscillabstract()
  {
    //Add two Elements and a Connection to help users getting started:
    Oscisource source = new Oscisource(10, 160);
    source.index = currentIndex++;
    elements.add(source);
    Oscilloutput output = new Oscilloutput(width-225, height-145);
    output.index = currentIndex++;
    elements.add(output);
    Connection connection = new Connection(0, 0, 1, "Output", "Input");
    connections.add(connection);
  }

  public void resetWorkspace()
  {
    //The output needs to stay here when resetting:
    connections.clear();
    elements.clear();
    currentIndex = 0;
    Oscilloutput output = new Oscilloutput(width-225, height-145);
    output.index = currentIndex++;
    elements.add(output);
    System.gc();
    status.clear();
    status.add("Workspace reset");
  }

  //Each time an Element needs an index, it arrives here
  //The index is used for identification so it's important it's unique
  //So increment each time it's accessed.
  //It doesn't matter if the index of the elements isn't sequential, it should just be unique
  public int getIndex()
  {
    return currentIndex++;
  }

  public void update()
  {
    //Draw/update the elements:
    for (Oscillelement element : elements)
    {
      element.update();      //Always keep the update() and display() strictly separated to easily implement threading in the future!
      if (element.x > -element.sizex && element.x < width+5 && element.y > -element.sizey && element.y < height+5) element.display(hideElements);
    }

    //Draw/update the connections and remove if indicated:
    for (int i = 0; i < connections.size (); i++)
    {
      Connection connection = connections.get(i);
      if (connection.deleteConnection) connections.remove(i); 
      connection.update();
      connection.display();
    }

    //Elements use an alternative delete method: 
    //when indicated they should be deleted they put deleteOscillelement to true
    //and set deletingElementIndex to their own index
    if (deleteOscillelement)
    {
      for (int i = 0; i < elements.size (); i++)
      {
        if (elements.get(i).index == deletingElementIndex)
        {
          elements.remove(i);
          i = elements.size();
        }
      }
      deleteOscillelement = false;
    }

    //Display the new element dialog when necessary:
    if (addNewElement)
    {
      if (theElement != null)
      {
        theElement.update();
        theElement.display();
      }
    }

    //Some GUI magic when resetting workspace (the Clear button):
    if (resetWorkspace)
    {
      if (keyPressed && key == ENTER)
      {
        resetWorkspace();
        cp5.getController("emptyOscElements").setLabel("Clear");
        resetWorkspace = false;
      }
      if ((keyPressed && key != ENTER) || mousePressed)
      {
        cp5.getController("emptyOscElements").setLabel("Clear");
        resetWorkspace = false;
      }
    }

    //Drag the workspace around:
    if (dragWorkspace)
    {
      float workspaceX = -mouseX + pmouseX ;
      float workspaceY = -mouseY + pmouseY ;
      for (Oscillelement element : elements)
      {
        element.setPosition(workspaceX, workspaceY);
      }
    }

    //When the mouse is released, stop dragging it around
    if (dragWorkspace && !mousePressed) 
    {
      dragWorkspace = false;
      cursor(ARROW);
    }
  }

  public void mousePressed()
  {
    //Search element and check if it's clicked on:

    if (!keyPressed)
    {
      boolean clickedOnElement = false;
      for (int i = elements.size ()-1; i >= 0; i--)
      {
        Oscillelement element = elements.get(i);
        if (checkMouseOver && mouseX > element.x && mouseX < element.x + element.sizex && mouseY > element.y && mouseY < element.y + element.sizey && !clickedOnElement && !addNewElement)
        {
          clickedOnElement = true;    //used later to check if the new element dialog should be brought up
          element.mouseUpdate();          //tell the element it's been clicked on
          i = -1;
        }
      }
      if (addNewElement)      //the new element dialog is not a part of the elements arraylist so check it independently
      {
        if (mouseX > theElement.x && mouseX < theElement.x + theElement.sizex && mouseY > theElement.y && mouseY < theElement.y + theElement.sizey)
        {
          clickedOnElement = true;
          theElement.mouseUpdate();
        } else
        {
          addNewElement = false;
          showAddDialog = true;
        }
      }


      //Not clicked on anything so bring up the new element dialog:
      if (!clickedOnElement && cp5.getWindow().getMouseOverList().isEmpty() && mouseButton == LEFT)
      {
        if (!addNewElement)
        {
          showAddDialog = !showAddDialog;
          if (showAddDialog) addNewElement = true;
          theElement = new NewElement(mouseX, mouseY);
        }
      }
    }

    //When clicked with the middle mouse button, drag the workspace around:
    if ((mouseButton == CENTER || (mouseButton == LEFT && keyPressed && keyCode == CONTROL))  && !hideElements)
    {
      dragWorkspace = true;
      cursor(MOVE);
    }
  }

  //Convenience method
  public Oscillelement searchElement(int index)
  {
    for (Oscillelement element : elements)
    {
      if (element.index == index) return element;
    }
    return null;
  }

  //Same
  public Oscillelement searchElement(float x, float y)
  {
    for (Oscillelement element : elements)
    {
      if (checkMouseOver && mouseX > element.x && mouseX < element.x + element.sizex && mouseY > element.y && mouseY < element.y + element.sizey)
      {
        return element;
      }
    }
    return null;
  }
}


//Parent class for the elements
class Oscillelement
{
  float x;
  float y;
  float sizex = 100;
  float sizey = 100;
  int index; //index = sequenceCreator.osc.getIndex();
  boolean dragging = false;
  float dragOffsetX = 0;
  float dragOffsetY = 0;
  ArrayList<GuiElement> gui = new ArrayList<GuiElement>();
  String name;
  ArrayList<Node> nodes = new ArrayList<Node>();

  Oscillelement()
  {
  }

  Oscillelement(float x, float y, String name)
  {
    this.x = x;
    this.y = y;
    sizex = 100;
    sizey = 100;
    this.name = name;
    if (sequenceCreator.osc != null)
    {
      index = sequenceCreator.osc.getIndex();
    }
  }

  //This is the adviced constructor
  Oscillelement(float x, float y, float sizex, float sizey, String name)
  {
    this.x = x;
    this.y = y;
    this.sizex = sizex;
    this.sizey = sizey;
    this.name = name;
    if (sequenceCreator.osc != null)
    {
      index = sequenceCreator.osc.getIndex();
    }
  }

  //(Or this one if you're reading in a file)
  Oscillelement(String[] input)
  {
    for (String arg : input)
    {
      String[] q = splitTokens(arg);
      if (q.length >= 2)
      {
        if (q[0].equals("Name") ) name = q[1];
        if (q[0].equals("X") ) x = PApplet.parseInt(q[1]);
        if (q[0].equals("Y") ) y = PApplet.parseInt(q[1]);
        if (q[0].equals("SizeX") ) sizex = PApplet.parseInt(q[1]);
        if (q[0].equals("SizeY") ) sizex = PApplet.parseInt(q[1]);
        if (q[0].equals("Index") ) index = PApplet.parseInt(q[1]);
      }
    }
  }

  //Display this element
  public void display(boolean hide)
  {
    stroke(50);
    strokeWeight(3);
    fill(127);
    float bx = x ;
    float by = y ;
    if (hide) bx += width*10;
    if (hide) by += height*10;

    rect(bx, by, sizex, sizey, 7);

    fill(0);
    textAlign(LEFT);
    textFont(f10);

    text(name, bx+5, by+13);

    for (GuiElement element : gui)
    {
      element.display(bx, by);
    }

    for (Node node : nodes)
    {
      node.display(bx, by);
    }
  }

  //Never display anything in the update() method.
  public void update()
  {
    try
    {
      if (dragging && !mousePressed) dragging = false;
      if (dragging)
      {
        x = mouseX-dragOffsetX;
        y = mouseY - dragOffsetY;
      }

      for (GuiElement element : gui)
      {
        element.update(x, y);
      }

      for (Node node : nodes)
      {
        node.update();
      }
    }
    catch(Exception e)
    {
      println("An error occured while updating element " + index);
      println(e);
      closeElement();
    }
  }

  //This method gets called when the Oscillabstract class detects the user has clicked on this element
  public void mouseUpdate()
  {
    if (!dragging)
    {
      boolean shouldItDrag = true;    //Unless otherwise specified, start dragging
      for (GuiElement element : gui)
      {
        if (element.activateElement(x, y) && element.visible)
        {
          guiActionDetected();
          shouldItDrag = false;    //When clicked on a Gui element, specify otherwise
        }
      }
      for (Node node : nodes)
      {
        if (node.checkMouse(x, y) && node.visible)
        {
          if (mouseButton == LEFT) nodeActionDetected(node);
          if (mouseButton == RIGHT) resetNode(node);
          shouldItDrag = false;
        }
      }
      if (shouldItDrag)
      {
        dragging = true;
        dragOffsetX = mouseX - x;
        dragOffsetY = mouseY - y;
      }
    }
  }

  public void setPosition(float inx, float iny)
  {
    x -= inx;
    y -= iny;
  }

  //When this node has a Connection, the Connection is going to call this method (if it has the right type). 
  //The Connection keeps track of the name of the node as a string, so check which input it corresponds to and apply value
  public void nodeInput(String nodeName, Frame frame)
  {
  }

  //Same here but with floats
  public void nodeInput(String nodeName, float[] input)
  {
  }
  /*
  void nodeInput(String nodeName, float input)
   {
   }
   
   float getFloatValue(String outName)
   {
   return 0;
   }
   */

  //The Connection will call this method when updating. It specifies the name of the node.
  public float[] getFloatArrayValue(String outName)
  {
    float[] empty = {
      0
    };
    return empty;
  }

  //Same but for frames
  public Frame getFrameValue(String outName)
  {
    return null;
  }

  //Handle GUI events here. Loop through all GuiElements and check for their boolean active.
  //If it's true, it has been clicked on.
  public void guiActionDetected()
  {
  }

  //Return a String[] with all the parameters or this element. Be as complete as possible so the exact state can be restored accurately.
  public String[] getElementAsString()
  {
    StringList output = new StringList();
    output.append("Name " + name);
    output.append("X " + x);
    output.append("Y " + y);
    output.append("Index " + index);
    for (GuiElement el : gui)
    {
      output.append("GUI " + el.name + " " + el.getValue());
    }

    return output.array();
  }

  //If clicked on a node, start dragging a connection:
  public void nodeActionDetected(Node node)
  {
    if (node instanceof InNode) 
    {
      //Check if it already has an input (you can't have two connections in the same input): 
      boolean connected = false;
      for (Connection connection : sequenceCreator.osc.connections)
      {
        if (connection.connectedToInput(index, node)) 
        {
          connection.startDraggingInput();
          connected = true;
        }
      }
      if (!connected) 
      {
        Connection connection = new Connection(node.type, node.x+x, node.y+y, node.name, index); //InputNode fixed
        connection.startDraggingOutput();
        sequenceCreator.osc.connections.add(connection);
      }
    }
    if (node instanceof OutNode)
    {
      Connection connection = new Connection(node.type, node.x+x, node.y+y, index, node.name); //OutputNode fixed
      connection.startDraggingInput();
      sequenceCreator.osc.connections.add(connection);
    }
  }

  //Method to reset the value of the node
  public void resetNode(Node node)
  {
  }

  //Allows dynamically resizing the element
  public void reachSize(float newSizex, float newSizey)
  {
    sizex += (newSizex - sizex)*0.25f;
    sizey += (newSizey - sizey)*0.25f;
  }

  //Call this upon exiting the element
  public void closeElement()
  {
    deleteOscillelement = true;
    deletingElementIndex = index;
  }

  //convenience
  public Node getNode(String name)
  {
    for (Node node : nodes)
    {
      if (node.name.equals(name)) return node;
    }
    return null;
  }

  public Node searchNode(float xin, float yin)
  {
    for (Node node : nodes)
    {
      if (xin > x + node.x-5 && xin < x + node.x + 5 && yin > y + node.y-5 && yin < y + node.y +5)
      {
        return node;
      }
    }
    return null;
  }
}

class NewElement extends Oscillelement
{
  int formTime = millis();
  boolean guiVisible = false;

  float yoffset = 0;
  float prevyoffset = 0;
  float blahy = 250;
  float totalshifted = 0;

  NewElement(int x, int y)
  {
    super(x, y, 220, 20, "Add:");
  }

  public void guiActionDetected()
  {
    for (GuiElement element : gui)
    {
      if (element.active) 
      {
        if (element.name.equals("Scroller"))
        {
          element.active = true;
        }
        if (element.name.equals("Source"))
        { 
          element.active = false;
          newSource();
          status.clear();
          status.add("Select which frames are to be used as a source. Sync is the current frame's index.");
        }
        if (element.name.equals("Oscillator"))
        { 
          element.active = false;
          newOscillator();
          status.clear();
          status.add("Click the wave preview window to select a waveform: ");
          status.add("sine, cosine, ramp, triangle, sawtooth, square, random, noise");
        }
        if (element.name.equals("Merger"))
        { 
          element.active = false;
          newMerger();
          status.clear();
          status.add("Merge two or more frames together. ");
          status.add("You can also write specific properties of the first frame into the others.");
        }
        if (element.name.equals("Breakout"))
        { 
          element.active = false;
          newBreakout();
          status.clear();
          status.add("Split a frame into its components (X, Y, Z, R, G, B, ");
          status.add("amount of points, blanked, palette index)");
        }
        if (element.name.equals("Breakin"))
        { 
          element.active = false;
          newBreakin();
          status.clear();
          status.add("Join data together to form a frame.");
        }
        if (element.name.equals("RGB"))
        { 
          element.active = false;
          newColour();
          status.clear();
          status.add("Assign RGB values to the points of a frame.");
        }
        if (element.name.equals("Palette"))
        { 
          element.active = false;
          newPalette();
          status.clear();
          status.add("Assign a palette index to the points of a frame.");
        }
        if (element.name.equals("Palettifier"))
        { 
          element.active = false;
          newPalettifier();
          status.clear();
          status.add("Make a frame use a palette. RGB values are automatically fitted to the palette colour.");
        }
        if (element.name.equals("Translate"))
        {
          element.active = false;
          newTranslator();
          status.clear();
          status.add("Translate the points of the frame around.");
        }
        if (element.name.equals("Rotate"))
        {
          element.active = false;
          newRotator();
          status.clear();
          status.add("Rotate the frame around. You can also specify an anchor point around which the frame should rotate.");
        }
        if (element.name.equals("Scale"))
        {
          element.active = false;
          newScaler();
          status.clear();
          status.add("Scale the frame. You can also specify an anchor point to which reference the frame should scale.");
        }
        if (element.name.equals("Constant"))
        {
          element.active = false;
          newConstant();
          status.clear();
          status.add("Drag the mouse to select a value. Use the control key to round to the nearest (half) integer.");
        }
        if (element.name.equals("Add/Subtract"))
        {
          element.active = false;
          newAdder();
          status.clear();
          status.add("Add or subtract two or more values together.");
        }
        if (element.name.equals("Multiply/Divide"))
        {
          element.active = false;
          newMultiplier();
          status.clear();
          status.add("Multiply two or more values.");
        }
        if (element.name.equals("Math"))
        {
          element.active = false;
          //newDivider();
          status.clear();
          status.add("Divide a value by another.");
        }
        if (element.name.equals("Clock"))
        {
          element.active = false;
          newClock();
          status.clear();
          status.add("Outputs a signal linearly going from 0 to 1 in one second.");
          status.add("The shape of the signal can be altered by connecting a stream of values to Shape.");
        }
        if (element.name.equals("Inspect"))
        {
          element.active = false;
          newInspect();
          status.clear();
          status.add("Hook up some data you want to visualize.");
        }
      }
    }
    //mousePressed = false;
  }

  public void update()
  {
    super.update();
    blahy = 315;
    if (y > height - blahy) blahy = -y + height;
    reachSize(sizex, blahy);
    if (!guiVisible)
    {
      if (millis() - formTime > blahy)
      {
        gui.add( new GuiScroller(sizex-10, 5, 8, sizey-10, "Scroller"));
        gui.add( new GuiButton(5, 20, 90, 20, "Source"));
        gui.add( new GuiButton(5, 45, 90, 20, "Oscillator"));
        gui.add( new GuiButton(5, 70, 90, 20, "Merger"));
        gui.add( new GuiButton(sizex - 115, 20, 90, 20, "Breakout"));
        gui.add( new GuiButton(sizex - 115, 45, 90, 20, "Breakin"));
        gui.add( new GuiButton(sizex - 115, 80, 90, 20, "RGB"));
        gui.add( new GuiButton(sizex - 115, 105, 90, 20, "Palette"));
        gui.add( new GuiButton(sizex - 115, 130, 90, 20, "Palettifier"));
        gui.add( new GuiButton(5, 105, 90, 20, "Translate"));
        gui.add( new GuiButton(5, 130, 90, 20, "Rotate"));
        gui.add( new GuiButton(5, 155, 90, 20, "Scale"));
        gui.add( new GuiButton(5, 190, 90, 20, "Constant"));
        gui.add( new GuiButton(5, 215, 90, 20, "Add/Subtract"));
        gui.add( new GuiButton(5, 240, 90, 20, "Multiply/Divide"));
        gui.add( new GuiButton(5, 265, 90, 20, "Math"));
        gui.add( new GuiButton(5, 290, 90, 20, "Clock"));
        gui.add( new GuiButton(sizex - 115, 165, 90, 20, "Inspect"));
        guiVisible = true;
      }
    }
    for (GuiElement el : gui)
    {
      if (el.name.equals("Scroller")) 
      {
        yoffset = el.getValue();
        yoffset = map(yoffset, 0, 1, 0, 315 - blahy);
      } else
      {
        if (yoffset != prevyoffset) 
        {
          el.y  -= yoffset - prevyoffset;
        }
        if (el.y < 0 || el.y > blahy - el.sizey) el.alpha = 0;
        else el.alpha = 255;
      }
    }
    prevyoffset = yoffset;
  }

  public void display()
  {
    super.display(sequenceCreator.osc.hideElements);
  }

  public void newSource()
  {
    sequenceCreator.osc.elements.add(new Oscisource(x, y));
    sequenceCreator.osc.addNewElement = false;
    sequenceCreator.osc.showAddDialog = false;
  }

  public void newOscillator()
  {
    sequenceCreator.osc.elements.add(new Oscillator(x, y));
    sequenceCreator.osc.addNewElement = false;
    sequenceCreator.osc.showAddDialog = false;
  }

  public void newMerger()
  {
    sequenceCreator.osc.elements.add(new Oscimerger((int)x, (int) y));
    sequenceCreator.osc.addNewElement = false;
    sequenceCreator.osc.showAddDialog = false;
  }

  public void newBreakout()
  {
    sequenceCreator.osc.elements.add(new Oscibreakout((int)x, (int) y));
    sequenceCreator.osc.addNewElement = false;
    sequenceCreator.osc.showAddDialog = false;
  }
  public void newBreakin()
  {
    sequenceCreator.osc.elements.add(new Oscibreakin((int)x, (int) y));
    sequenceCreator.osc.addNewElement = false;
    sequenceCreator.osc.showAddDialog = false;
  }
  public void newColour()
  {
    sequenceCreator.osc.elements.add(new Oscicolour((int)x, (int) y));
    sequenceCreator.osc.addNewElement = false;
    sequenceCreator.osc.showAddDialog = false;
  }
  public void newPalette()
  {
    sequenceCreator.osc.elements.add(new Oscipalette((int)x, (int) y));
    sequenceCreator.osc.addNewElement = false;
    sequenceCreator.osc.showAddDialog = false;
  }
  public void newPalettifier()
  {
    sequenceCreator.osc.elements.add(new Oscipalettifier((int)x, (int) y));
    sequenceCreator.osc.addNewElement = false;
    sequenceCreator.osc.showAddDialog = false;
  }
  public void newTranslator()
  {
    sequenceCreator.osc.elements.add(new Oscitranslate((int) x, (int) y));
    sequenceCreator.osc.addNewElement = false;
    sequenceCreator.osc.showAddDialog = false;
  }
  public void newRotator()
  {
    sequenceCreator.osc.elements.add(new Oscirotate((int) x, (int) y));
    sequenceCreator.osc.addNewElement = false;
    sequenceCreator.osc.showAddDialog = false;
  }
  public void newScaler()
  {
    sequenceCreator.osc.elements.add(new Osciscale((int) x, (int) y));
    sequenceCreator.osc.addNewElement = false;
    sequenceCreator.osc.showAddDialog = false;
  }
  public void newConstant()
  {
    sequenceCreator.osc.elements.add(new Oscilloconstant(x, y));
    sequenceCreator.osc.addNewElement = false;
    sequenceCreator.osc.showAddDialog = false;
  }
  public void newAdder()
  {
    sequenceCreator.osc.elements.add(new Oscilladder(x, y));
    sequenceCreator.osc.addNewElement = false;
    sequenceCreator.osc.showAddDialog = false;
  }
  public void newMultiplier()
  {
    sequenceCreator.osc.elements.add(new Osciplier(x, y));
    sequenceCreator.osc.addNewElement = false;
    sequenceCreator.osc.showAddDialog = false;
  }
  public void newMath()
  {
    //sequenceCreator.osc.elements.add(new Oscivider(x, y));
    sequenceCreator.osc.addNewElement = false;
    sequenceCreator.osc.showAddDialog = false;
  }
  public void newClock()
  {
    sequenceCreator.osc.elements.add(new Oscilloclock(x, y));
    sequenceCreator.osc.addNewElement = false;
    sequenceCreator.osc.showAddDialog = false;
  }
  public void newInspect()
  {
    sequenceCreator.osc.elements.add(new Oscinspect(x, y));
    sequenceCreator.osc.addNewElement = false;
    sequenceCreator.osc.showAddDialog = false;
  }
}
/*
class Oscibuffershift extends Oscillelement
 {
 float[] values = {0};
 float[] offset = {0};
 float[] output = {
 0
 };
 
 Oscibuffershift(float x, float y)
 {
 super(x, y, 100, 100, "Buffer Shift");
 generateNodes();
 generateGui();
 values.add(new float[0]);
 values.add(new float[0]);
 }
 
 Oscilladder(String[] input)
 {
 super(input);
 sizex = 100;
 sizey = 100;
 
 }
 
 void update()
 {
 super.update();
 int l = 1;
 
 if (!values.isEmpty()) 
 {
 l = values.get(0).length;
 
 output = new float[l];
 
 for (int i = 0; i < values.size (); i++)
 {
 float[] v = values.get(i);
 if (v.length > 0) getNode("Value " + (i+1)).setColour(color((int) min(255, max(0, v[0]*255))));
 }
 if (output.length > 0) getNode("Output").setColour(color((int) min(255, max(0, output[0]*255))));
 }
 
 void generateGui()
 {
 gui.add(new GuiClose(sizex-15, 0));
 gui.add(new GuiButton(sizex-50, 65, 45, 20, "Add"));
 gui.add(new GuiButton(5, 5+3*20, 20, 20, "+"));
 }
 
 void generateNodes()
 {
 nodes.add(new InNode(10, 25, "Value 1", 1));
 nodes.add(new InNode(10, 45, "Value 2", 1));
 nodes.add(new OutNode(sizex-10, 25, "Output", 1));
 }
 
 void nodeInput(String nodeName, float[] input)
 {
 for (int i = 0; i < numberOfInputs; i++)
 {
 if (nodeName.equals("Value " + (i+1)))
 {
 float[] val = new float[input.length];
 arrayCopy(input, val);
 if (i < values.size())values.set(i, val);
 }
 }
 }
 
 void resetNode(Node node)
 {
 for (int i = 0; i < numberOfInputs; i++)
 {
 if (node.name.equals("Value " + (i+1)))
 {
 float[] val = new float[0];
 if (i < values.size())values.set(i, val);
 }
 }
 }
 
 float[] getFloatArrayValue(String outName)
 {
 if (outName.equals("Output")) return output;
 return null;
 }
 
 void guiActionDetected()
 {
 for (GuiElement element : gui)
 {
 if (element.active) 
 {
 
 if (element.name.equals("+"))
 {
 element.active = false;
 numberOfInputs++;
 nodes.add(new InNode(10, 5+20*numberOfInputs, "Value " + numberOfInputs, 1));
 for (GuiElement el : gui)
 {
 if (!el.name.equals("close")) el.y += 20;
 }
 sizey += 20;
 values.add(new float[0]);
 }
 if (element.name.equals("Add"))
 {
 if (subtract) 
 {
 element.text = "Add";
 subtract = false;
 } else 
 {
 element.text = "Subtract";
 subtract = true;
 }
 element.toggle();
 }
 
 if (element.name.equals("close"))
 { 
 element.active = false;
 closeElement();
 }
 }
 }
 }
 
 String[] getElementAsString()
 {
 String[] superList = super.getElementAsString();
 StringList args = new StringList();
 args.append("Inputs " + numberOfInputs);
 args.append("Subtract " + subtract);
 
 return concat(superList, args.array());
 }
 }
 */
class Oscinspect extends Oscillelement
{
  Frame frame;
  float[] values = {
  };
  float yValue = 60;
  float xValue = 100;
  boolean details = false;
  float minValue, maxValue, cursorY, sum, pminValue, pmaxValue;
  int cursorX;

  Oscinspect(float x, float y)
  {
    super(x, y, 100, 160, "Inspect");
    generateGui();
    generateNodes();
  }

  Oscinspect(String[] input)
  {
    super(input);
    sizex = 100;
    sizey = 60;
    generateGui();
    generateNodes();
  }

  public void update()
  {
    super.update();
    yValue = 60;
    if (values.length > 0) yValue += 50;
    if (frame != null) yValue += 100;
    reachSize(xValue, yValue);
  }

  public void display(boolean hide)
  {
    super.display(hide);
    if (hide) return;
    fill(0);
    noStroke();

    int yps = (int) y+60;
    if (values.length > 0)
    {
      if (mouseY >= yps && mouseY <= yps + 40 && mouseX >= (int) x+5 && mouseX <= (int) x+95) cursorX = mouseX-(int) x-5;
      rect(x+5, yps, 90, 40);
      float prev = values[0];
      if (laserboyMode) stroke(color(PApplet.parseInt((sin(PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin(PI/2+PApplet.parseFloat(frameCount)/10)*0.5f+0.5f)*255), PApplet.parseInt((sin(3*PI/2+PApplet.parseFloat(frameCount)/20)*0.5f+0.5f)*255))); 
      else stroke(10, 127, 50);
      strokeWeight(1);
      minValue = 1e32f;
      maxValue = -1e32f;
      sum = 0;
      for (int i = 1; i < values.length; i++)
      {
        //Determine minimum:
        if (values[i] < minValue) minValue = values[i];

        //Determine maximum:
        if (values[i] > maxValue) maxValue = values[i];

        //Determine value at cursor position:
        if (i >= cursorX/90f*(values.length-1) && i < (cursorX+1)/90f*(values.length-1)) cursorY = values[i];

        //Calculate sum:
        sum += values[i];

        //Draw:
        line(x+5+(i-1)*(90)/(values.length-1), 20*map(prev, pminValue, pmaxValue, -1, 1)+yps+20, x+5+(i)*(90)/(values.length-1), yps+20+20*map(values[i], pminValue, pmaxValue, -1, 1));
        prev = values[i];
      }
      pminValue = minValue;
      pmaxValue = maxValue;
      strokeWeight(1);
      stroke(180);
      line(cursorX+x+5, yps, cursorX+x+5, yps+40);
      yps += 50;
      if (details)
      {
        stroke(0);
        text("Size: " + values.length, x+105, y+20);
        text("X: " + cursorX*values.length/90f, x+105, y+35);
        text("Y: " + cursorY, x+105, y+50);
        text("Min: " + minValue, x+105, y+65);
        text("Max: " + maxValue, x+105, y+95);
        text("Average: " + sum/values.length, x+105, y+80);
      }
    }
    if (frame != null)
    {

      fill(0);
      noStroke();
      rect(x+5, yps, 90, 90);

      frame.drawFrame(x+5, yps, 0, 90, 90, 0, false, true);

      if (details)
      {
        stroke(0);
        if (values.length > 0)
        {
          strokeWeight(1);
          line(x+105, yps-5, x+245, yps-5);
        }
        text("Points: " + frame.points.size(), x+105, yps+15);
        text("Name: " + frame.frameName, x+105, yps+30);
        text("Company: " + frame.companyName, x+105, yps+45);
        text("Palette: " + (frame.palette ? "Yes" : "No"), x+105, yps+60);
        text("Ilda format: " + frame.ildaVersion, x+105, yps+75);
      }
    }
    frame = null;
    values = new float[0];
  }

  public void generateGui()
  {
    gui.add(new GuiClose(sizex-15, 0));
    gui.add(new GuiToggle(sizex-45, 25, 40, 15, "Details"));
  }

  public void generateNodes()
  {
    //RelX, RelY, name, type (0 = frame, 1 = float[], 2 = float)
    nodes.add(new InNode(10, 25, "Input_fl", 1));
    nodes.add(new InNode(10, 45, "Input_fr", 0));
  }

  public void nodeInput(String nodeName, Frame inputFrame)
  {
    if (nodeName.equals("Input_fr"))
    {
      if (inputFrame != null)
      {
        frame = new Frame(inputFrame);
      }
    }
  }

  public void nodeInput(String nodeName, float[] input)
  {
    if (nodeName.equals("Input_fl")) 
    {
      values = input;
    }
  }

  public void guiActionDetected()
  {
    for (GuiElement element : gui)
    {
      if (element.active) 
      {
        if (element.name.equals("Details"))
        { 
          element.active = false;

          toggleDetails(1-element.getValue());
          element.setValue(1-element.getValue());
        }

        if (element.name.equals("close"))
        { 
          element.active = false;
          closeElement();
        }
      }
    }
  }

  public void toggleDetails(float value)
  {
    if (value == 1)
    {
      details = true;
      xValue = 250;
    } else
    {
      details = false;
      xValue = 100;
    }
  }
}

class Oscitranslate extends Oscillelement
{
  float[] tx = {    //Three float arrays which store the value by which to translate
    0               //They can have more than one value so each point can be translated over a different amount
  };
  float[] ty = {
    0
  };
  float[] tz = {
    0
  };
  Frame startFrame = new Frame();
  Frame translatedFrame = new Frame();
  float newYValue = 110;

  Oscitranslate(int x, int y)
  {
    super(x, y, 100, 110, "Translate");
    generateGui();
    generateNodes();
  }

  Oscitranslate(String[] input)
  {
    super(input);
    sizex = 100;
    sizey = 110;
    generateGui();
    generateNodes();
  }

  public void update()
  {
    super.update();
    reachSize(sizex, newYValue);
    translatedFrame.points.clear();
    if (startFrame != null) 
    {
      //mapArray(int newSize, float[] input, float defaultvalue) interpolates the array
      float[] ttx = mapArray(startFrame.points.size(), tx, 0);
      float[] tty = mapArray(startFrame.points.size(), ty, 0);
      float[] ttz = mapArray(startFrame.points.size(), tz, 0);

      for (int i = 0; i < startFrame.points.size (); i++)
      {
        Point point = new Point(startFrame.points.get(i));

        //Linearly interpolate between the inputvalues:
        float xind = map(ttx[i], 0, 1, 0, width);
        float yind = map(tty[i], 0, 1, 0, height);
        float zind = map(ttz[i], 0, 1, 0, depth);

        point.position.x += xind; //Translate
        point.position.y += yind;
        point.position.z += zind;
        translatedFrame.points.add(point);
      }
    }
  }

  public void generateGui()
  {
    gui.add(new GuiClose(sizex-15, 0));
  }

  public void generateNodes()
  {
    //RelX, RelY, name, type (0 = frame, 1 = float[], 2 = float)
    nodes.add(new InNode(10, 25, "Input", 0));
    nodes.add(new InNode(10, 50, "X", 1));
    nodes.add(new InNode(10, 70, "Y", 1));
    nodes.add(new InNode(10, 90, "Z", 1));
    nodes.add(new OutNode(sizex-10, 25, "Output", 0));
  }

  //Gets called by the connection
  public void nodeInput(String nodeName, Frame inputFrame)
  {
    if (nodeName.equals("Input"))
    {
      if (inputFrame != null)
      {
        startFrame.points.clear();
        Frame stupidcrapJava = new Frame(inputFrame);  //clone the frame so the original one doesn't get translated as well
        for (Point point : stupidcrapJava.points)
        {
          startFrame.points.add(new Point(point.clone(point)));
        }
      }
    }
  }

  public void nodeInput(String nodeName, float[] input)
  {
    if (nodeName.equals("X")) tx = input;
    if (nodeName.equals("Y")) ty = input;
    if (nodeName.equals("Z")) tz = input;
  }

  public Frame getFrameValue(String outName)
  {
    if (outName.equals("Output"))
    {
      return translatedFrame.clone();
    }
    return null;
  }

  public void guiActionDetected()
  {
    for (GuiElement element : gui)
    {
      if (element.active) 
      {
        if (element.name.equals("Options"))
        { 
          element.active = false;

          toggleOptions(element.getValue());
          element.setValue(1-element.getValue());
        }

        if (element.name.equals("close"))
        { 
          element.active = false;
          closeElement();
        }
      }
    }
  }

  public void resetNode(Node node)
  {
    if (node.name.equals("X"))
    {
      tx = new float[0];
    }
    if (node.name.equals("Y"))
    {
      ty = new float[0];
    }
    if (node.name.equals("Z"))
    {
      tz = new float[0];
    }
  }

  public void toggleOptions(float displayThem)
  {
    if (displayThem == 1)
    {
      for (GuiElement element : gui)
      {
        if (!element.name.equals("Options") && !element.name.equals("close")) 
        {
          element.visible = true;
        }
      }
      newYValue = 225;
    } else
    {
      for (GuiElement element : gui)
      {
        if (!element.name.equals("Options") && !element.name.equals("close")) 
        {
          element.visible = false;
        }
      }
      newYValue = 110;
    }
  }
}

class Oscirotate extends Oscillelement
{
  float[] rx = {
    0
  };
  float[] ry = {
    0
  };
  float[] rz = {
    0
  };
  //Anchor point(s):
  float[] anx = {
    0.5f
  };
  float[] any = {
    0.5f
  };
  float[] anz = {
    0.5f
  };
  Frame startFrame = new Frame();
  Frame rotatedFrame = new Frame();
  boolean pivot = false;

  Oscirotate(int x, int y)
  {
    super(x, y, 100, 110, "Rotate");
    generateGui();
    generateNodes();
  }

  Oscirotate(String[] input)
  {
    super(input);
    sizex = 100;
    sizey = 110;
    generateGui();
    generateNodes();
    for (String arg : input)
    {
      String[] q = splitTokens(arg);
      if (q.length >= 2)
      {
        if (q[0].equals("Pivot") )
        {
          pivot = PApplet.parseBoolean(q[1]);
          if (pivot)
          {
            for (GuiElement el : gui)
            {
              if (el.name.equals("Pivot point"))
              {
                el.active = false;
                el.visible = false;
              }
              sizey = 170;

              nodes.add(new InNode(10, 110, "Pivot X", 1));
              nodes.add(new InNode(10, 130, "Pivot Y", 1));
              nodes.add(new InNode(10, 150, "Pivot Z", 1));
            }
          }
        }
      }
    }
  }

  public void update()
  {
    super.update();
    rotatedFrame.points.clear();
    if (startFrame != null) 
    {

      //mapArray(int newSize, float[] input, float defaultvalue) interpolates the array
      float[] rrx = mapArray(startFrame.points.size(), rx, 0);    //the angles 
      float[] rry = mapArray(startFrame.points.size(), ry, 0);
      float[] rrz = mapArray(startFrame.points.size(), rz, 0);
      float[] aanx = mapArray(startFrame.points.size(), anx, 0);    //The anchor point
      float[] aany = mapArray(startFrame.points.size(), any, 0);
      float[] aanz = mapArray(startFrame.points.size(), anz, 0);

      float theta, phi, psi;
      float prevtheta = 1; 
      float prevphi = 1;  
      float prevpsi = 1; 
      float[][] R = new float[3][3];    //The rotation matrix

      for (int i = 0; i < startFrame.points.size (); i++)
      {
        Point point = new Point(startFrame.points.get(i)); 

        //Rescale the angles
        theta = rrx[i]*TWO_PI;
        phi = rry[i]*TWO_PI;
        psi = rrz[i]*TWO_PI;

        //Only calculate the matrix when necessary:
        if (theta != prevtheta || phi != prevphi || psi != prevpsi)
        {
          R = calculateRotationMatrix(theta, phi, psi);
          prevtheta = theta;
          prevphi = phi;
          prevpsi = psi;
        }

        float xind = point.position.x - aanx[i]*width;
        float yind = point.position.y - aany[i]*height;
        float zind = point.position.z - aanz[i]*depth;



        // x' = Rx (matrix multiplication)
        float xnew = R[0][0]*xind + R[0][1]*yind + R[0][2]*zind;
        float ynew = R[1][0]*xind + R[1][1]*yind + R[1][2]*zind;
        float znew = R[2][0]*xind + R[2][1]*yind + R[2][2]*zind;

        //Add the anchor point:
        point.position.x = xnew + aanx[i]*width;
        point.position.y = ynew + aany[i]*height;
        point.position.z = znew + aanz[i]*depth;
        rotatedFrame.points.add(point);
      }
    }
  }



  public void generateGui()
  {
    //gui.add(new GuiDropdown(5, 80, 90, 20, "Options", true));
    gui.add(new GuiClose(sizex-15, 0));
    gui.add(new GuiButton(sizex-60, 80, 55, 20, "Pivot point"));
  }

  public void generateNodes()
  {
    //RelX, RelY, name, type (0 = frame, 1 = float[], 2 = float)
    nodes.add(new InNode(10, 25, "Input", 0));
    nodes.add(new InNode(10, 50, "X", 1));
    nodes.add(new InNode(10, 70, "Y", 1));
    nodes.add(new InNode(10, 90, "Z", 1));
    nodes.add(new OutNode(sizex-10, 25, "Output", 0));
  }

  public void nodeInput(String nodeName, Frame inputFrame)
  {

    if (nodeName.equals("Input"))
    {
      if (inputFrame != null)
      {
        startFrame.points.clear();
        Frame stupidcrapJava = new Frame(inputFrame);
        for (Point point : stupidcrapJava.points)
        {
          startFrame.points.add(new Point(point.clone(point)));
        }
      }
    }
  }

  public void nodeInput(String nodeName, float[] input)
  {
    if (nodeName.equals("X")) rx = input;
    if (nodeName.equals("Y")) ry = input;
    if (nodeName.equals("Z")) rz = input;
    if (nodeName.equals("Pivot X")) anx = input;
    if (nodeName.equals("Pivot Y")) any = input;
    if (nodeName.equals("Pivot Z")) anz = input;
  }

  public Frame getFrameValue(String outName)
  {
    if (outName.equals("Output"))
    {
      return rotatedFrame.clone();
    }
    return null;
  }

  public void guiActionDetected()
  {
    for (GuiElement element : gui)
    {
      if (element.active) 
      {
        if (element.name.equals("Pivot point"))
        { 
          element.active = false;
          element.visible = false;
          sizey = 170;

          nodes.add(new InNode(10, 110, "Pivot X", 1));
          nodes.add(new InNode(10, 130, "Pivot Y", 1));
          nodes.add(new InNode(10, 150, "Pivot Z", 1));

          pivot = true;
        }

        if (element.name.equals("close"))
        { 
          element.active = false;
          closeElement();
        }
      }
    }
  }

  public void resetNode(Node node)
  {
    if (node.name.equals("X"))
    {
      rx = new float[0];
    }
    if (node.name.equals("Y"))
    {
      ry = new float[0];
    }
    if (node.name.equals("Z"))
    {
      rz = new float[0];
    }
    if (node.name.equals("Pivot X"))
    {
      anx = new float[0];
    }
    if (node.name.equals("Pivot Y"))
    {
      any = new float[0];
    }
    if (node.name.equals("Pivot Z"))
    {
      anz = new float[0];
    }
  }
}

class Osciscale extends Oscillelement
{
  float[] whole = {
    1
  };
  float[] sx = {
    1
  };
  float[] sy = {
    1
  };
  float[] sz = {
    1
  };
  //Anchor point(s):
  float[] anx = {
    0.5f
  };
  float[] any = {
    0.5f
  };
  float[] anz = {
    0.5f
  };
  Frame startFrame = new Frame();
  Frame scaledFrame = new Frame();
  boolean anchor = false;

  Osciscale(int x, int y)
  {
    super(x, y, 100, 130, "Scale");
    generateGui();
    generateNodes();
  }

  Osciscale(String[] input)
  {
    super(input);
    sizex = 100;
    sizey = 130;
    generateGui();
    generateNodes();
    for (String arg : input)
    {
      String[] q = splitTokens(arg);
      if (q.length >= 2)
      {
        if (q[0].equals("Anchor") )
        {
          anchor = PApplet.parseBoolean(q[1]);
          if (anchor)
          {
            for (GuiElement el : gui)
            {
              if (el.name.equals("Anchor point"))
              {
                el.active = false;
                el.visible = false;
              }
              sizey = 190;

              nodes.add(new InNode(10, 130, "Anchor X", 1));
              nodes.add(new InNode(10, 150, "Anchor Y", 1));
              nodes.add(new InNode(10, 170, "Anchor Z", 1));
            }
          }
        }
      }
    }
  }

  public void update()
  {
    super.update();
    scaledFrame.points.clear();
    if (startFrame != null) 
    {

      //mapArray(int newSize, float[] input, float defaultvalue) interpolates the array
      whole = mapArray(startFrame.points.size(), whole, 1);
      float[] ssx = mapArray(startFrame.points.size(), sx, 1);
      float[] ssy = mapArray(startFrame.points.size(), sy, 1);
      float[] ssz = mapArray(startFrame.points.size(), sz, 1);
      float[] aanx = mapArray(startFrame.points.size(), anx, 0.5f);
      float[] aany = mapArray(startFrame.points.size(), any, 0.5f);
      float[] aanz = mapArray(startFrame.points.size(), anz, 0.5f);

      for (int i = 0; i < startFrame.points.size (); i++)
      {
        Point point = new Point(startFrame.points.get(i)); 

        float xind = point.position.x - aanx[i]*width;
        float yind = point.position.y - aany[i]*height;
        float zind = point.position.z - aanz[i]*depth;

        xind = ssx[i]*xind*whole[i];
        yind = ssy[i]*yind*whole[i];
        zind = ssz[i]*zind*whole[i];

        point.position.x = xind + aanx[i]*width;
        point.position.y = yind + aany[i]*height;
        point.position.z = zind + aanz[i]*depth;
        scaledFrame.points.add(point);
      }
    }
  }

  public void generateGui()
  {
    //gui.add(new GuiDropdown(5, 80, 90, 20, "Options", true));
    gui.add(new GuiClose(sizex-15, 0));
    gui.add(new GuiButton(sizex-60, 100, 55, 20, "Anchor point"));
  }

  public void generateNodes()
  {
    //RelX, RelY, name, type (0 = frame, 1 = float[], 2 = float)
    nodes.add(new InNode(10, 25, "Input", 0));
    nodes.add(new InNode(10, 50, "Combined", 1));
    nodes.add(new InNode(10, 70, "X", 1));
    nodes.add(new InNode(10, 90, "Y", 1));
    nodes.add(new InNode(10, 110, "Z", 1));
    nodes.add(new OutNode(sizex-10, 25, "Output", 0));
  }

  public void nodeInput(String nodeName, Frame inputFrame)
  {

    if (nodeName.equals("Input"))
    {
      if (inputFrame != null)
      {
        startFrame.points.clear();
        Frame stupidcrapJava = new Frame(inputFrame);
        for (Point point : stupidcrapJava.points)
        {
          startFrame.points.add(new Point(point.clone(point)));
        }
      }
    }
  }

  public void nodeInput(String nodeName, float[] input)
  {
    if (nodeName.equals("Combined")) whole = input;
    if (nodeName.equals("X")) sx = input;
    if (nodeName.equals("Y")) sy = input;
    if (nodeName.equals("Z")) sz = input;
    if (nodeName.equals("Anchor X")) anx = input;
    if (nodeName.equals("Anchor Y")) any = input;
    if (nodeName.equals("Anchor Z")) anz = input;
  }

  public Frame getFrameValue(String outName)
  {
    if (outName.equals("Output"))
    {
      return scaledFrame.clone();
    }
    return null;
  }

  public void guiActionDetected()
  {
    for (GuiElement element : gui)
    {
      if (element.active) 
      {
        if (element.name.equals("Anchor point"))
        { 
          element.active = false;
          element.visible = false;
          sizey = 190;

          nodes.add(new InNode(10, 130, "Anchor X", 1));
          nodes.add(new InNode(10, 150, "Anchor Y", 1));
          nodes.add(new InNode(10, 170, "Anchor Z", 1));

          anchor = true;
        }

        if (element.name.equals("close"))
        { 
          element.active = false;
          closeElement();
        }
      }
    }
  }

  public void resetNode(Node node)
  {
    if (node.name.equals("X"))
    {
      sx = new float[0];
    }
    if (node.name.equals("Y"))
    {
      sy = new float[0];
    }
    if (node.name.equals("Z"))
    {
      sz = new float[0];
    }
    if (node.name.equals("Anchor X"))
    {
      anx = new float[0];
    }
    if (node.name.equals("Anchor Y"))
    {
      any = new float[0];
    }
    if (node.name.equals("Anchor Z"))
    {
      anz = new float[0];
    }
    if (node.name.equals("Combined"))
    {
      whole = new float[0];
    }
  }

  public String[] getElementAsString()
  {
    String[] superList = super.getElementAsString();
    StringList args = new StringList();
    args.append("Anchor " + anchor);

    return concat(superList, args.array());
  }
}

class Oscibreakout extends Oscillelement
{

  Frame startFrame = new Frame();

  Oscibreakout(int x, int y)
  {
    super(x, y, 100, 200, "Breakout");
    generateGui();
    generateNodes();
  }

  Oscibreakout(String[] input)
  {
    super(input);
    sizex = 100;
    sizey = 200;
    generateGui();
    generateNodes();
  }

  public void update()
  {
    super.update();
  }

  public void generateGui()
  {
    //gui.add(new GuiDropdown(5, 80, 90, 20, "Options", true));
    gui.add(new GuiClose(sizex-15, 0));
  }

  public void generateNodes()
  {
    //RelX, RelY, name, type (0 = frame, 1 = float[], 2 = float)
    nodes.add(new InNode(10, 25, "Input", 0));
    nodes.add(new OutNode(sizex-10, 25, "X", 1));
    nodes.add(new OutNode(sizex-10, 45, "Y", 1));
    nodes.add(new OutNode(sizex-10, 65, "Z", 1));
    nodes.add(new OutNode(sizex-10, 85, "R", 1));
    nodes.add(new OutNode(sizex-10, 105, "G", 1));
    nodes.add(new OutNode(sizex-10, 125, "B", 1));
    nodes.add(new OutNode(sizex-10, 145, "Total points", 1));
    nodes.add(new OutNode(sizex-10, 165, "Blank", 1));
    nodes.add(new OutNode(sizex-10, 185, "Palette index", 1));
  }

  public void nodeInput(String nodeName, Frame inputFrame)
  {

    if (nodeName.equals("Input"))
    {
      if (inputFrame != null)
      {
        startFrame.points.clear();
        Frame stupidcrapJava = new Frame(inputFrame);
        for (Point point : stupidcrapJava.points)
        {
          startFrame.points.add(new Point(point.clone(point)));
        }
      }
    }
  }

  public float[] getFloatArrayValue(String outName)
  {
    if (outName.equals("X"))
    {
      float[] out = new float[startFrame.points.size()];
      for (int i = 0; i < startFrame.points.size (); i++)
      {
        out[i] = startFrame.points.get(i).position.x/width-0.5f;
      }
      return out;
    }
    if (outName.equals("Y"))
    {
      float[] out = new float[startFrame.points.size()];
      for (int i = 0; i < startFrame.points.size (); i++)
      {
        out[i] = startFrame.points.get(i).position.y/height-0.5f;
      }
      return out;
    }
    if (outName.equals("Z"))
    {
      float[] out = new float[startFrame.points.size()];
      for (int i = 0; i < startFrame.points.size (); i++)
      {
        out[i] = startFrame.points.get(i).position.z/depth-0.5f;
      }
      return out;
    }
    if (outName.equals("R"))
    {
      float[] out = new float[startFrame.points.size()];
      for (int i = 0; i < startFrame.points.size (); i++)
      {
        out[i] = PApplet.parseFloat((startFrame.points.get(i).colour >> 16) & 0xFF)/255;
      }
      return out;
    }
    if (outName.equals("G"))
    {
      float[] out = new float[startFrame.points.size()];
      for (int i = 0; i < startFrame.points.size (); i++)
      {
        out[i] = PApplet.parseFloat((startFrame.points.get(i).colour >> 8) & 0xFF)/255;
      }
      return out;
    }
    if (outName.equals("B"))
    {
      float[] out = new float[startFrame.points.size()];
      for (int i = 0; i < startFrame.points.size (); i++)
      {
        out[i] = PApplet.parseFloat(startFrame.points.get(i).colour & 0xFF)/255;
      }
      return out;
    }
    if (outName.equals("Total points"))
    {
      float[] out = new float[startFrame.points.size()];
      for (int i = 0; i < startFrame.points.size (); i++)
      {
        out[i] = startFrame.points.size();
      }
      return out;
    }
    if (outName.equals("Blank"))
    {
      float[] out = new float[startFrame.points.size()];
      for (int i = 0; i < startFrame.points.size (); i++)
      {
        out[i] = (float) PApplet.parseInt(startFrame.points.get(i).blanked);
      }
      return out;
    }
    if (outName.equals("Palette index"))
    {
      float[] out = new float[startFrame.points.size()];
      for (int i = 0; i < startFrame.points.size (); i++)
      {
        out[i] = (float) startFrame.points.get(i).paletteIndex;
      }
      return out;
    }


    float[] empty = {
      0
    };
    return empty;
  }

  public void guiActionDetected()
  {
    for (GuiElement element : gui)
    {
      if (element.active) 
      {
        if (element.name.equals("close"))
        { 
          element.active = false;
          closeElement();
        }
      }
    }
  }
}

class Oscibreakin extends Oscillelement
{

  Frame outFrame = new Frame();
  int numberOfPoints = 200;
  int prevPoints = 0;

  Oscibreakin(int x, int y)
  {
    super(x, y, 100, 200, "Breakin");
    generateGui();
    generateNodes();
  }

  Oscibreakin(String[] input)
  {
    super(input);
    sizex = 100;
    sizey = 200;
    generateGui();
    generateNodes();
    for (String arg : input)
    {
      String[] q = splitTokens(arg);
      if (q.length >= 2)
      {
        if (q[0].equals("NumberOfPoints") )
        {
          numberOfPoints = PApplet.parseInt(q[1]);

          for (int i = 1; i <= numberOfPoints; i++)
          {
            outFrame.points.add(new Point(width*0.5f, height*0.5f, depth*0.5f, 0, 0, 0, true));
          }
        }
      }
    }
  }

  public void update()
  {
    super.update();
    if (prevPoints != numberOfPoints)
    {
      outFrame = new Frame();
      for (int i = 0; i < numberOfPoints; i++)
      {
        outFrame.points.add( new Point(width*0.5f, height*0.5f, depth*0.5f, 0, 0, 0, false));
      }
      prevPoints = numberOfPoints;
    }
  }

  public void generateGui()
  {
    //gui.add(new GuiDropdown(5, 80, 90, 20, "Options", true));
    gui.add(new GuiClose(sizex-15, 0));
  }

  public void generateNodes()
  {
    //RelX, RelY, name, type (0 = frame, 1 = float[], 2 = float)
    nodes.add(new OutNode(sizex-10, 25, "Output", 0));
    nodes.add(new InNode(10, 25, "X", 1));
    nodes.add(new InNode(10, 45, "Y", 1));
    nodes.add(new InNode(10, 65, "Z", 1));
    nodes.add(new InNode(10, 85, "R", 1));
    nodes.add(new InNode(10, 105, "G", 1));
    nodes.add(new InNode(10, 125, "B", 1));
    nodes.add(new InNode(10, 145, "Total points", 1));
    nodes.add(new InNode(10, 165, "Blank", 1));
    nodes.add(new InNode(10, 185, "Palette index", 1));
  }

  public void nodeInput(String nodeName, float[] input)
  {
    int l = outFrame.points.size();
    if (nodeName.equals("X"))
    {
      input = mapArray(l, input, 0);
      for (int i = 0; i < input.length; i++)
      {
        outFrame.points.get(i).position.x = (input[i]+0.5f)*width;
      }
    }
    if (nodeName.equals("Y"))
    {
      input = mapArray(l, input, 0);
      for (int i = 0; i < input.length; i++)
      {
        outFrame.points.get(i).position.y = (input[i]+0.5f)*height;
      }
    }
    if (nodeName.equals("Z"))
    {
      input = mapArray(l, input, 0);
      for (int i = 0; i < input.length; i++)
      {
        outFrame.points.get(i).position.z = (input[i]+0.5f)*depth;
      }
    }
    if (nodeName.equals("R"))
    {
      input = mapArray(l, input, 0);
      for (int i = 0; i < input.length; i++)
      {
        int nlg = outFrame.points.get(i).colour;
        nlg = color(max(0, min(abs(input[i])*255, 255)), (nlg>> 8) & 0xFF, nlg & 0xFF);
        outFrame.points.get(i).colour = nlg;
      }
    }
    if (nodeName.equals("G"))
    {
      input = mapArray(l, input, 0);
      for (int i = 0; i < input.length; i++)
      {
        int delair = outFrame.points.get(i).colour;
        delair = color((delair >> 16) & 0xFF, max(0, min(abs(input[i])*255, 255)), delair & 0xFF);
        outFrame.points.get(i).colour = delair;
      }
    }
    if (nodeName.equals("B"))
    {
      input = mapArray(l, input, 0);
      for (int i = 0; i < input.length; i++)
      {
        int delair = outFrame.points.get(i).colour;
        delair = color((delair >> 16) & 0xFF, (delair >> 8) & 0xFF, max(0, min(abs(input[i])*255, 255)));
        outFrame.points.get(i).colour = delair;
      }
    }
    if (nodeName.equals("Total points"))
    {
      if (input.length > 0) numberOfPoints = (int) input[0];
    }
    if (nodeName.equals("Blank"))
    {
      input = mapArray(l, input, 0);
      for (int i = 0; i < input.length; i++)
      {
        if (input[i] > 0.5f) outFrame.points.get(i).blanked = true;
      }
    }
    if (nodeName.equals("Palette index"))
    {
      input = mapArray(l, input, 0);
      for (int i = 0; i < input.length; i++)
      {
        outFrame.points.get(i).paletteIndex = (int) input[i];
      }
    }
  }

  public Frame getFrameValue(String outName)
  {
    if (outName.equals("Output")) return outFrame;
    return null;
  }

  public void guiActionDetected()
  {
    for (GuiElement element : gui)
    {
      if (element.active) 
      {
        if (element.name.equals("close"))
        { 
          element.active = false;
          closeElement();
        }
      }
    }
  }
}

class Oscicolour extends Oscillelement
{

  Frame outFrame = new Frame();
  Frame inFrame = new Frame();
  boolean multiply = false;
  float[] r = {
    1
  };
  float[] g = {
    1
  };
  float[] b = {
    1
  };
  float[] ity = {
    1
  };

  Oscicolour(int x, int y)
  {
    super(x, y, 100, 120, "RGB");
    generateGui();
    generateNodes();
  }

  Oscicolour(String[] input)
  {
    super(input);
    sizex = 100;
    sizey = 120;
    generateGui();
    generateNodes();
    for (String arg : input)
    {
      String[] q = splitTokens(arg);
      if (q.length >= 2)
      {
        if (q[0].equals("Multiply") )
        {
          multiply = PApplet.parseBoolean(q[1]);
        }
      }
    }
  }

  public void update()
  {
    super.update();
    int l = inFrame.points.size();
    if (multiply)
    {
      r = mapArray(l, r, 1);
      g = mapArray(l, g, 1);
      b = mapArray(l, b, 1);
    } else
    {
      r = mapArray(l, r, 0);
      g = mapArray(l, g, 0);
      b = mapArray(l, b, 0);
    }
    ity = mapArray(l, ity, 1);
    outFrame = new Frame(inFrame.clone());
    for (int i = 0; i < l; i++)
    {
      if (multiply)
      {
        int nlg = outFrame.points.get(i).colour;
        nlg = color(   max(0, min(((nlg >> 16) & 0xFF) * r[i]*ity[i], 255)), max(0, min(((nlg >> 8) & 0xFF) * g[i]*ity[i], 255)), max(0, min(((nlg  & 0xFF) * b[i]*ity[i]), 255)));
        outFrame.points.get(i).colour = nlg;
      } else
      {
        outFrame.points.get(i).colour = color(max(0, min((r[i]*ity[i])*255, 255)), max(0, min((g[i]*ity[i])*255, 255)), max(0, min((b[i]*ity[i])*255, 255)));
      }
    }
  }

  public void generateGui()
  {
    gui.add(new GuiButton(sizex - 55, 70, 50, 20, "Overwrite"));
    gui.add(new GuiClose(sizex-15, 0));
  }

  public void generateNodes()
  {
    //RelX, RelY, name, type (0 = frame, 1 = float[], 2 = float)
    nodes.add(new OutNode(sizex-10, 25, "Output", 0));
    nodes.add(new InNode(10, 25, "Input", 0));
    nodes.add(new InNode(10, 45, "R", 1));
    nodes.add(new InNode(10, 65, "G", 1));
    nodes.add(new InNode(10, 85, "B", 1));
    nodes.add(new InNode(10, 105, "I", 1));
  }

  public void nodeInput(String nodeName, Frame input)
  {
    if (nodeName.equals("Input")) 
    {
      if (input != null) inFrame = new Frame(input.clone());
    }
  }

  public void nodeInput(String nodeName, float[] input)
  {

    if (nodeName.equals("R"))
    {
      if (input != null) r = input;
    }
    if (nodeName.equals("G"))
    {
      if (input != null) g = input;
    }
    if (nodeName.equals("B"))
    {
      if (input != null) b = input;
    }
    if (nodeName.equals("I"))
    {
      if (input != null) ity = input;
    }
  }

  public void resetNode(Node node)
  {
    if (node.name.equals("R"))
    {
      r = new float[0];
    }
    if (node.name.equals("G"))
    {
      g = new float[0];
    }
    if (node.name.equals("B"))
    {
      b = new float[0];
    }
    if (node.name.equals("I"))
    {
      ity = new float[0];
    }
  }

  public Frame getFrameValue(String outName)
  {
    if (outName.equals("Output")) return outFrame;
    return null;
  }

  public void guiActionDetected()
  {
    for (GuiElement element : gui)
    {
      if (element.active) 
      {
        if (element.name.equals("close"))
        { 
          element.active = false;
          closeElement();
        }
        if (element.name.equals("Overwrite"))
        { 
          element.active = false;
          if (multiply)
          {
            multiply = false;
            element.text = "Overwrite";
          } else
          {
            multiply = true;
            element.text = "Multiply";
          }
          r = new float[0];
          g = new float[0];
          b = new float[0];
          ity = new float[0];
        }
      }
    }
  }

  public String[] getElementAsString()
  {
    String[] superList = super.getElementAsString();
    StringList args = new StringList();
    args.append("Multiply " + multiply);

    return concat(superList, args.array());
  }
}

class Oscipalette extends Oscillelement
{
  Frame outFrame = new Frame();
  Frame inFrame = new Frame();
  Palette palette;
  float newYValue = 80;
  boolean options = false;
  boolean connected = false;
  int palind = activePalette;

  float[] ind = {
    0
  };


  Oscipalette(int x, int y)
  {
    super(x, y, 100, 80, "Palette");
    generateGui();
    generateNodes();
    if (activePalette < palettes.size() && activePalette >= 0) palette = palettes.get(activePalette);
    for (GuiElement element : gui)
    {
      if (!element.name.equals("Options") && !element.name.equals("close")) 
      {
        element.visible = false;
      }
    }
  }

  Oscipalette(String[] input)
  {
    super(input);
    sizex = 100;
    sizey = 80;
    generateGui();
    generateNodes();
    for (String arg : input)
    {
      String[] q = splitTokens(arg);
      if (q.length >= 2)
      {
        if (q[0].equals("GUI") )
        {
          if (q[1].equals("Options"))
          { 
            toggleOptions(PApplet.parseFloat(q[2]));
            if (PApplet.parseFloat(q[2]) == 0) options = false;
          }
        }
        if (q[0].equals("Palettefile"))
        {
          String paletteName = q[1];
          if (q.length > 2)
          {
            for (int i = 2; i < q.length; i++)
            {
              paletteName = paletteName + " " + q[i];
            }
          }

          File selection = sequenceCreator.osc.openedLocation;
          String blah = selection.getPath();
          String[] fixedPath = splitTokens(blah, ".");
          String path = "";
          if (fixedPath.length > 1)
          {
            for (int i = 0; i < fixedPath.length-1; i++)
            {
              path = path + fixedPath[i];
            }
          } else path = fixedPath[0];

          path = path + paletteName;
          PImage img;
          try {
            img = loadImage(path);
          }
          catch(Exception e)
          {
            status.add("Error when trying to load in palette");
            return;
          }

          palette = new Palette("ReadedPalette");

          for ( int i = 0; i < min (img.width, 256); i++)
          {
            palette.addColour(img.get(i, 0));
          }
        }
      }
    }

    if (palette == null && activePalette < palettes.size() && activePalette >= 0) palette = palettes.get(activePalette);

    if (!options)
    {
      for (GuiElement element : gui)
      {
        if (!element.name.equals("Options") && !element.name.equals("close")) 
        {
          element.visible = false;
        }
      }
    }
  }

  public void update()
  {
    super.update();
    reachSize(sizex, newYValue);
    int l = inFrame.points.size();   
    ind = mapArray(l, ind, 0);
    outFrame = new Frame(inFrame.clone());
    outFrame.palette = true;
    if (connected)
    {
      for (int i = 0; i < l; i++)
      {

        outFrame.points.get(i).paletteIndex = (int) ind[i];
      }
    }
    outFrame.palettePaint(palette);
    connected = false;
  }

  public void display(boolean hide)
  {
    super.display(hide);
    if (hide) return;

    if (options)
    {
      int i = 0;
      for (PaletteColour colour : palette.colours)
      {
        noStroke();

        colour.displayColour((int) x+10+5*(i%16), (int) y+110+5*PApplet.parseInt(i/16), 5);
        i++;
      }
      fill(0);
      textAlign(LEFT);
      textFont(f10);
      text(palette.name, x+10, y+127+5*(palette.colours.size()/16));
    }
  }

  public void generateGui()
  {
    gui.add(new GuiDropdown(5, 50, 90, 20, "Options", true));
    gui.add(new GuiButton(5, 80, 40, 20, "<<"));
    gui.add(new GuiButton(55, 80, 40, 20, ">>"));
    gui.add(new GuiClose(sizex-15, 0));
  }

  public void generateNodes()
  {
    //RelX, RelY, name, type (0 = frame, 1 = float[], 2 = float)
    nodes.add(new OutNode(sizex-10, 25, "Output", 0));
    nodes.add(new InNode(10, 25, "Input", 0));
    nodes.add(new InNode(10, 45, "Index", 1));
  }

  public void nodeInput(String nodeName, Frame input)
  {
    if (nodeName.equals("Input")) 
    {
      if (input != null) inFrame = new Frame(input.clone());
    }
  }

  public void nodeInput(String nodeName, float[] input)
  {

    if (nodeName.equals("Index"))
    {
      connected = true;
      if (input != null) ind = input;
    }
  }

  public void resetNode(Node node)
  {

    if (node.name.equals("Index"))
    {
      ind = new float[0];
    }
  }

  public Frame getFrameValue(String outName)
  {
    if (outName.equals("Output")) return outFrame;
    return null;
  }

  public void guiActionDetected()
  {
    for (GuiElement element : gui)
    {
      if (element.active) 
      {
        if (element.name.equals("close"))
        { 
          element.active = false;
          closeElement();
        }
        if (element.name.equals("Options"))
        {
          element.active  = false;
          toggleOptions(element.getValue());
          element.setValue(1-element.getValue());
        }
        if (element.name.equals("<<"))
        {
          element.active  = false;
          palind--;
          if (palind < 0) palind = palettes.size()-1;
          palette = palettes.get(palind);
          newYValue = 135 + 5*(palette.colours.size()/16);
        }
        if (element.name.equals(">>"))
        {
          element.active  = false;
          palind++;
          if (palind >= palettes.size() ) palind = 0;
          palette = palettes.get(palind);
          newYValue = 135 + 5*(palette.colours.size()/16);
        }
      }
    }
  }

  public void toggleOptions(float displayThem)
  {
    if (displayThem == 1)
    {
      for (GuiElement element : gui)
      {
        if (!element.name.equals("Options") && !element.name.equals("close")) 
        {
          element.visible = true;
        }
      }
      newYValue = 135 + 5*((int) palette.colours.size()/16);
      options = true;
    } else
    {
      for (GuiElement element : gui)
      {
        if (!element.name.equals("Options") && !element.name.equals("close")) 
        {
          element.visible = false;
        }
      }
      newYValue = 80;
      options = false;
    }
  }

  public String[] getElementAsString()
  {
    String[] superList = super.getElementAsString();
    StringList args = new StringList();
    if (palette != null)
    {
      File selection = sequenceCreator.osc.openedLocation;
      String blah = selection.getPath();
      String[] fixedPath = splitTokens(blah, ".");
      String path = "";
      if (fixedPath.length > 1)
      {
        for (int i = 0; i < fixedPath.length-1; i++)
        {
          path = path + fixedPath[i];
        }
      } else path = fixedPath[0];
      path = path + palette.name;

      args.append("Palettefile " + palette.name);

      PImage pg = createImage(palette.colours.size(), 1, RGB);
      for (int i = 0; i < palette.colours.size (); i++)
      {
        pg.pixels[i] = palette.colours.get(i).getColour();
      }
      pg.save(path);
    }
    return concat(superList, args.array());
  }
}

class Oscipalettifier extends Oscillelement
{
  Frame outFrame = new Frame();
  Frame inFrame = new Frame();
  Palette palette;
  float newYValue = 80;
  boolean options = false;
  int palind = activePalette;

  float[] ind = {
    0
  };


  Oscipalettifier(int x, int y)
  {
    super(x, y, 100, 80, "Palettifier");
    generateGui();
    generateNodes();
    if (activePalette < palettes.size() && activePalette >= 0) palette = palettes.get(activePalette);
    for (GuiElement element : gui)
    {
      if (!element.name.equals("Options") && !element.name.equals("close")) 
      {
        element.visible = false;
      }
    }
  }

  Oscipalettifier(String[] input)
  {
    super(input);
    sizex = 100;
    sizey = 80;
    generateGui();
    generateNodes();
    for (String arg : input)
    {
      String[] q = splitTokens(arg);
      if (q.length >= 2)
      {
        if (q[0].equals("GUI") )
        {
          if (q[1].equals("Options"))
          { 
            toggleOptions(PApplet.parseFloat(q[2]));
            if (PApplet.parseFloat(q[2]) == 0) options = false;
          }
        }
        if (q[0].equals("Palettefile"))
        {
          String paletteName = q[1];
          if (q.length > 2)
          {
            for (int i = 2; i < q.length; i++)
            {
              paletteName = paletteName + " " + q[i];
            }
          }

          File selection = sequenceCreator.osc.openedLocation;
          String blah = selection.getPath();
          String[] fixedPath = splitTokens(blah, ".");
          String path = "";
          if (fixedPath.length > 1)
          {
            for (int i = 0; i < fixedPath.length-1; i++)
            {
              path = path + fixedPath[i];
            }
          } else path = fixedPath[0];

          path = path + paletteName;
          PImage img;
          try {
            img = loadImage(path);
          }
          catch(Exception e)
          {
            status.add("Error when trying to load in palette");
            return;
          }

          palette = new Palette("ReadedPalette");

          for ( int i = 0; i < min (img.width, 256); i++)
          {
            palette.addColour(img.get(i, 0));
          }
        }
      }
    }

    if (palette == null && activePalette < palettes.size() && activePalette >= 0) palette = palettes.get(activePalette);

    if (!options)
    {
      for (GuiElement element : gui)
      {
        if (!element.name.equals("Options") && !element.name.equals("close")) 
        {
          element.visible = false;
        }
      }
    }
  }

  public void update()
  {
    super.update();
    reachSize(sizex, newYValue);
    int l = inFrame.points.size();   
    ind = mapArray(l, ind, 0);
    outFrame = new Frame(inFrame.clone());
    outFrame.palette = true;

    for (int i = 0; i < l; i++)
    {
      ind[i] = outFrame.points.get(i).getBestFittingPaletteColourIndex(palette);
      outFrame.points.get(i).paletteIndex = (int) ind[i];
    }

    //outFrame.palettePaint(palette);
  }

  public void display(boolean hide)
  {
    super.display(hide);
    if (hide) return;

    if (options)
    {
      int i = 0;
      for (PaletteColour colour : palette.colours)
      {
        noStroke();

        colour.displayColour((int) x+10+5*(i%16), (int) y+110+5*PApplet.parseInt(i/16), 5);
        i++;
      }
      fill(0);
      textAlign(LEFT);
      textFont(f10);
      text(palette.name, x+10, y+127+5*(palette.colours.size()/16));
    }
  }

  public void generateGui()
  {
    gui.add(new GuiDropdown(5, 50, 90, 20, "Options", true));
    gui.add(new GuiButton(5, 80, 40, 20, "<<"));
    gui.add(new GuiButton(55, 80, 40, 20, ">>"));
    gui.add(new GuiClose(sizex-15, 0));
  }

  public void generateNodes()
  {
    //RelX, RelY, name, type (0 = frame, 1 = float[], 2 = float)
    nodes.add(new OutNode(sizex-10, 25, "Output", 0));
    nodes.add(new InNode(10, 25, "Input", 0));
    nodes.add(new OutNode(sizex-10, 45, "Index", 1));
  }

  public void nodeInput(String nodeName, Frame input)
  {
    if (nodeName.equals("Input")) 
    {
      if (input != null) inFrame = new Frame(input.clone());
    }
  }

  public void resetNode(Node node)
  {

    if (node.name.equals("Index"))
    {
      ind = new float[0];
    }
  }

  public Frame getFrameValue(String outName)
  {
    if (outName.equals("Output")) return outFrame;
    return null;
  }

  public float[] getFloatArrayValue(String name)
  {
    if (name.equals("Index")) return ind;
    return null;
  }

  public void guiActionDetected()
  {
    for (GuiElement element : gui)
    {
      if (element.active) 
      {
        if (element.name.equals("close"))
        { 
          element.active = false;
          closeElement();
        }
        if (element.name.equals("Options"))
        {
          element.active  = false;
          toggleOptions(element.getValue());
          element.setValue(1-element.getValue());
        }
        if (element.name.equals("<<"))
        {
          element.active  = false;
          palind--;
          if (palind < 0) palind = palettes.size()-1;
          palette = palettes.get(palind);
          newYValue = 135 + 5*(palette.colours.size()/16);
        }
        if (element.name.equals(">>"))
        {
          element.active  = false;
          palind++;
          if (palind >= palettes.size() ) palind = 0;
          palette = palettes.get(palind);
          newYValue = 135 + 5*(palette.colours.size()/16);
        }
      }
    }
  }

  public void toggleOptions(float displayThem)
  {
    if (displayThem == 1)
    {
      for (GuiElement element : gui)
      {
        if (!element.name.equals("Options") && !element.name.equals("close")) 
        {
          element.visible = true;
        }
      }
      newYValue = 135 + 5*((int) palette.colours.size()/16);
      options = true;
    } else
    {
      for (GuiElement element : gui)
      {
        if (!element.name.equals("Options") && !element.name.equals("close")) 
        {
          element.visible = false;
        }
      }
      newYValue = 80;
      options = false;
    }
  }

  public String[] getElementAsString()
  {
    String[] superList = super.getElementAsString();
    StringList args = new StringList();
    if (palette != null)
    {
      File selection = sequenceCreator.osc.openedLocation;
      String blah = selection.getPath();
      String[] fixedPath = splitTokens(blah, ".");
      String path = "";
      if (fixedPath.length > 1)
      {
        for (int i = 0; i < fixedPath.length-1; i++)
        {
          path = path + fixedPath[i];
        }
      } else path = fixedPath[0];
      path = path + palette.name;

      args.append("Palettefile " + palette.name);

      PImage pg = createImage(palette.colours.size(), 1, RGB);
      for (int i = 0; i < palette.colours.size (); i++)
      {
        pg.pixels[i] = palette.colours.get(i).getColour();
      }
      pg.save(path);
    }
    return concat(superList, args.array());
  }
}

class Oscimerger extends Oscillelement
{
  boolean sendX, sendY, sendZ, sendR, sendG, sendB, sendBl, sendPalInd, sendNr;
  float newYValue = 80;
  Frame firstFrame = new Frame();
  ArrayList<Frame> secondFrames = new ArrayList<Frame>();
  Frame mergedFrame = new Frame();
  int numberOfInputs;
  float[] mergOptions = new float[10];
  boolean extended = false;


  Oscimerger(int x, int y)
  {
    super(x, y, 120, 80, "Merge");

    generateGui();
    generateNodes();
  }

  Oscimerger(String[] input)
  {
    super(input);
    sizex = 120;
    sizey = 80;
    generateGui();
    generateNodes();
    for (String arg : input)
    {
      String[] q = splitTokens(arg);
      if (q.length >= 2)
      {
        if (q[0].equals("NumberOfInputs") )
        {
          numberOfInputs = PApplet.parseInt(q[1]);

          for (int i = 1; i <= numberOfInputs; i++)
          {
            nodes.add(new InNode(10, 45+(i)*20, "Frame " + (i +2), 0));

            for (GuiElement element : gui)
            {
              if (!element.name.equals("close")) element.y += 20;
            }
            newYValue+=20;
          }
        }
        if (q[0].equals("GUI") )
        {
          if (q[1].equals("Options"))
          { 
            toggleOptions(PApplet.parseFloat(q[2]));
          }
          if (q[1].equals("close"))
          {
          }
          if (!q[1].equals("Options") && !q[1].equals("close") && !q[1].equals("Add") && !q[1].equals("None"))
          { 
            String elName = q[1];

            for (GuiElement el : gui)
            {
              if (el.name.equals(elName))
              {
                el.active = true;
                el.setValue(1-PApplet.parseInt(q[2]));
                guiActionDetected();
              }
            }
          }
        }
      }
    }
  }

  public void generateGui()
  {
    gui.add(new GuiDropdown(5, 55, 110, 20, "Options", true));
    gui.add(new GuiButton(5, 75, 110, 20, "Add node"));
    gui.add(new GuiToggle(5, 160, 15, 15, "X"));
    gui.add(new GuiToggle(23, 160, 15, 15, "Y"));
    gui.add(new GuiToggle(41, 160, 15, 15, "Z"));
    gui.add(new GuiToggle(60, 160, 15, 15, "R"));
    gui.add(new GuiToggle(78, 160, 15, 15, "G"));
    gui.add(new GuiToggle(96, 160, 15, 15, "B"));
    gui.add(new GuiToggle(5, 180, 50, 15, "Number"));
    gui.add(new GuiToggle(60, 180, 50, 15, "Blanking"));
    gui.add(new GuiToggle(5, 200, 50, 15, "Palette"));
    gui.add(new GuiButton(60, 200, 50, 15, "None"));
    gui.add(new GuiClose(sizex-15, 0));

    for (GuiElement element : gui)
    {
      if (!element.name.equals("Options") && !element.name.equals("close")) element.visible = false;
    }
  }

  public void update()
  {
    super.update();
    reachSize(sizex, newYValue);
    mergedFrame.points.clear();
    boolean mergMode = false;
    for (int i = 0; i < mergOptions.length; i++)
    {
      if (mergOptions[i] == 1) mergMode = true;
    }
    //println(mergMode + " " + secondFrames.isEmpty());

    if (firstFrame != null && !mergMode) 
    {
      mergedFrame.points.addAll(firstFrame.points);
    }
    if (!secondFrames.isEmpty()) 
    {
      for (Frame frame : secondFrames)
      {
        if (!frame.points.isEmpty()) 
        {
          if (mergMode)
          {
            frame.merge(firstFrame, mergOptions);
          } else
          {
            Point firstPoint = frame.points.get(0);
            mergedFrame.points.add(new Point(firstPoint.position, (firstPoint.colour >> 16) & 0xFF, (firstPoint.colour >> 8) & 0xFF, firstPoint.colour & 0xFF, true));
          }
        }
        mergedFrame.points.addAll(frame.points);
      }
    }
    firstFrame.points.clear();
    secondFrames = new ArrayList<Frame>(numberOfInputs+1);
    for (int i = 0; i <= numberOfInputs; i++)
    {
      secondFrames.add(new Frame());
    }
  }

  public void display(boolean hide)
  {
    if (hide) return;
    super.display(hide);
    if (extended)
    {
      fill(0);
      textFont(f10);
      textAlign(LEFT);
      text("Write these properties of Frame 1 to the other frames:", x+ 5, y+100+20*numberOfInputs, 110, 60);
    }
  }

  public void generateNodes()
  {
    //RelX, RelY, name, type (0 = frame, 1 = float[], 2 = float)
    nodes.add(new InNode(10, 25, "Frame 1", 0));
    nodes.add(new InNode(10, 45, "Frame 2", 0));
    nodes.add(new OutNode(sizex-10, 25, "Output", 0));
  }

  public void nodeInput(String nodeName, Frame inputFrame)
  {

    if (nodeName.equals("Frame 1"))
    {
      if (inputFrame != null)
      {
        firstFrame = new Frame(inputFrame.clone());
      }
    }

    for (int i = 0; i <= numberOfInputs; i++)
    {
      if (nodeName.equals("Frame " + (i+2)))
      {
        if (inputFrame != null)
        {
          //println("i " + i + "frame " + (i+2) + "nrinputs " + numberOfInputs);
          secondFrames.set(i, new Frame(inputFrame.clone()));
        }
      }
    }
  }

  public Frame getFrameValue(String outName)
  {
    if (outName.equals("Output"))
    {
      return mergedFrame;
    }
    return null;
  }

  public void guiActionDetected()
  {
    for (GuiElement element : gui)
    {
      if (element.active) 
      {
        if (element.name.equals("Options"))
        { 
          element.active = false;

          toggleOptions(element.getValue());
          element.setValue(1-element.getValue());
        }

        if (element.name.equals("Add node"))
        { 
          element.active = false;

          addInputNode();
        }

        if (element.name.equals("X"))
        { 
          element.active = false;
          element.toggle();
          actX(element.getValue());
        }

        if (element.name.equals("Y"))
        { 
          element.active = false;
          element.toggle();
          actY(element.getValue());
        }

        if (element.name.equals("Z"))
        { 
          element.active = false;
          element.toggle();
          actZ(element.getValue());
        }

        if (element.name.equals("R"))
        { 
          element.active = false;
          element.toggle();
          actR(element.getValue());
        }

        if (element.name.equals("G"))
        { 
          element.active = false;
          element.toggle();
          actG(element.getValue());
        }

        if (element.name.equals("B"))
        { 
          element.active = false;
          element.toggle();
          actB(element.getValue());
        }

        if (element.name.equals("Number"))
        { 
          element.active = false;
          element.toggle();
          actNumber(element.getValue());
        }

        if (element.name.equals("Blanking"))
        { 
          element.active = false;
          element.toggle();
          actBlanking(element.getValue());
        }

        if (element.name.equals("Palette"))
        { 
          element.active = false;
          element.toggle();
          actPalette(element.getValue());
        }

        if (element.name.equals("None"))
        { 
          element.active = false;
          actNone();
        }



        if (element.name.equals("close"))
        { 
          element.active = false;
          closeElement();
        }
      }
    }
  }

  public void addInputNode()
  {
    nodes.add(new InNode(10, 45+(++numberOfInputs)*20, "Frame " + (numberOfInputs +2), 0));
    for (GuiElement element : gui)
    {
      if (!element.name.equals("close")) element.y += 20;
    }
    newYValue += 20;
  }

  public void toggleOptions(float displayThem)
  {
    if (displayThem == 1)
    {
      for (GuiElement element : gui)
      {
        if (!element.name.equals("Options") && !element.name.equals("close")) 
        {
          element.visible = true;
        }
      }
      newYValue = 220 + 20*numberOfInputs;
      extended = true;
    } else
    {
      for (GuiElement element : gui)
      {
        if (!element.name.equals("Options") && !element.name.equals("close")) 
        {
          element.visible = false;
        }
      }
      newYValue = 80 + 20*numberOfInputs;
      extended = false;
    }
  }

  public void actX(float input)
  {
    mergOptions[2] = input;
  }

  public void actY(float input)
  {
    mergOptions[4] = input;
  }

  public void actZ(float input)
  {
    mergOptions[6] = input;
  }

  public void actR(float input)
  {
    mergOptions[3] = input;
  }

  public void actG(float input)
  {
    mergOptions[5] = input;
  }

  public void actB(float input)
  {
    mergOptions[7] = input;
  }

  public void actNumber(float input)
  {
    mergOptions[1] = input;
  }

  public void actBlanking(float input)
  {
    mergOptions[8] = input;
  }

  public void actPalette(float input)
  {
    mergOptions[9] = input;
  }

  public void actNone()
  {
    for (int i = 0; i < mergOptions.length; i++)
    {
      mergOptions[i] = 0;
    }
    for (GuiElement element : gui)
    {
      if (!element.name.equals("Options") && !element.name.equals("close") && !element.name.equals("Add node") && !element.name.equals("None")) 
      {
        element.setValue(1);
        element.active = true;
      }
    }
    guiActionDetected();
  }

  public String[] getElementAsString()
  {
    String[] superList = super.getElementAsString();
    StringList args = new StringList();
    args.append("NumberOfInputs " + numberOfInputs);

    return concat(superList, args.array());
  }
}

class Oscilloutput extends Oscillelement
{

  int displaySize = 90;
  int activeFrame = 0;
  int lastTime = 0;
  int maxFrames = 1;
  ArrayList<Frame> outputFrames = new ArrayList<Frame>(maxFrames);
  boolean record = false;
  int playbackSpeed = 30;

  Oscilloutput(int x, int y)
  {
    super(x, y, 200, 100, "Output");
    generateNodes();
    generateGui();
  }

  Oscilloutput(String[] input)
  {
    super(input);
    sizex = 200;
    sizey = 100;
    generateNodes();
    generateGui();
  }

  public void generateNodes()
  {
    //RelX, RelY, name, type (0 = frame, 1 = float[], 2 = float)
    nodes.add(new InNode(10, 25, "Input", 0));
    nodes.add(new InNode(10, 45, "Sync", 1));
  }

  public void display(boolean hide)
  {
    if (hide) return;

    super.display(hide);

    fill(0);
    noStroke();
    if (!hide)rect(x+sizex-displaySize-5, y+5, displaySize, displaySize);

    if (activeFrame>= 0 && activeFrame < outputFrames.size()  && !hide)
    {
      outputFrames.get(activeFrame).drawFrame(x+sizex-displaySize-5, y+5, 0, displaySize, displaySize, 0, false, true);
    }

    if (record && frameCount%90<45)
    {
      fill(255, 0, 0);
      noStroke();
      ellipse(x+sizex-displaySize+5, y+15, 5, 5);
    }
  }

  public void update()
  {
    super.update();
    if (millis() - lastTime > 1000/playbackSpeed)
    {
      activeFrame++;
      if ((activeFrame >= outputFrames.size() || activeFrame > maxFrames) && !record ) activeFrame = 0;
      lastTime = millis();
    }
    sequenceCreator.osc.outFrames = outputFrames;
  }

  public void nodeInput(String nodeName, Frame inputFrame)
  {
    if (nodeName.equals("Input"))
    {
      if (inputFrame != null)
      {
        Frame stupidcrapJava = new Frame(inputFrame.clone());
        /*
        for (Point point : stupidcrapJava.points)
         {
         inputFrame.points.add(new Point(point.clone(point)));
         }
         */

        if (stupidcrapJava.frameName == null) stupidcrapJava.frameName = "Oscillabstract";
        if (stupidcrapJava.companyName == null) stupidcrapJava.companyName = "IldaViewer";
        stupidcrapJava.pointCount = stupidcrapJava.points.size();
        stupidcrapJava.frameNumber = activeFrame;
        stupidcrapJava.totalFrames = maxFrames;
        stupidcrapJava.scannerHead = 123;
        if (activeFrame >= outputFrames.size()-1)outputFrames.add(stupidcrapJava);
        else outputFrames.set(activeFrame, stupidcrapJava);
      }
    }
  }

  public void nodeInput(String nodeName, float[] in)
  {
    if (nodeName.equals("Sync"))
    {
      int input = activeFrame;
      if (in.length > 0) input = (int) in[0];
      activeFrame = (int) input;
      if (input > maxFrames) maxFrames = (int) input;
    }
  }

  public void generateGui()
  {
    gui.add( new GuiToggle(sizex-displaySize-70, sizey-25, 55, 20, "Record"));
  }

  public void guiActionDetected()
  {
    for (GuiElement element : gui)
    {
      if (element.active) 
      {
        if (element.name.equals("Record"))
        { 
          element.active = false;
          if (element.getValue() == 0) 
          {
            record = true;
            outputFrames.clear();
            activeFrame = 0;
          } else 
          {
            record = false;
          }
          element.setValue(1-element.getValue());
        }
      }
    }
  }
}



class Oscisource extends Oscillelement
{
  ArrayList<Frame> sources = new ArrayList<Frame>();

  int activeFrame = 0;
  int playbackSpeed = 20;
  int lastTime = 0;
  int displaySize = 90;
  float newYValue = sizey;
  boolean resizing = false;
  int xoffset = 0;
  int frameSize = 100;
  int visibleFrames = PApplet.parseInt(width/frameSize);
  int firstFrame = -1;
  int lastFrame = -1;
  boolean scrolling = false;
  int prevX = 0;
  boolean startscrolling = true;
  int xoffset2 = 0;
  int preprogFrame = -1;
  boolean scrolling2 = false;
  boolean autoplay = false;

  ArrayList<Frame> preprogframes = new ArrayList<Frame>();

  boolean selectTheFrames = false;

  Oscisource(float x, float y)
  {
    super(x, y, 100, 225, "Source");
    generateGui();
    generatePreProgFrames(200);
    generateNodes();
  }

  Oscisource(float x, float y, Frame sourceFrame)
  {
    super(x, y, 100, 225, "Source");
    sources.add(sourceFrame);
    generateGui();
    generatePreProgFrames(200);
  }

  Oscisource(float x, float y, ArrayList<Frame> sources)
  {
    super(x, y, 100, 225, "Source");
    this.sources = sources;
    generateGui();
    generatePreProgFrames(200);
  }

  Oscisource(String[] input)
  {
    super(input);
    if (sizex == 0) sizex = 100;
    if (sizey == 0) sizey = 225;
    generateGui();
    generateNodes();
    generatePreProgFrames(200);
    for (String arg : input)
    {
      String[] q = splitTokens(arg);
      if (q.length >= 2)
      {

        if (q[0].equals("Beginframe")) firstFrame = PApplet.parseInt(q[1]);
        if (q[0].equals("Endframe")) lastFrame = PApplet.parseInt(q[1]);
        if (q[0].equals("Programmedframe")) preprogFrame = PApplet.parseInt(q[1]);
        if (q[0].equals("Framefile"))
        {
          String frameName = q[1];
          if (q.length > 2)
          {
            for (int i = 2; i < q.length; i++)
            {
              frameName = frameName + " " + q[i];
            }
          }

          char[] test = new char[4];  //Test if it already has the extension .ild:
          for (int i = 0; i < 4; i++)
          {
            if (frameName.length() > 3)test[i] = frameName.charAt(i+frameName.length()-4);
          }
          String testing = new String(test);
          if ( !testing.equals(".ild") )
          {
            frameName += ".ild";
          }

          File selection = sequenceCreator.osc.openedLocation;
          String blah = selection.getPath();
          String[] fixedPath = splitTokens(blah, ".");
          String path = "";
          if (fixedPath.length > 1)
          {
            for (int i = 0; i < fixedPath.length-1; i++)
            {
              path = path + fixedPath[i];
            }
          } else path = fixedPath[0];

          path = path + frameName;
          FileWrapper file = new FileWrapper(path, true);  //Create a new FileWrapper, this constructor automatically reads the file, second argument doesn't matter just to distinguish it from the other one
          ArrayList<Frame> frames = file.getFramesFromBytes();
          if (firstFrame != -1 && lastFrame != -1)
          {
            for (int i = 0; i <= lastFrame-firstFrame; i++)
            {
              sources.add(frames.get(i));
            }
            firstFrame = 0;
            lastFrame = lastFrame - firstFrame;
          }
        }

        if (q[0].equals("GUI") )
        {
          if (q[1].equals("Select frames"))
          {
          }
          if (q[1].equals("Options"))
          { 
            toggleOptions(1-PApplet.parseFloat(q[2]));
          }
          if (q[1].equals("close"))
          {
          }
          if (q[1].equals("Autoplay"))
          { 
            toggleAutoplay(PApplet.parseFloat(q[2]));
          }
        }
      }
    }
    if (preprogFrame >= 0 && preprogFrame < preprogframes.size())
    {
      sources.add(preprogframes.get(preprogFrame));
    }
  } 

  public void display(boolean hide)
  {
    super.display(sequenceCreator.osc.hideElements);
    fill(0);
    noStroke();
    if (!hide)rect(x+5, y+15, displaySize, displaySize);
    if (activeFrame>= 0 && activeFrame < sources.size() &&!selectTheFrames && !hide)
    {
      sources.get(activeFrame).drawFrame(x+5, y+15, 0, displaySize, displaySize, 0, false, true);
    }


    if (selectTheFrames)
    {
      if (mousePressed) sequenceCreator.osc.addNewElement = false;
      sequenceCreator.osc.hideElements = true;
      checkMouseOver = false;
      textAlign(LEFT);
      fill(50);
      noStroke();
      rect(0, 150, width, height-300);
      if (!frames.isEmpty())
      {

        for (int i = max ( (int) -xoffset/frameSize, 0); i < min(frames.size(), (int) -xoffset/frameSize+visibleFrames+1); i++)
        {
          fill(0);
          noStroke();
          if (i == firstFrame)
          {
            fill(255, 50);
            textFont(f16);
            text("First", xoffset + frameSize*i+45, 220);
            fill(0);
            strokeWeight(3);
            stroke(255, 255, 0);
          }


          if (i == lastFrame)
          {
            fill(255, 50);
            textFont(f16);
            text("Last", xoffset + frameSize*i+45, 220);
            fill(0);
            strokeWeight(3);
            stroke(0, 255, 255);
          }

          if ( i< lastFrame && i > firstFrame)
          {
            strokeWeight(2); 
            stroke(lerp(0, 255, 1-((float)i-(float)firstFrame)/(lastFrame)), 255, lerp(0, 255, ((float)i-(float)firstFrame)/(lastFrame)));
          }

          fill(0);
          rect(xoffset+frameSize*i, 160, 90, 90);
          frames.get(i).drawFrame((float)xoffset+frameSize*i, 160.0f, 0.0f, 90.0f, 90.0f, 0.0f, false, true);
          if (i == firstFrame)
          {
            fill(255, 50);
            textFont(f16);
            text("First", xoffset + frameSize*i+45, 220);
          }
          if (i == lastFrame)
          {
            fill(255, 50);
            textFont(f16);
            text("Last", xoffset + frameSize*i+45, 220);
          }
        }
      } else
      {
        textFont(f16);
        fill(255, 50);
        text("No frames", 50, 190);
      }

      if (mousePressed && mouseY > 150 && mouseY < 250)
      {
        int pickedFrame = (int) (mouseX-xoffset)/frameSize;
        if (mouseButton == LEFT) firstFrame = pickedFrame;
        if (mouseButton == RIGHT) lastFrame = pickedFrame;
        if (mouseButton == CENTER && !scrolling) 
        {
          scrolling = true;
          prevX = -xoffset + mouseX;
          cursor(MOVE);
        }
        preprogFrame = -1;
      }

      if (!mousePressed && scrolling)
      {
        scrolling = false;
        cursor(ARROW);
      }

      if (scrolling)
      {
        xoffset = mouseX - prevX;
      }

      noStroke();
      textAlign(CENTER);

      fill(127);  
      rect(10, 260, 35, 25);
      fill(0);
      textFont(f20);
      text("<<", 25, 278);
      if (mousePressed && mouseX > 10 && mouseX < 45 && mouseY > 260 && mouseY <285) xoffset = 5;

      fill(127);  
      rect(50, 260, 35, 25);
      fill(0);
      textFont(f20);
      text("<", 65, 278);
      if (mousePressed && mouseX > 50 && mouseX < 85 && mouseY > 260 && mouseY <285) xoffset += 5;

      fill(127);  
      rect(width-85, 260, 35, 25);
      fill(0);
      textFont(f20);
      text(">", width-67, 278);
      if (mousePressed && mouseX > width-85 && mouseX < width-50 && mouseY > 260 && mouseY <285) xoffset -= 5;

      fill(127);  
      rect(width-45, 260, 35, 25);
      fill(0);
      textFont(f20);
      text(">>", width-27, 278);
      if (mousePressed && mouseX > width-45 && mouseX < width-10 && mouseY > 260 && mouseY <285) xoffset = -frames.size() * frameSize + frameSize * visibleFrames;

      fill(127);
      float scrollX = map(xoffset, 0, -frames.size()*frameSize, 100, width-100);
      rect(scrollX, 260, 10, 25);      
      if (mousePressed && mouseX > scrollX && mouseX < scrollX+10 && mouseY > 260 && mouseY <285) startscrolling = true;
      if (startscrolling)
      {
        xoffset = (int) map(mouseX, 100, width-100, 0, (float)-frames.size()*frameSize);
        if (xoffset > 5) xoffset = 5;
        if (xoffset < -frames.size()*frameSize+ frameSize * visibleFrames) xoffset = -frames.size()*frameSize+ frameSize * visibleFrames;
      }

      if (startscrolling && !mousePressed) startscrolling = false;

      if (!preprogframes.isEmpty())
      {
        for (int i = 0; i < preprogframes.size (); i++)
        {
          fill(0);
          noStroke();
          if (i == preprogFrame)
          {

            fill(0);
            strokeWeight(3);
            stroke(255, 255, 0);
          }

          fill(0);
          rect(xoffset2+frameSize*i, 300, 90, 90);
          preprogframes.get(i).drawFrame((float)xoffset2+frameSize*i, 300, 0.0f, 90.0f, 90.0f, 0.0f, false, true);
        }
      }

      if (mousePressed && mouseY > 300 && mouseY < 400)
      {
        int pickedFrame = (int) (mouseX-xoffset2)/frameSize;
        if (mouseButton == CENTER)
        {
          scrolling2 = true;
          prevX = -xoffset2 + mouseX;
        } else
        {
          preprogFrame = pickedFrame;
          firstFrame = -1;
          lastFrame = -1;
        }
      }

      if (!mousePressed && scrolling2)
      {
        scrolling2 = false;
      }

      if (scrolling2)
      {
        xoffset2 = mouseX - prevX;
      }

      fill(127);
      noStroke();
      rect(width*0.5f- 55, height-180, 45, 20);
      rect(width*0.5f- 5, height-180, 45, 20);

      fill(0);
      textFont(f12);
      text("Accept", width*0.5f-35, height-167);
      text("Cancel", width*0.5f+15, height-167);

      //Accept
      if (mousePressed && mouseX > width*0.5f-55 && mouseX < width*0.5f-10 && mouseY > height-180 && mouseY < height-160)
      {
        selectTheFrames = false;
        checkMouseOver = true;
        sequenceCreator.osc.hideElements = false;
        sources.clear();
        if (firstFrame != -1 && lastFrame != -1)
        {
          for (int i = firstFrame; i <= lastFrame; i++)
          {
            sources.add(frames.get(i));
          }
        } else
        {
          if (preprogFrame != -1) sources.add(preprogframes.get(preprogFrame));
        }
      }
      //Cancel
      if (mousePressed && mouseX > width*0.5f-5 && mouseX < width*0.5f+40 && mouseY > height-180 && mouseY < height-160)
      {
        selectTheFrames = false;
        checkMouseOver = true;
        sequenceCreator.osc.hideElements = false;
      }
    }
  }


  public void update()
  {       
    super.update(); 

    if (autoplay)
    {
      if (millis() - lastTime > 1000/playbackSpeed)
      {
        activeFrame++;
        if (activeFrame >= sources.size() || activeFrame < 0 ) activeFrame = 0;
        lastTime = millis();
      }
    } 
    if (resizing)
    {
      reachSize(sizex, newYValue);
      if (sizey == newYValue) resizing = false;
    }
  }

  public Frame getFrameValue(String outName)
  {
    if (outName.equals("Output"))
    {
      if (activeFrame >= 0 && activeFrame < sources.size())
      {
        return sources.get(activeFrame);
      }
    }
    return null;
  }

  public float[] getFloatArrayValue(String outName)
  {
    if (outName.equals("Sync")) 
    {
      float[] out = {
        activeFrame
      };
      return out;
    }
    float[] out = {
      0
    };
    return out;
  }

  public void guiActionDetected()
  {
    for (GuiElement element : gui)
    {
      if (element.active) 
      {
        if (element.name.equals("Select frames"))
        { 
          element.active = false;
          selectFrames();
        }
        if (element.name.equals("Options"))
        { 
          element.active = false;
          toggleOptions(element.getValue());
          element.setValue(1-element.getValue());
        }
        if (element.name.equals("close"))
        { 
          element.active = false;
          closeElement();
        }
        if (element.name.equals("Autoplay"))
        { 
          element.active = false;
          element.setValue(1-element.getValue());
          toggleAutoplay(element.getValue());
        }
      }
    }
  }

  public void generateGui()
  {
    gui.add(new GuiDropdown(5, 145, 90, 20, "Options", false));
    gui.add(new GuiButton(5, 170, 90, 20, "Select frames"));
    gui.add(new GuiToggle(5, 195, 90, 20, "Autoplay"));
    gui.add(new GuiClose(sizex-15, 0));
  }

  public void selectFrames()
  {
    mousePressed = false;
    selectTheFrames = true;
    sequenceCreator.osc.addNewElement = false;
    status.clear();
    status.add("Left click to select the first frame, right click to select the last frame.");
  }

  public void toggleOptions(float displayThem)
  {

    if (displayThem == 1)
    {
      for (GuiElement element : gui)
      {
        if (element.name.equals("Select frames")) element.visible = true;
        if (element.name.equals("Autoplay")) element.visible = true;
      }
      newYValue = 225;
    } else
    {
      for (GuiElement element : gui)
      {
        if (element.name.equals("Select frames")) element.visible = false;
        if (element.name.equals("Autoplay")) element.visible = false;
      }
      newYValue = 170;
    }
    resizing = true;
  }

  public void toggleAutoplay(float shouldIt)
  {
    if (shouldIt == 1) 
    {
      autoplay = true;
    } else autoplay = false;
  }

  public void resetNode(Node node)
  {
    if (node.name.equals("Sync_in"))
    {
      activeFrame = 0;
    }
  }

  public void generatePreProgFrames(int numPoints)
  {
    preprogframes = new ArrayList<Frame>();
    //Empty:
    Frame emptyFrame = new Frame();

    preprogframes.add(emptyFrame); 

    //Dot:
    Frame dotFrame = new Frame();
    ArrayList<Point> dotPoints = new ArrayList<Point>();
    for (int i = 0; i < numPoints; i++)
    {
      dotPoints.add(new Point(width*0.5f, height*0.5f, depth*0.5f, 255, 255, 255, false));
    }
    dotFrame.points = dotPoints;
    dotFrame.frameName = "dot";
    preprogframes.add(dotFrame);

    //Line:
    Frame lineFrame = new Frame();
    ArrayList<Point> linePoints = new ArrayList<Point>();
    for (int i = 0; i < numPoints; i++)
    {
      linePoints.add( new Point(PApplet.parseFloat(i)*width/numPoints, height*0.5f, depth*0.5f, 255, 255, 255, false));
    }
    lineFrame.points = linePoints;
    lineFrame.frameName = "line";
    preprogframes.add(lineFrame);

    //Circle:
    Frame circleFrame = new Frame();
    ArrayList<Point> somePoints = new ArrayList<Point>();
    for (int i = 0; i < numPoints; i++)
    {
      float x = map( sin(PApplet.parseFloat(i)*TWO_PI/numPoints), -1, 1, 0, width);
      float y = map( cos(PApplet.parseFloat(i)*TWO_PI/numPoints), -1, 1, 0, height);
      somePoints.add(new Point(x, y, depth*0.5f, 255, 255, 255, false));
    }
    circleFrame.points = somePoints;
    circleFrame.frameName = "circle";
    preprogframes.add(circleFrame);

    //Triangle:
    Frame triFrame = new Frame();
    ArrayList<Point> triPoints = new ArrayList<Point>();
    for (int i = 0; i < numPoints*0.333f; i++)
    {
      float x = map( i, 0, numPoints*0.333f, 0, width);
      float y = height;
      triPoints.add(new Point(x, y, depth*0.5f, 255, 255, 255, false));
    }
    for (int i = PApplet.parseInt (numPoints*0.333f); i < PApplet.parseInt(numPoints*0.666f); i++)
    {
      float x = map( i, numPoints*0.333f, numPoints*0.666f, width, width*0.5f);
      float y = map( i, numPoints*0.333f, numPoints*0.666f, height, 0);
      triPoints.add(new Point(x, y, depth*0.5f, 255, 255, 255, false));
    }
    for (int i = PApplet.parseInt (numPoints*0.666f); i < numPoints; i++)
    {
      float x = map( i, numPoints*0.666f, numPoints, width*0.5f, 0);
      float y = map( i, numPoints*0.666f, numPoints, 0, height);
      triPoints.add(new Point(x, y, depth*0.5f, 255, 255, 255, false));
    }
    triFrame.points = triPoints;
    triFrame.frameName = "triangle";
    preprogframes.add(triFrame);

    //Spiral:
    Frame spiralFrame = new Frame();
    ArrayList<Point> spiralPoints = new ArrayList<Point>();
    for (int i = 0; i < numPoints; i++)
    {
      float x = map( PApplet.parseFloat(i)/numPoints*sin(PApplet.parseFloat(i)*2*TWO_PI/numPoints), -1, 1, 0, width);
      float y = map( PApplet.parseFloat(i)/numPoints*cos(PApplet.parseFloat(i)*2*TWO_PI/numPoints), -1, 1, 0, height);
      spiralPoints.add(new Point(x, y, i*depth/numPoints, 255, 255, 255, false));
    }
    spiralFrame.points = spiralPoints;
    spiralFrame.frameName = "spiral";
    preprogframes.add(spiralFrame);
  }

  public void generateNodes()
  {
    nodes.add(new InNode(10, displaySize+45, "Sync_in", 1));
    nodes.add(new OutNode(sizex-10, displaySize+25, "Output", 0));
    nodes.add(new OutNode(sizex-10, displaySize+45, "Sync", 1));
  }

  public void nodeInput(String nodeName, float[] input)
  {
    if (nodeName.equals("Sync_in"))
    {
      if (input.length > 0) activeFrame = (int) input[0];
    }
  }

  public String[] getElementAsString()
  {
    String[] superList = super.getElementAsString();
    StringList args = new StringList();
    args.append("Beginframe " + firstFrame);
    args.append("Endframe " + lastFrame);
    args.append("Programmedframe " + preprogFrame);
    if (!sources.isEmpty() && preprogFrame == -1) 
    {
      int count = 0;
      for (Frame frame : sources)
      {
        frame.frameName = "Oscillabstract";
        frame.companyName = "IldaViewer";
        frame.pointCount = frame.points.size();
        frame.frameNumber = count++;
        frame.totalFrames = sources.size();
        frame.scannerHead = 0;
      }
      String name = "_frames_" + index;
      args.append("Framefile " + name + ".ild");
      File selection = sequenceCreator.osc.openedLocation;
      String blah = selection.getPath();
      String[] fixedPath = splitTokens(blah, ".");
      String path = "";
      if (fixedPath.length > 1)
      {
        for (int i = 0; i < fixedPath.length-1; i++)
        {
          path = path + fixedPath[i];
        }
      } else path = fixedPath[0];
      path = path + name + ".ild";
      FileWrapper file = new FileWrapper(path, sources, 4);
    }

    return concat(superList, args.array());
  }
}

class Oscilloconstant extends Oscillelement
{
  float[] value = {
    0
  };
  boolean connected = false;
  boolean updateValue = false;
  float oldValue;

  Oscilloconstant(float x, float y)
  {
    super(x, y, 100, 70, "Constant");
    generateNodes();
    generateGui();
  }

  Oscilloconstant(String[] input)
  {
    super(input);
    sizex = 100;
    sizey = 70;
    generateNodes();
    generateGui();
    for (String arg : input)
    {
      String[] q = splitTokens(arg);
      if (q.length >= 2)
      {
        if (q[0].equals("Value")) value[0] = PApplet.parseFloat(q[1]);
        if (q[0].equals("GUI") && q.length >= 3 )
        {

          if (q[1].equals("Value"))
          { 
            for (GuiElement el : gui)
            {
              if (el.name.equals("Value")) el.setValue(PApplet.parseFloat(q[2]));
            }
          }
        }
      }
    }
  }

  public void update()
  {
    super.update();
    //getNode("Output").setColour((int) min(255, max(0, value[0]))*255);
    for (GuiElement el : gui)
    {
      if (el.name.equals("Value")) value[0] = el.getValue();
    }

    getNode("Output").setColour(color((int) min(255, max(0, value[0]*255))));
  }

  public void display(boolean hide)
  {
    super.display(hide);
  }

  public void generateGui()
  {
    gui.add(new GuiClose(sizex-15, 0));
    gui.add(new GuiNumberBox(5, 45, 90, 20, "Value"));
  }

  public void guiActionDetected()
  {
    for (GuiElement element : gui)
    {
      if (element.active) 
      {

        if (element.name.equals("Value"))
        { 
          element.active = true;
          /*
          if (!mousePressed) element.active = false;
           changeValue(element.getValue());
           updateValue = true;
           oldValue = value[0];
           */
        }
        if (element.name.equals("close"))
        { 
          element.active = false;
          closeElement();
        }
      }
    }
  }

  public void generateNodes()
  {
    nodes.add(new OutNode(sizex-10, 25, "Output", 1));
  }

  public void changeValue(float nr)
  {
    value[0] = nr;
    for (GuiElement el : gui)
    {
      if (el.name.equals("Value")) el.setValue(nr);
    }
  }

  public float[] getFloatArrayValue(String outName)
  {
    if (outName.equals("Output")) return value;
    return null;
  }

  public String[] getElementAsString()
  {
    String[] superList = super.getElementAsString();
    StringList args = new StringList();
    args.append("Value " + value[0]);


    return concat(superList, args.array());
  }
}

class Oscilladder extends Oscillelement
{
  ArrayList<float[]> values = new ArrayList<float[]>(2);
  boolean subtract = false;
  float[] output = {
    0
  };
  int numberOfInputs = 2;

  Oscilladder(float x, float y)
  {
    super(x, y, 100, 100, "Adder");
    generateNodes();
    generateGui();
    values.add(new float[0]);
    values.add(new float[0]);
  }

  Oscilladder(String[] input)
  {
    super(input);
    sizex = 100;
    sizey = 100;
    for (String arg : input)
    {
      String[] q = splitTokens(arg);
      if (q.length >= 2)
      {
        if (q[0].equals("Subtract")) subtract = PApplet.parseBoolean(q[1]);
        if (q[0].equals("Inputs")) numberOfInputs = PApplet.parseInt(q[1]);
      }
    }
    generateNodes();
    generateGui();
    values.add(new float[0]);
    values.add(new float[0]);
    for (int i = 2; i < numberOfInputs; i++)
    {
      values.add(new float[0]);
      nodes.add(new InNode(10, 5+20*i, "Value " + (i+1), 1));
      for (GuiElement el : gui)
      {
        if (!el.name.equals("close")) el.y += 20;
      }
      sizey += 20;
    }
  }

  public void update()
  {
    super.update();
    int l = 1;

    if (!values.isEmpty()) 
    {
      l = values.get(0).length;

      output = new float[l];
      if (subtract)
      {
        arrayCopy(values.get(0), output);
        if (values.size() > 1)
        {
          for (int i = 1; i < values.size (); i++)
          {
            float[] temp = mapArray(l, values.get(i), 0);
            for (int j = 0; j < temp.length; j++)
            {
              output[j] -= temp[j];
            }
          }
        }
      } else
      {
        for (int j = 0; j < values.size (); j++)
        {
          float[] input = mapArray(l, values.get(j), 0);
          if (input.length > 0)
          {
            for (int i = 0; i < l; i++)
            {
              output[i] += input[i];
            }
          }
        }
      }
    }
    for (int i = 0; i < values.size (); i++)
    {
      float[] v = values.get(i);
      if (v.length > 0) getNode("Value " + (i+1)).setColour(color((int) min(255, max(0, v[0]*255))));
    }
    if (output.length > 0) getNode("Output").setColour(color((int) min(255, max(0, output[0]*255))));
  }

  public void generateGui()
  {
    gui.add(new GuiClose(sizex-15, 0));
    gui.add(new GuiButton(sizex-50, 65, 45, 20, "Add"));
    gui.add(new GuiButton(5, 5+3*20, 20, 20, "+"));
  }

  public void generateNodes()
  {
    nodes.add(new InNode(10, 25, "Value 1", 1));
    nodes.add(new InNode(10, 45, "Value 2", 1));
    nodes.add(new OutNode(sizex-10, 25, "Output", 1));
  }

  public void nodeInput(String nodeName, float[] input)
  {
    for (int i = 0; i < numberOfInputs; i++)
    {
      if (nodeName.equals("Value " + (i+1)))
      {
        float[] val = new float[input.length];
        arrayCopy(input, val);
        if (i < values.size())values.set(i, val);
      }
    }
  }

  public void resetNode(Node node)
  {
    for (int i = 0; i < numberOfInputs; i++)
    {
      if (node.name.equals("Value " + (i+1)))
      {
        float[] val = new float[0];
        if (i < values.size())values.set(i, val);
      }
    }
  }

  public float[] getFloatArrayValue(String outName)
  {
    if (outName.equals("Output")) return output;
    return null;
  }

  public void guiActionDetected()
  {
    for (GuiElement element : gui)
    {
      if (element.active) 
      {

        if (element.name.equals("+"))
        {
          element.active = false;
          numberOfInputs++;
          nodes.add(new InNode(10, 5+20*numberOfInputs, "Value " + numberOfInputs, 1));
          for (GuiElement el : gui)
          {
            if (!el.name.equals("close")) el.y += 20;
          }
          sizey += 20;
          values.add(new float[0]);
        }
        if (element.name.equals("Add"))
        {
          if (subtract) 
          {
            element.text = "Add";
            subtract = false;
          } else 
          {
            element.text = "Subtract";
            subtract = true;
          }
          element.toggle();
        }

        if (element.name.equals("close"))
        { 
          element.active = false;
          closeElement();
        }
      }
    }
  }

  public String[] getElementAsString()
  {
    String[] superList = super.getElementAsString();
    StringList args = new StringList();
    args.append("Inputs " + numberOfInputs);
    args.append("Subtract " + subtract);

    return concat(superList, args.array());
  }
}

class Osciplier extends Oscillelement
{
  ArrayList<float[]> values = new ArrayList<float[]>(2);
  boolean divide = false;
  float[] output = {
    0
  };
  int numberOfInputs = 2;
  boolean error = false;

  Osciplier(float x, float y)
  {
    super(x, y, 100, 100, "Multiplier");
    generateNodes();
    generateGui();
    values.add(new float[0]);
    values.add(new float[0]);
  }

  Osciplier(String[] input)
  {
    super(input);
    sizex = 100;
    sizey = 100;
    for (String arg : input)
    {
      String[] q = splitTokens(arg);
      if (q.length >= 2)
      {
        if (q[0].equals("Divide")) divide = PApplet.parseBoolean(q[1]);
        if (q[0].equals("Inputs")) numberOfInputs = PApplet.parseInt(q[1]);
      }
    }
    generateNodes();
    generateGui();
    values.add(new float[0]);
    values.add(new float[0]);
    for (int i = 2; i < numberOfInputs; i++)
    {
      nodes.add(new InNode(10, 5+20*(i+1), "Value " + (i+1), 1));
      for (GuiElement el : gui)
      {
        if (!el.name.equals("close")) el.y += 20;
      }
      sizey += 20;
      values.add(new float[0]);
    }
  }

  public void update()
  {
    super.update();
    int l = 1;
    error = false;

    if (!values.isEmpty()) 
    {
      l = values.get(0).length;

      output = new float[l];
      if (divide)
      {
        if (values.size() > 0) arrayCopy(values.get(0), output);
        if (values.size() > 1)
        {
          for (int i = 1; i < values.size (); i++)
          {
            if (values.get(i).length == 0) error = true;
            float[] temp = mapArray(l, values.get(i), 1);
            for (int j = 0; j < temp.length; j++)
            {
              if (temp[j] != 0) output[j] /= temp[j];
              else output[j] = 1e32f;
            }
          }
        }
      } else
      {
        if (values.size() > 0) arrayCopy(values.get(0), output);
        for (int j = 0; j < values.size (); j++)
        {
          float[] input = mapArray(l, values.get(j), 1);
          if (input.length > 0)
          {
            for (int i = 0; i < l; i++)
            {
              output[i] *= input[i];
            }
          }
        }
      }
    }
    for (int i = 0; i < values.size (); i++)
    {
      float[] v = values.get(i);
      if (v.length > 0) getNode("Value " + (i+1)).setColour(color((int) min(255, max(0, v[0]*255))));
    }
    if (error) getNode("Output").setColour(color(255, 50, 10));
    if (output.length > 0) getNode("Output").setColour(color((int) min(255, max(0, output[0]*255))));
  }

  public void generateGui()
  {
    gui.add(new GuiClose(sizex-15, 0));
    gui.add(new GuiButton(sizex-50, 65, 45, 20, "Multiply"));
    gui.add(new GuiButton(5, 5+(2+1)*20, 20, 20, "+"));
  }

  public void generateNodes()
  {
    nodes.add(new InNode(10, 25, "Value 1", 1));
    nodes.add(new InNode(10, 45, "Value 2", 1));
    nodes.add(new OutNode(sizex-10, 25, "Output", 1));
  }

  public void nodeInput(String nodeName, float[] input)
  {
    for (int i = 0; i < numberOfInputs; i++)
    {
      if (nodeName.equals("Value " + (i+1)))
      {
        float[] val = new float[input.length];
        arrayCopy(input, val);
        if (i < values.size())values.set(i, val);
      }
    }
  }

  public void resetNode(Node node)
  {
    for (int i = 0; i < numberOfInputs; i++)
    {
      if (node.name.equals("Value " + (i+1)))
      {
        float[] val = new float[0];
        if (i < values.size())values.set(i, val);
      }
    }
  }

  public float[] getFloatArrayValue(String outName)
  {
    if (outName.equals("Output")) return output;
    return null;
  }

  public void guiActionDetected()
  {
    for (GuiElement element : gui)
    {
      if (element.active) 
      {

        if (element.name.equals("+"))
        {
          element.active = false;
          numberOfInputs++;
          nodes.add(new InNode(10, 5+20*numberOfInputs, "Value " + numberOfInputs, 1));
          for (GuiElement el : gui)
          {
            if (!el.name.equals("close")) el.y += 20;
          }
          sizey += 20;
          values.add(new float[0]);
        }
        if (element.name.equals("Multiply"))
        {
          if (divide) 
          {
            element.text = "Multiply";
            divide = false;
          } else 
          {
            element.text = "Divide";
            divide = true;
          }
          element.toggle();
        }

        if (element.name.equals("close"))
        { 
          element.active = false;
          closeElement();
        }
      }
    }
  }

  public String[] getElementAsString()
  {
    String[] superList = super.getElementAsString();
    StringList args = new StringList();
    args.append("Inputs " + numberOfInputs);
    args.append("Divide " + divide);

    return concat(superList, args.array());
  }
}

class Oscilloclock extends Oscillelement
{
  float[] value = {
    0
  };
  boolean connected = false;
  float count = 0;
  float[] output = new float[1];
  float frequency = 1;
  float lastTime = 0;
  float sync = 0;
  float prevsync = 0;

  Oscilloclock(float x, float y)
  {
    super(x, y, 100, 90, "Clock");
    generateNodes();
    generateGui();
  }

  Oscilloclock(String[] input)
  {
    super(input);
    sizex = 100;
    sizey = 90;
    generateNodes();
    generateGui();
    for (String arg : input)
    {
      String[] q = splitTokens(arg);
      if (q.length >= 2)
      {
        if (q[0].equals("Count")) count = PApplet.parseFloat(q[1]);
        if (q[0].equals("Frequency")) frequency = PApplet.parseFloat(q[1]);
      }
    }
  }

  public void update()
  {
    super.update();
    if (frameRate != 0) count += max(-frameRate, min(frequency/frameRate, frameRate));
    if (count >= 1 || count <= -1) count  = 0;
    if (sync != prevsync && sync >= 1)
    {
      count = 0;
      prevsync = sync;
    }
    if (!connected || value.length == 0)
    {
      output[0] = count;
    } else
    {
      if (value.length == 1) output[0] = value[0];
      int i = (int) (abs(count) * value.length);
      if (count > 0) 
      {
        output[0] = map((count*value.length)%1, 0, 1, value[i], value[min(value.length-1, i+1)]);
        //output[0] = map(count%1, 0, 1, value[], value[(int) min(count * value.length+1, value.length-1)]);
      } else output[0] = map((count*value.length)%1, -1, 0, value[i], value[min(value.length-1, i+1)]);
    }

    getNode("Output").setColour(color((int) min(255, max(0, output[0]*255))));
  }

  public void display(boolean hide)
  {
    super.display(hide);
  }

  public void generateGui()
  {
    gui.add(new GuiClose(sizex-15, 0));
  }
  public void guiActionDetected()
  {
    for (GuiElement element : gui)
    {
      if (element.active) 
      {
        if (element.name.equals("close"))
        { 
          element.active = false;
          closeElement();
        }
      }
    }
  }

  public void generateNodes()
  {
    nodes.add(new InNode(10, 45, "Frequency", 1));
    nodes.add(new InNode(10, 25, "Reset", 1));
    nodes.add(new InNode(10, 65, "Shape", 1));
    nodes.add(new OutNode(sizex-10, 25, "Output", 1));
  }

  public void nodeInput(String nodeName, float[] input)
  {
    if (nodeName.equals("Frequency"))
    {
      if (input.length > 0) frequency = input[0];
    }
    if (nodeName.equals("Reset"))
    {
      if (input.length > 0) 
      {
        sync = input[0];
      }
    }
    if (nodeName.equals("Shape"))
    {
      value = input;
      connected = true;
    }
  }

  public float[] getFloatArrayValue(String outName)
  {
    if (outName.equals("Output")) return output;
    return null;
  }

  public String[] getElementAsString()
  {
    String[] superList = super.getElementAsString();
    StringList args = new StringList();
    args.append("Count " + count);
    args.append("Frequency " + frequency);

    return concat(superList, args.array());
  }
}

class Oscillator extends Oscillelement
{

  float waveform = 0;

  float[] frequency = {
    1
  };
  float[] phase = {
    0
  };
  float[] amplitude = {
    0.5f
  };
  float[] offset = {
    0
  };
  float[] random = {
    0
  };
  float[] prevrandom = {
    0
  };
  int prevTime = 0;
  float samples = 200;

  float[] invalues;
  boolean inputDisconnected;

  float[] outvalues;


  Oscillator(float x, float y)
  {
    super(x, y, 100, 220, "Oscillator");

    generateNodes();
    generateGui();
  }

  Oscillator(String[] input)
  {
    super(input);
    sizex = 100;
    sizey = 220;
    generateNodes();
    generateGui();
    for (String arg : input)
    {
      String[] q = splitTokens(arg);
      if (q.length >= 2)
      {
        if (q[0].equals("Waveform")) waveform = PApplet.parseFloat(q[1]);
        if (q[0].equals("Frequency")) 
        {
          frequency = new float[1];
          frequency[0] = PApplet.parseFloat(q[1]);
        }
        if (q[0].equals("Amplitude")) 
        {
          amplitude =  new float[1];
          amplitude[0] =   PApplet.parseFloat(q[1]);
        }
        if (q[0].equals("Phase")) 
        {
          phase =  new float[1];
          phase[0] =   PApplet.parseFloat(q[1]);
        }
        if (q[0].equals("Offset")) 
        {
          offset =  new float[1];
          offset[0] =   PApplet.parseFloat(q[1]);
        }
        if (q[0].equals("Samples")) samples = PApplet.parseFloat(q[1]);

        if (q[0].equals("GUI") )
        {
        }
      }
    }
  }


  public void update()
  {
    super.update();
    outvalues = oscillate(invalues);
    if (outvalues.length > 0) getNode("Output").setColour(color((int) min(255, max(0, outvalues[0]*255))));
    inputDisconnected = true;
  }

  public void display(boolean hide)
  {
    super.display(hide);
    if (hide) return;
    fill(0);
    noStroke();
    rect(x+5, y+15, sizex-10, 40);
    if (outvalues.length > 0)
    {
      float prev = outvalues[0];
      if (laserboyMode) stroke(color(PApplet.parseInt((sin(PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin(PI/2+PApplet.parseFloat(frameCount)/10)*0.5f+0.5f)*255), PApplet.parseInt((sin(3*PI/2+PApplet.parseFloat(frameCount)/20)*0.5f+0.5f)*255))); 
      else stroke(10, 127, 50);
      strokeWeight(1);
      for (int i = 1; i < outvalues.length; i++)
      {
        line(x+5+(i-1)*(sizex-10)/(outvalues.length-1), 20*max(-1, min(1, prev))+y+35, x+5+(i)*(sizex-10)/(outvalues.length-1), y+35+20*max(-1, min(1, outvalues[i])));
        prev = outvalues[i];
      }
    }
    if (mousePressed && mouseX > x+5 && mouseX < x+sizex-5 && mouseY > y+15 && mouseY < y+55) 
    {
      if (mouseButton == LEFT) waveform++;
      else waveform--;
      if (waveform > 7) waveform = 0;
      if (waveform < 0) waveform = 7;

      mousePressed = false;
    }
  }

  public float[] oscillate(float[] input)
  {
    if (samples == 0) samples = 1;
    int l  = (int) samples;
    if (l < 1) l = 1;

    if (inputDisconnected || input == null || input.length == 0)
    {
      input = new float[l];
      for (int i = 0; i < l; i++)
      {
        input[i] = PApplet.parseFloat(i)/l;
      }
    }

    float[] output = mapArray(l, input, 1);

    frequency = mapArray(l, frequency, 1);
    phase = mapArray(l, phase, 0);
    amplitude = mapArray(l, amplitude, 1);
    offset = mapArray(l, offset, 0);

    switch((int) waveform)
    {
    case 0:    //Sine
      for (int i = 0; i < l; i++)
      {
        output[i] = sin((output[i]*frequency[i]+phase[i])*TWO_PI)*amplitude[i]+offset[i];
      }
      break;
    case 1:     //Cosine
      for (int i = 0; i < l; i++)
      {
        output[i] = cos((output[i]*frequency[i]+phase[i])*TWO_PI)*amplitude[i]+offset[i];
      }
      break;
    case 2:    //Linear
      for (int i = 0; i < l; i++)
      {
        output[i] = (ramp((output[i]*frequency[i]+phase[i])))*amplitude[i]+offset[i];
      }
      break;
    case 3:    //Triangle
      for (int i = 0; i < l; i++)
      {
        output[i] = tri((output[i]*frequency[i]+phase[i]))*amplitude[i]+offset[i];
      }
      break;
    case 4:    //Linear reversed
      for (int i = 0; i < l; i++)
      {
        output[i] = (-ramp((output[i]*frequency[i]+phase[i])))*amplitude[i]+offset[i];
      }
      break;
    case 5:    //Square
      for (int i = 0; i < l; i++)
      {
        output[i] = square((output[i]*frequency[i]+phase[i]))*amplitude[i]+offset[i];
      }
      break;
    case 6:    //Random
      try
      {

        float time = 0;
        if (frequency.length > 0 && frequency[0] != 0)
        {

          if (millis() - lastTime > 1000/frequency[0])
          {
            prevrandom = random;
            random = new float[l];

            for (int i = 0; i < l; i++)
            {
              random[i] = random(-1, 1);
            }
            lastTime = millis();
          }
          time = map(millis(), lastTime, lastTime + 1000/frequency[0], 0, 1);
        }
        if (prevrandom.length != l) prevrandom = mapArray(l, prevrandom, 0);

        for (int i = 0; i < l; i++)
        {
          output[i] = amplitude[i]*map(time, 0, 1, prevrandom[i], random[i])+offset[i];
        }
      }
      catch(Exception e)  //???
      {
        println("Random generator exception. Output size: " + output.length + ", previous size: " + prevrandom.length);
        println(e);
      }
      break;
    case 7:    //Noise

      random = mapArray(l, random, 0);
      prevrandom = mapArray(l, prevrandom, 0);

      for (int i = 0; i < l; i++)
      {
        prevrandom[i] += phase[i];
        random[i] = noise(l*0.03f*i+prevrandom[i]*0.5f);//, random[i]*l*0.01);
      }

      for (int i = 0; i < l; i++)
      {
        output[i] = amplitude[i]*(random[i]-0.5f)*2+offset[i];
      }
      break;
    default:
      break;
    }

    return output;
  }



  public void generateGui()
  {
    gui.add(new GuiClose(sizex-15, 0));
  }

  public void guiActionDetected()
  {
    for (GuiElement element : gui)
    {
      if (element.active) 
      {

        if (element.name.equals("Options"))
        { 
          /*
          element.active = false;
           toggleOptions(element.getValue());
           element.setValue(1-element.getValue());
           */
        }
        if (element.name.equals("close"))
        { 
          element.active = false;
          closeElement();
        }
      }
    }
  }

  public void generateNodes()
  {
    //RelX, RelY, name, type (0 = frame, 1 = float[], 2 = float) except I only use float[] and not float
    nodes.add(new InNode(10, 75, "Input", 1));
    nodes.add(new InNode(10, 95, "Waveform", 1));
    nodes.add(new InNode(10, 115, "Frequency", 1));
    nodes.add(new InNode(10, 135, "Phase", 1));
    nodes.add(new InNode(10, 155, "Amplitude", 1));
    nodes.add(new InNode(10, 175, "Offset", 1));
    nodes.add(new InNode(10, 195, "Samples", 1));
    nodes.add(new OutNode(sizex-10, 75, "Output", 1));
  }

  public void nodeInput(String nodeName, float[] input)
  {
    if (nodeName.equals("Input"))
    {
      invalues = input;
      inputDisconnected = false;
    }
    if (input.length>0)
    {
      if (nodeName.equals("Waveform"))waveform = input[0];
      if (nodeName.equals("Samples"))samples = input[0];
    }
    if (nodeName.equals("Frequency"))frequency = input;
    if (nodeName.equals("Phase"))phase = input;
    if (nodeName.equals("Amplitude"))amplitude = input;
    if (nodeName.equals("Offset"))offset = input;
  }

  public float[] getFloatArrayValue(String outName)
  {
    if (outName.equals("Output")) return outvalues;
    return null;
  }

  public String[] getElementAsString()
  {
    String[] superList = super.getElementAsString();
    StringList args = new StringList();
    args.append("Waveform " + waveform);
    args.append("Frequency " + frequency[0]);
    args.append("Phase " + phase[0]);
    args.append("Amplitude " + amplitude[0]);
    args.append("Offset " + offset[0]);
    args.append("Samples " + samples);

    return concat(superList, args.array());
  }
}

public float tri(float in)
{
  in = in%1;
  if (in>=0.5f ) return 2*ramp(in)-1;
  if (in >= 0&& in < 0.5f) return -2*ramp(in)-1;
  if (in < 0 && in > -0.5f) return 2*ramp(in)-1;
  else return -2*ramp(in)-1;
}

public float ramp(float in)
{
  if (in>=0) return 2*(in%1)-1;
  else
  {
    return 1-2*(abs(in)%1);
  }
}

public float square(float in)
{
  if (in>=0)
  {
    if ((in%1)<0.5f) return -1;
    else return 1;
  } else
  {
    if (abs(in%1)<0.5f) return 1;
    else return -1;
  }
}

public float[] mapArray(int newLength, float[] input, float defaultValue)
{
  if (newLength < 0) return null;
  if (input == null || input.length == 0)
  {
    input = new float[newLength];
    for (int i = 0; i < newLength; i++)
    {
      input[i] = defaultValue;
    }
  }

  float[] output = new float[newLength];
  if (input.length == newLength) arrayCopy(input, output);

  for (int i = 0; i < newLength; i++)
  {
    float pos = map(i, 0, newLength, 0, input.length-1);
    int index = floor(pos);
    float magic = pos - index;

    output[i] = map(magic, 0, 1, input[index], input[min(index+1, input.length-1)]);
  }

  return output;
}

public float roundToHalfInt(float input)
{
  float decimalPart = input%1;
  float integerPart = input - decimalPart;

  //Positive values:
  if (decimalPart < 0.25f && decimalPart >= 0) return integerPart;
  if (decimalPart >= 0.25f && decimalPart < 0.75f) return integerPart + 0.5f;
  if (decimalPart >= 0.75f && decimalPart < 1) return integerPart +1;

  //Negative values:
  if (decimalPart > -0.25f && decimalPart <= 0) return integerPart;
  if (decimalPart <= -0.25f && decimalPart > -0.75f) return integerPart - 0.5f;
  if (decimalPart <= -0.75f && decimalPart > -1) return integerPart -1;

  return integerPart;
}


class GuiElement
{
  float x;
  float y;
  float sizex;
  float sizey;
  String name;
  String text;
  boolean active = false;
  boolean visible = true;
  boolean updateValue = false;
  int alpha = 255;

  GuiElement()
  {
  }

  GuiElement(float x, float y, float sizex, float sizey, String name)
  {
    this.x = x;
    this.y = y;
    this.sizex = sizex;
    this.sizey = sizey;
    this.name = name;
  }

  public void display(float elx, float ely)
  {
  }

  public void update(float elx, float ely)
  {
  }

  public boolean activateElement(float elx, float ely)
  {
    if (mouseX > x + elx && mouseX < x + elx + sizex && mouseY > y + ely && mouseY < y + ely + sizey)
    {
      active = true;
      return true;
    }
    return false;
  }

  public void toggle()
  {
  }

  public float getValue()
  {
    return 0;
  }

  public void setValue(float input)
  {
  }

  public void activate(boolean activate)
  {
    updateValue = activate;
  }
}

class GuiNumberBox extends GuiElement
{
  float value = 0;
  float oldValue = 0;

  GuiNumberBox(float x, float y, float sizex, float sizey, String name)
  {
    super(x, y, sizex, sizey, name);
    value = 0;
  }

  public void display(float elx, float ely)
  {
    fill(50, alpha);
    if (active)
    {
      if (laserboyMode) fill(color(PApplet.parseInt((sin((ely)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((y)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((elx+ely)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255)), alpha); 
      else fill(127, alpha);
      stroke(0);
      strokeWeight(1);
    } else
    {
      if (laserboyMode) fill(color(PApplet.parseInt((sin((elx)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), 255-PApplet.parseInt((sin((y)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((x+y)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255)), alpha); 
      else fill(50, alpha);
      noStroke();
    }
    rect(x+elx, y+ely, sizex, sizey);
    if (laserboyMode) fill(color(255-PApplet.parseInt((sin((x)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt(255-(sin((y)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), 255-PApplet.parseInt((sin((elx+ely)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255)), alpha); 
    else fill(255, alpha);
    noStroke();
    textAlign(LEFT);
    textFont(f10);
    text(value, x+elx + sizex*0.5f-textWidth(str(value))*0.5f, y+ely + sizey*0.5f+3);
    if (sizex != 0) triangle(x+elx+2, y+ely+2, x+elx+2, y+ely+sizey-2, x+elx+sqrt(2)*(sizex/sizey), y+ely+0.5f*sizey);
  }

  public void update(float elx, float ely)
  {
    super.update(elx, ely);
    if (!mousePressed) active = false;
    if (mousePressed && activateElement(elx, ely) && !updateValue)
    {

      updateValue = true;
      oldValue = value;
    }
    if (active) 
    {
      value = (0.00001f*pow(-mouseY+y+ely+sizey*0.5f, 3)+(oldValue));
      if (keyPressed && keyCode == CONTROL) 
      {
        value = (roundToHalfInt(value));
        updateValue = false;
        oldValue = value;
        active = false;
      }
    }
    if (updateValue && !mousePressed) 
    {
      updateValue = false;
      active = false;
    }
  }

  public void setValue(float input)
  {
    value = input;
  }

  public float getValue()
  {
    return value;
  }
}

class GuiScroller extends GuiElement
{
  float position; //[0..1]
  float scrollerSize = 5;
  boolean scrolling = false;
  float oldValue = 0;

  GuiScroller(float x, float y, float sizex, float sizey, String name)
  {
    super(x, y, sizex, sizey, name);
  }

  public void update(float elx, float ely)
  {
    if (active && !scrolling)
    {
      scrolling = true;
      oldValue = position;
    }

    if (scrolling && !mousePressed)
    {
      scrolling = false;
      active = false;
    }

    if (scrolling)
    {
      if (sizey != 0) position = (mouseY - y - ely)/sizey;
      if (position < 0) position = 0;
      if (position > 1) position = 1;

      if (mouseX > x+elx + sizex) mouseX = (int) (x + elx + sizex);
      if (mouseX < x + elx) mouseX = (int) (x + elx);
      if (mouseY > y + ely + sizey) mouseY = (int) (y + ely + sizey);
      if (mouseY < y + ely) mouseY = (int) (y + ely);
    }
  }

  public void display(float elx, float ely)
  {
    if (laserboyMode) fill(color(PApplet.parseInt((sin((elx)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((ely)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((x+y)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255)), alpha); 
    else fill(200, alpha);
    noStroke();
    rect(x+elx, y+ely, sizex, sizey);
    if (laserboyMode) fill(color(255-PApplet.parseInt((sin((x)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((y)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((elx+ely)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255)), alpha); 
    else fill(50, alpha);
    rect(x+elx, y+ely+map(position, 0, 1, 0, sizey-scrollerSize), sizex, scrollerSize);
  }

  public float getValue()
  {
    return position;
  }

  public void setValue(float input)
  {
    position = map(input, 0, sizey-scrollerSize, 0, 1);
  }
}

class GuiButton extends GuiElement
{


  GuiButton(float x, float y, float sizex, float sizey, String name)
  {
    super(x, y, sizex, sizey, name);
    text = name;
  }


  public void display(float elx, float ely)
  {
    if (!visible) return;
    if (laserboyMode) fill(color(PApplet.parseInt((sin((y)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((x)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((elx+ely)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255)), alpha); 
    else fill(50, alpha);
    noStroke();
    rect(x + elx, y + ely, sizex, sizey);
    if (laserboyMode) fill(color(PApplet.parseInt((sin((x)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((y)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((elx+ely)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255)), alpha); 
    else fill(255, alpha);
    textAlign(LEFT);
    textFont(f10);
    text(text, x+elx + sizex*0.5f-textWidth(text)*0.5f, y+ely + sizey*0.5f+3);
  }
}

class GuiToggle extends GuiElement
{
  String text;
  boolean isActive = false;

  GuiToggle(float x, float y, float sizex, float sizey, String name)
  {
    super(x, y, sizex, sizey, name);
    text = name;
  }

  public void display(float elx, float ely)
  {
    if (!visible) return;
    if (isActive)
    {
      if (laserboyMode) fill(color(PApplet.parseInt((sin((x)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((y)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((elx+ely)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255)), alpha); 
      else fill(127, alpha);
      stroke(0, alpha);
      strokeWeight(1);
    } else
    {
      if (laserboyMode) fill(color(255-PApplet.parseInt((sin((x)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), 255-PApplet.parseInt((sin((y)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), 255-PApplet.parseInt((sin((elx+ely)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255)), alpha); 
      else fill(50, alpha);
      noStroke();
    }
    rect(x + elx, y + ely, sizex, sizey);

    if (isActive)
    {
      if (laserboyMode) fill(color(255-PApplet.parseInt((sin((x)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), 255- PApplet.parseInt((sin((y)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), 255-PApplet.parseInt((sin((elx+ely)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255)), alpha); 
      else fill(0, alpha);
    } else
    {
      if (laserboyMode) fill(color(PApplet.parseInt((sin((x)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((y)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((elx+ely)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255)), alpha); 
      else fill(255, alpha);
    }

    textFont(f10);
    textAlign(CENTER);
    //text(text, x+elx + sizex*0.5-textWidth(text)*0.5, y+ely + sizey*0.5+3);
    text(text, (int) x+elx + sizex*0.5f, (int) y+ely + sizey*0.5f+3);
  }

  public void toggle()
  {
    isActive = !isActive;
  }

  public float getValue()
  {
    if (isActive) return 1;
    else return 0;
  }

  public void setValue(float value)
  {
    if (value == 1) isActive = true;
    else isActive = false;
  }
}

class GuiDropdown extends GuiElement
{
  String text;
  boolean dropdown;

  GuiDropdown(float x, float y, float sizex, float sizey, String name, boolean dropdown)
  {
    this(x, y, sizex, sizey, name);
    this.dropdown = dropdown;
  }

  GuiDropdown(float x, float y, float sizex, float sizey, String name)
  {
    super(x, y, sizex, sizey, name);
    text = name;
  }

  public void toggle()
  {
    dropdown = !dropdown;
  }

  public void display(float elx, float ely)
  {
    if (!visible) return;
    if (laserboyMode) fill(color(PApplet.parseInt((sin((x)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((y)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((elx+ely)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255)), alpha); 
    else fill(0, alpha);
    noStroke();
    if (dropdown) triangle(x+elx+sizex-11, y+ely+10, x+elx+sizex-5, y+ely+10, x+elx+sizex-8, y+ely+5);
    else triangle(x+elx+sizex-11, y+ely+10, x+elx+sizex-5, y+ely+10, x+elx+sizex-8, y+ely+15);
    textFont(f10);
    textAlign(LEFT);
    text(text, x+elx+sizex-textWidth(text)-15, y+ely+15);
  }

  public float getValue()
  {
    if (dropdown) return 1;
    else return 0;
  }

  public void setValue(float input)
  {
    if (input == 1) dropdown = true;
    else dropdown = false;
  }
}

class GuiClose extends GuiElement
{
  GuiClose(float x, float y)
  {
    super(x, y, 10, 10, "close");
  }

  public void display(float elx, float ely)
  {
    textFont(f10);
    if (laserboyMode) fill(color(PApplet.parseInt((sin((x)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((y)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((elx+ely)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255)), alpha); 
    else fill(0, alpha);
    text("X", x+elx, y+ely+10);
  }
}

/*
* Here's how we'll do it:
 * Each Oscillelement has a few nodes (in and out)
 * Each node has a continuously updating value (float, Frame etc)
 * They also have a number referring to a Connection
 * When updated, they look for their Connection and give/retrieve the value
 * 
 */

/*
 * Change of plan
 * When an OutNode has a Connection, it writes its value to an external global array specific for his value
 * (there will be an array for each object/primitive type)
 * The Connection keeps track of the position in the array then tells the InNode to read it
 *
 */

/*
 * Funny how neither got implemented.
 * A Connection keeps track of which elements and nodes it's connected to.
 * Then it calls the getFloatArrayValue or getFrameValue according to its type from the out element node 
 * and passes the result on to the input of the other element.
 * The result is not stored somewhere in between.
 *
 */

class Node
{
  float x, y;
  String name;
  boolean visible = true;
  boolean active = false;
  int colour = color(0);
  int type; //0 = Frame, 1 = float[], 2 = float

  Node(float x, float y, String name, int type)
  {
    this.x = x;
    this.y = y;
    this.name = name;
    this.type = type;
  }

  public void update()
  {
  }

  public void connect(int index)
  {
  }

  public void setColour(int colour)
  {
    this.colour = colour;
  }

  public void display(float elx, float ely)
  {
    if (laserboyMode) fill(color(PApplet.parseInt((sin((x)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((y)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((elx+ely)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255))); 
    else fill(colour);
    quad(x+elx-5, y+ely, x+elx, y+ely+5, x+elx+5, y+ely, x+elx, y+ely-5);
    textFont(f10);
  }

  public boolean checkMouse(float elx, float ely)
  {
    if (mouseX > x + elx -5 && mouseX < x + elx + 5 && mouseY > y + ely -5 && mouseY < y + ely + 5)
    {
      active = true;
      return true;
    }
    return false;
  }
}

class InNode extends Node
{
  InNode(float x, float y, String name, int type)
  {
    super(x, y, name, type);
  }

  public void display(float elx, float ely)
  {
    if (type == 0)
    {
      stroke(20, 100, 255);
      strokeWeight(1);
    } else noStroke();
    if (laserboyMode) fill(color(PApplet.parseInt((sin((x)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((y)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((elx+ely)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255))); 
    else fill(0);
    textAlign(LEFT);
    text(split(name, '_')[0], x+elx+8, y+ely+3);
    fill(colour);
    super.display(elx, ely);
  }
}

class OutNode extends Node
{
  OutNode(float x, float y, String name, int type)
  {
    super(x, y, name, type);
  }

  public void display(float elx, float ely)
  {
    if (type == 0)
    {
      stroke(20, 100, 255);
      strokeWeight(1);
    } else noStroke();
    if (laserboyMode) fill(color(PApplet.parseInt((sin((x)/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((y)+PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin((elx+ely)/2+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255))); 
    else fill(0);
    textAlign(RIGHT);
    text(split(name, '_')[0], x+elx-8, y+ely+3);
    fill(colour);
    super.display(elx, ely);
  }
}



class Connection
{
  int type;  //0 = Frame, 1 = float[], 2 = float
  //int index;
  int inIndex, outIndex;  //Index of the Oscillelement
  String inName, outName; //Name of the Node
  float x1, y1, x2, y2; //1 = out, 2 = in
  boolean active;
  boolean shouldUpdate;
  boolean dragInput = false;
  boolean dragOutput = false;
  boolean deleteConnection = false;

  Connection(int type)
  {
    this.type = type;
    active = false;
    shouldUpdate = false;
  }

  Connection(int type, int outIndex, int inIndex, String outName, String inName)
  {
    this.type = type;
    this.inIndex = inIndex;
    this.outIndex = outIndex;
    this.inName = inName;
    this.outName = outName;
    active = false;
    shouldUpdate = true;
  }

  Connection(int type, float x1, float y1, int outIndex, String outName)
  {
    this.type = type;
    this.outIndex = outIndex;
    this.outName = outName;
    this.x1 = x1;
    this.y1 = y1;
    active = false;
    shouldUpdate = false;
  }

  Connection(int type, float x2, float y2, String inName, int inIndex)
  {
    this.type = type;
    this.inIndex = inIndex;
    this.inName = inName;
    this.x2 = x2;
    this.y2 = y2;
    active = false;
    shouldUpdate = false;
  }

  Connection(String[] input)
  {
    for (String arg : input)
    {
      String[] q = splitTokens(arg);
      if (q.length >= 2)
      {
        if (q[0].equals("Type") ) type = PApplet.parseInt(q[1]);
        if (q[0].equals("InIndex") ) inIndex = PApplet.parseInt(q[1]);
        if (q[0].equals("OutIndex") ) outIndex = PApplet.parseInt(q[1]);
        if (q[0].equals("NodeInName") )
        {
          inName = q[1];
          for (int i = 2; i < q.length; i++)
          {
            inName = inName + " " + q[i];
          }
        }
        if (q[0].equals("NodeOutName") )
        {
          outName = q[1];
          for (int i = 2; i < q.length; i++)
          {
            outName = outName + " " +q[i];
          }
        }
      }
    }
    shouldUpdate = true;
  }

  public void update()
  {
    if (shouldUpdate)
    {
      if (outName == null || inName == null) return;
      if (sequenceCreator.osc == null) return;
      Oscillelement outElement = sequenceCreator.osc.searchElement(outIndex);
      Oscillelement inElement = sequenceCreator.osc.searchElement(inIndex);
      if (outElement != null && inElement != null)
      {
        try
        {
          if (outElement.getNode(outName) == null || inElement.getNode(inName) == null) deleteConnection = true;
          x1 = outElement.getNode(outName).x + outElement.x;
          y1 = outElement.getNode(outName).y + outElement.y;
          x2 = inElement.getNode(inName).x + inElement.x;
          y2 = inElement.getNode(inName).y + inElement.y;

          switch(type)
          {
          case 0: 
            inElement.nodeInput(inName, outElement.getFrameValue(outName));
            break;
          case 1:
            inElement.nodeInput(inName, outElement.getFloatArrayValue(outName));
            break;
            /*
          case 2:
             inElement.nodeInput(inName, outElement.getFloatArrayValue(outName));
             
             break;
             */
          default:
            break;
          }
        }
        catch(Exception e)
        {
          println("Error when updating connection from element " + outIndex + " and node " + outName + " to element " + inIndex + " and node " + inName);
          println(e);
          deleteConnection = true;
        }
      } else deleteConnection = true;
    }

    if (dragInput && mousePressed)
    {
      dragInput(mouseX, mouseY);
    }

    if (dragInput && !mousePressed)
    {
      dragInput = false;
      active = false;
      Oscillelement inputElement = sequenceCreator.osc.searchElement(mouseX, mouseY);
      if (inputElement != null)
      {
        Node inputNode = inputElement.searchNode(mouseX, mouseY);
        boolean alreadyConnected = false;
        if (inputNode != null)
        {
          for (Connection connection : sequenceCreator.osc.connections)
          {

            if ( connection.connectedToInput(inputElement.index, inputNode)) alreadyConnected = true;
          }
          if (alreadyConnected)
          {
            deleteConnection = true;
            return;
          }
          if (inputNode.type == type && inputNode instanceof InNode)
          {
            inName = inputNode.name;
            inIndex = inputElement.index;
            shouldUpdate = true;
          } else deleteConnection = true;
        } else deleteConnection = true;
      } else deleteConnection = true;
    }

    if (dragOutput && mousePressed)
    {
      dragOutput(mouseX, mouseY);
    }

    if (dragOutput && !mousePressed)
    {
      dragOutput = false;
      active = false;
      Oscillelement outputElement = sequenceCreator.osc.searchElement(mouseX, mouseY);
      if (outputElement != null)
      {
        Node outputNode = outputElement.searchNode(mouseX, mouseY);

        if (outputNode != null && outputNode.type == type && outputNode instanceof OutNode)
        {
          outName = outputNode.name;
          outIndex = outputElement.index;
          shouldUpdate = true;
        } else deleteConnection = true;
      } else deleteConnection = true;
    }
  }



  public void display()
  {
    if (sequenceCreator.osc.hideElements) return;
    noFill();
    if (active)
    {
      stroke(255, 127, 0);
      strokeWeight(2);
    } else
    {
      strokeWeight(1);
      if (type == 0)
      {
        stroke(20, 100, 255);
      } else stroke(255);
    }
    bezier(x1, y1, x1+0.5f*abs(x2-x1), y1, x2-0.5f*abs(x2-x1), y2, x2, y2);
  }

  public void dragInput(float x, float y)
  {
    active = true;
    x2 = x;
    y2 = y;
  }

  public void connectInput(int inIndex, Node node)
  { 
    this.inIndex = inIndex;
    x2 = node.x;
    y2 = node.y;
    type = node.type;
    inName = node.name;
  }



  public void dragOutput(float x, float y)
  {
    active = true;
    x1 = x;
    y1 = y;
  }

  public void connectOutput(int outIndex, Node node)
  {
    this.inIndex = outIndex;
    x1 = node.x;
    y1 = node.y;
    type = node.type;
    outName = node.name;
  }


  public void setCoordinates(float elx, float ely, Node node)  //Node = Output
  {
    if (node == null) return;
    x1 = elx + node.x;
    y1 = ely + node.y;
  }

  public void setCoordinates( Node node, float elx, float ely)  //Node = Input
  {
    if (node == null) return;
    x2 = elx + node.x;
    y2 = ely + node.y;
  }

  public void startDraggingInput()
  {
    shouldUpdate = false;
    dragInput = true;
  }

  public void startDraggingOutput()
  {
    shouldUpdate = false;
    dragOutput = true;
  }

  public boolean connectedToInput(int index, Node node)
  {
    if (inName == null) return false;
    try
    {
      if (inIndex == index && inName.equals(node.name) && node instanceof InNode)
      {
        return true;
      }
    }
    catch(Exception e)
    {
      println("Error happened lolz");
      println(e);
    }
    return false;
  }

  public boolean connectedToOutput(int index, Node node)
  {
    if (outIndex == index && outName.equals(node.name) && node instanceof OutNode)
    {
      return true;
    } else return false;
  }

  public String[] getConnectionAsString()
  {
    StringList output = new StringList();
    output.append("Type " + type);
    output.append("InIndex " + inIndex);
    output.append("OutIndex " + outIndex);
    output.append("NodeInName " + inName);
    output.append("NodeOutName " + outName);

    return output.array();
  }
}

/*      WARNING
 * 
 * Warning: this class has a very high level of spaghettification!
 * Better skip to others for a better example.
 *
 */
 
 // Fields for Sequence Editor tab:

boolean sequenceditor = false;//Sequence editor mode
SequenceEditor seqeditor;     
String nrOfInsertedFrames = "1";//Amount of frames to add
RadioButton copyBehaviour;     //What should happen when frames are dropped in the lists?
CheckBox copiedElements;      //What data should be copied?
SeqeditorDropListener sedl;
MainDropListener mdl;
BufferDropListener bdl;

//      === SEQUENCE EDITOR TAB METHODS AND CP5 CALLBACKS ===

public void beginSeqEditor()
{
  sequenceditor = true;
  if (seqeditor == null) seqeditor = new SequenceEditor();
  else seqeditor.init();

  status.clear();
  status.add("Drag frames around. Hold ctrl to copy, right mouse button to multiselect.");
}

public void exitSeqEditor()
{
  frames.clear();
  for (FrameDraggable frame : seqeditor.theFrames)
  {
    frames.add(frame.frame);
  }
  sequenceditor = false;
} 

public void editorShowBlanking(boolean theValue)
{
  showBlanking = theValue;
}

public void insertFrame()
{
  seqeditor.addFrame();
  status.clear();
  status.add("Empty frames created.");
  status.add("Drag the frames to the Main frame list or the Buffer and drop them.");
}

public void deleteFrame()
{
  seqeditor.deleteFrame();
  status.clear();
  status.add("Deleted a frame.");
}

public void editorLoadIldaFile()
{
  //loading = true;    //It's possible frame displaying is in a separate thread, and you can't load and display at the same time
  thread("addIldaFile");
}

public void addIldaFile()
{
  selectInput("Load an Ilda file", "addFile");
}



//Gets called when an ilda file is selected in the previous method
public void addFile(File selection) {

  //Check if file is valid
  if (selection == null) {
    status.clear();
    status.add("Window was closed or the user hit cancel.");
    return;
  } else {
    //Check if file exists
    if (!selection.exists())
    {
      status.clear();
      status.add("Error when trying to read file " + selection.getAbsolutePath());
      status.add("File does not exist.");
      return;
    }
    status.clear();
    status.add("Loading file:");
    status.add(selection.getAbsolutePath());
    //File should be all good now, load it in!
    loadAnIldaFile(selection.getAbsolutePath());
  }
}

//Load in the file
public void loadAnIldaFile(String path)
{

  FileWrapper file = new FileWrapper(path, true);  //Create a new FileWrapper, this constructor automatically reads the file, second argument doesn't matter just to distinguish it from the other one
  ArrayList<Frame> newFrames = file.getFramesFromBytes();
  for (Frame frame : newFrames)
  {
    seqeditor.loadedFrames.add(new FrameDraggable(frame));
  }
  status.add("Loading completed.");
}

public void editorClearFrames()
{
  seqeditor.theFrames.clear();
  status.clear();
  status.add("All frames cleared.");
}

public void editorClearBuffer()
{
  seqeditor.bufferFrames.clear();
  status.clear();
  status.add("Buffer frames cleared.");
}

public void editorFitPalette()
{
  seqeditor.fitPalette();
  status.clear();
  status.add("Fitted RGB values with palette " + getActivePalette().name);
}

public void editorSelectFrames()
{
  seqeditor.selectFrames();
  status.clear();
  status.add("All frames selected.");
}

public void editorSelectBuffer()
{
  seqeditor.selectBuffer();
  status.clear();
  status.add("All frames in buffer selected.");
}

public void editorDeselectFrames()
{
  seqeditor.deselectFrames();
  status.clear();
  status.add("All frames deselected.");
}

public void editorDeselectBuffer()
{
  seqeditor.deselectBuffer();
  status.clear();
  status.add("All frames in buffer deselected.");
}

public void sfx()
{
  status.clear();
  status.add("This button does nothing yet. Stay tuned!");
}

class SequenceEditor
{
  float yoffset = 30;
  float offvel = 0;
  int initMouseX = 0;
  int initMouseY = 0;
  boolean dragging = false;
  boolean trigger = false;
  boolean triggerb = false;
  boolean checkdraginit = false;
  float yoffsetbuf = 30;
  float offvelbuf = 0;
  Frame displayedFrame; 
  int highlightedFrame = activeFrame;
  int highlightedFrameBuf = -1;
  boolean checkdraginitbuf = false;
  boolean checkKeyPressed = false;
  ArrayList<FrameDraggable> theFrames;
  ArrayList<FrameDraggable> draggedFrames;
  ArrayList<FrameDraggable> bufferFrames;
  ArrayList<FrameDraggable> loadedFrames;
  int frameSize = 25;
  int visibleFrames = PApplet.parseInt((height-30)/frameSize);
  int mainColour = color(127);
  int bufferColour = color(127);

  SequenceEditor()
  {

    theFrames = new ArrayList<FrameDraggable>();
    draggedFrames = new ArrayList<FrameDraggable>();
    bufferFrames = new ArrayList<FrameDraggable>();
    loadedFrames = new ArrayList<FrameDraggable>();

    for (Frame frame : frames)
    {
      theFrames.add(new FrameDraggable(frame));
    }
    if (!frames.isEmpty())
    {
      displayedFrame = frames.get(activeFrame);
      toggleHighlighted(activeFrame);
      toggleHighlightedBuf(-1);
    }
  }

  public void init()
  {
    theFrames.clear();


    for (int i = 0; i < frames.size (); i++)
    {  
      theFrames.add(new FrameDraggable(frames.get(i))) ;
    }

    if (!frames.isEmpty()) 
    {
      displayedFrame = frames.get(activeFrame);
      toggleHighlighted(activeFrame);
      toggleHighlightedBuf(-1);
    } else
    {
      displayedFrame = null;
    }
  }

  public void update()
  {
    //Dragging from browser:
    sedl.draw();
    mdl.draw();
    bdl.draw();

    //Update all frame positions:
    for (FrameDraggable frame : theFrames)
    {
      frame.updateOffset();
      frame.resetOffset();
    }

    //Update all bufferframe positions
    for (FrameDraggable frame : bufferFrames)
    {
      frame.updateOffset();
      frame.resetOffset();
    }

    //Display all frames in a list
    if (shouldDisplayMain())
    {
      displayMain();
      for (int i = max ( (int) -yoffset/frameSize, 0); i < min(theFrames.size(), (int) -yoffset/frameSize+visibleFrames+1); i++)
      {
        boolean highlighted = false;
        if (i == highlightedFrame) highlighted = true;
        if (i>=0 && i < theFrames.size()) theFrames.get(i).display(20.0f, 30+frameSize*i+yoffset, PApplet.parseInt(75*visibleFrames*sin((yoffset/frameSize+i)*PI/(visibleFrames-1))), highlighted);
      }
    }

    //Display the buffer when necessary:
    if (shouldDisplayBuffer())
    {
      displayBuffer();

      for (int i = max ( (int) -yoffsetbuf/frameSize, 0); i < min(bufferFrames.size(), (int) -yoffsetbuf/frameSize+visibleFrames+1); i++)
      {
        boolean highlighted = false;
        if (i == highlightedFrameBuf) highlighted = true;
        FrameDraggable frame = bufferFrames.get(i);
        frame.display(160, 30+frameSize*i+yoffsetbuf, PApplet.parseInt(75*visibleFrames*sin((yoffsetbuf/frameSize+i)*PI/(visibleFrames-1))), highlighted);
      }
    }

    //Display loaded ilda files:
    if (!loadedFrames.isEmpty())
    {
      fill(127);
      stroke(color(PApplet.parseInt((sin(PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*127+127), PApplet.parseInt((sin(PI+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*127+127), 127));
      strokeWeight(5);
    } else
    {
      fill(127, 50);
      stroke(127);
      strokeWeight(2);
    }
    rect(width-300, 380, 85, 40);
    if (!loadedFrames.isEmpty())
    {
      Frame frame = loadedFrames.get(0).frame;
      textAlign(CENTER);
      textFont(f10);
      if (laserboyMode) fill(color(PApplet.parseInt((sin(PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin(PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255), PApplet.parseInt((sin(+3*PI/2+PApplet.parseFloat(frameCount)/15)*0.5f+0.5f)*255))); 
      else fill(255);
      text(frame.frameName, width-260, 403);
    }

    //Clicked in main column:
    if ( mousePressed && mouseX > 20 && mouseX < 140 && !dragging)
    {

      if (!dragging)
      {
        if (!trigger)
        {
          int pickedFrame = (int) (mouseY-30-yoffset)/frameSize;
          if (pickedFrame >= 0 && pickedFrame < theFrames.size())
          { 
            displayedFrame = theFrames.get(pickedFrame).frame;

            if (mouseButton == RIGHT)
            {
              if (keyPressed && keyCode == SHIFT)
              {
                if (highlightedFrame > pickedFrame)
                {
                  for (int j = pickedFrame+1; j < highlightedFrame; j++)
                  {
                    theFrames.get(j).active = true;
                  }
                } else
                {
                  for (int j = highlightedFrame; j < pickedFrame; j++)
                  {
                    theFrames.get(j).active = true;
                  }
                }
              }
              theFrames.get(pickedFrame).toggleActive();
            }
            toggleHighlighted(pickedFrame);
            toggleHighlightedBuf(-1);
          }
        }


        //Stuff
        initMouseX = mouseX;
        initMouseY = mouseY;
        trigger = true;
        if (mouseButton == LEFT) checkdraginit = true;
      }


      offvel = mouseY - pmouseY;
      cam.setActive(false);
    } else
    {
      //Automatic repositioning for global frames:
      if (yoffset < 0 && (-yoffset/25 > (theFrames.size() - visibleFrames/2)))
      {
        offvel = 4*log(-yoffset/25-theFrames.size()+visibleFrames/2);
      }
      if (yoffset/25 > visibleFrames/2)
      {
        offvel = -log(yoffset/25);
      }
    }

    //When clicked in the buffer:
    if ( mousePressed && mouseX > 160 && mouseX < 280 && !bufferFrames.isEmpty() && !dragging)
    {

      if (!trigger)
      {
        if (!dragging)
        {
          int pickedFrame = (int) (mouseY-30-yoffsetbuf)/frameSize;
          if (pickedFrame >= 0 && pickedFrame < bufferFrames.size()) 
          {
            displayedFrame = bufferFrames.get(pickedFrame).frame;

            if (mouseButton == RIGHT)
            {
              if (keyPressed && keyCode == SHIFT)
              {
                if (highlightedFrameBuf > pickedFrame)
                {
                  for (int j = pickedFrame+1; j < highlightedFrameBuf; j++)
                  {
                    bufferFrames.get(j).toggleActive();
                  }
                } else
                {
                  for (int j = highlightedFrameBuf; j < pickedFrame; j++)
                  {
                    bufferFrames.get(j).toggleActive();
                  }
                }
              }
              bufferFrames.get(pickedFrame).toggleActive();
            }
            toggleHighlighted(-1);
            toggleHighlightedBuf(pickedFrame);
          }
        }

        initMouseX = mouseX;
        initMouseY = mouseY;
        trigger = true;
        if (mouseButton == LEFT) checkdraginitbuf = true;
      }

      offvelbuf = mouseY - pmouseY;
      cam.setActive(false);
    } else
    {
      if (yoffsetbuf < 0 && (-yoffsetbuf/25 > (bufferFrames.size() - visibleFrames/2)))
      {
        offvelbuf = 3*log(-yoffsetbuf/25-bufferFrames.size()+visibleFrames/2);
      }
      if (yoffsetbuf/25 > visibleFrames/2)
      {
        offvelbuf = -log(yoffsetbuf/25);
      }
    }

    int colour = color(64, 64, 64);

    switch(PApplet.parseInt(copyBehaviour.getValue()))
    {
    case 1 : 
      colour = color(128, 64, 64);
      break;
    case 2 : 
      colour = color(64, 128, 64);
      break;
    case 3  : 
      colour = color(64, 64, 128);
      break;
    }

    //Start dragging from main:
    if (mousePressed && mouseX>140 && checkdraginit)
    {
      if (!triggerb)
      {

        for (int i = 0; i < theFrames.size (); i++)
        {
          if (theFrames.get(i).active || highlightedFrame == i)
          {
            FrameDraggable frame = theFrames.get(i);
            frame.source = 0;
            frame.originalPosition = i;
            frame.setColour(colour);
            draggedFrames.add(frame);
          }
        }


        if ((!keyPressed) || (keyCode != CONTROL))
        {
          for (int i = theFrames.size ()-1; i >= 0; i--)
          {
            if (theFrames.get(i).active || highlightedFrame == i)
            {
              theFrames.remove(i);
              for (int j = i; j < theFrames.size (); j++)
              {
                theFrames.get(j).addInternalOffset(25);
              }
            }
          }
        }
        dragging = true;
        triggerb = true;
      }
    }

    //Start dragging from buffer:
    if (mousePressed && (mouseX>280 || mouseX < 160) && checkdraginitbuf)
    {
      if (!triggerb)
      {


        for (int i = 0; i < bufferFrames.size (); i++)
        {
          if (bufferFrames.get(i).active || highlightedFrameBuf == i)
          {
            FrameDraggable frame = bufferFrames.get(i);
            frame.source = 1;
            frame.originalPosition = i;
            frame.setColour(colour);
            draggedFrames.add(frame);
          }
        }
        if (!keyPressed || keyCode != CONTROL)
        {
          for (int i = bufferFrames.size ()-1; i>=0; i--)
          {
            if (bufferFrames.get(i).active || highlightedFrameBuf == i)
            {
              bufferFrames.remove(i);
              for (int j = i; j < bufferFrames.size (); j++)
              {
                bufferFrames.get(j).addInternalOffset(25);
              }
            }
          }
        }

        dragging = true;
        triggerb = true;
      }
    }

    //Start dragging from loaded ilda file section:
    if (mousePressed && (mouseX>width-300 && mouseX < width-215) && (mouseY > 380 && mouseY < 420) && !loadedFrames.isEmpty())
    {
      if (!triggerb)
      {
        for (int i = 0; i < loadedFrames.size (); i++)
        {
          FrameDraggable frame = loadedFrames.get(i);
          frame.source = 3;
          frame.originalPosition = i;
          frame.setColour(colour);
          draggedFrames.add(frame);
        }
        if (!keyPressed || keyCode != CONTROL)
        {
          for (int i = loadedFrames.size ()-1; i>=0; i--)
          {
            loadedFrames.remove(i);
          }
        }

        dragging = true;
        cam.setActive(false);
        triggerb = true;
      }
    }


    if (!mousePressed) {
      cam.setActive(true);
      trigger = false;
      triggerb = false;

      //Mouse released while dragging:
      if (dragging)
      {

        for (FrameDraggable frame : draggedFrames)
        {
          frame.setColour(color(64, 64, 64));
        }

        boolean dropped = false;

        //over main:
        if (mouseX > 20 && mouseX < 140 && !draggedFrames.isEmpty())
        {
          droppedOverMain();
          dropped = true;
        }


        //over buffer:
        if (mouseX > 160 && mouseX < 280 && !draggedFrames.isEmpty())
        {
          droppedOverBuffer();
          dropped = true;
        }

        //over Delete button:
        if (mouseX > cp5.getController("deleteFrame").getPosition().x && mouseX < cp5.getController("deleteFrame").getPosition().x + 85 && mouseY > cp5.getController("deleteFrame").getPosition().y && mouseY < cp5.getController("deleteFrame").getPosition().y + 85)
        {
          draggedFrames.clear();
          dropped = true;
        }

        //over SFX button:
        if (mouseX > cp5.getController("sfx").getPosition().x && mouseX < cp5.getController("sfx").getPosition().x + 85 && mouseY > cp5.getController("sfx").getPosition().y && mouseY < cp5.getController("sfx").getPosition().y + 85)
        {
          status.clear();
          status.add("This does nothing yet. Stay tuned!");
          //draggedFrames.clear();
          //dropped = true;
        }


        //somewhere else:
        if (!dropped)
        {
          int source = -1;
          if (!draggedFrames.isEmpty()) source = draggedFrames.get(0).source;
          switch (source)
          {
          case 0:
            int i = 0;
            for (FrameDraggable frame : draggedFrames)
            {
              theFrames.add(frame.originalPosition, frame);
            }
            break;
          case 1:
            i = 0;
            for (FrameDraggable frame : draggedFrames)
            {
              bufferFrames.add(frame.originalPosition, frame);
            }
            break;
          case 3:
            i = 0;
            for (FrameDraggable frame : draggedFrames)
            {
              loadedFrames.add(frame.originalPosition, frame);
            }
            break;
          default:
            draggedFrames.clear();
            break;
          }
        }


        dragging = false;
        draggedFrames.clear();
      }
      if (checkdraginit) checkdraginit = false;
      if (checkdraginitbuf) checkdraginitbuf = false;
    }

    drag();



    if (abs(offvel) < 0.25f) offvel = 0;
    yoffset += offvel;
    offvel = 0.95f*offvel;
    yoffsetbuf += offvelbuf;
    offvelbuf = 0.95f*offvelbuf;

    if (!keyPressed) checkKeyPressed = true;
    if (keyPressed && checkKeyPressed)
    { 

      checkKeyPressed = false;
      if (key == DELETE)
      {
        deleteFrame();
      }
    }

    //Display rectangles to indicate to which column (main/buffer) the clear, select all and deselect all buttons work with
    fill(50);
    stroke(127);
    strokeWeight(2);
    rect(width-300, 440, 285, 40);
    rect(width-300, 510, 285, 40);

    textAlign(RIGHT);
    fill(255);
    textFont(f16);
    text("MAIN", width-15, 438);
    text("BUFFER", width-15, 508);
  }

  public boolean shouldDisplayMain()
  {
    return ((dragging && !draggedFrames.isEmpty()) && mouseX > 20 && mouseX < 140 || !theFrames.isEmpty());
  }

  public void displayMain()
  {
    fill(127, 50);
    stroke(mainColour);
    strokeWeight(2);
    rect(20, 30, 120, visibleFrames*25-15);

    textFont(f28);
    fill(255, 50);
    text("MAIN", 25, 40, 115, visibleFrames*25-15);
  }

  public boolean shouldDisplayBuffer()
  {
    return ((dragging && !draggedFrames.isEmpty()) && mouseX > 160 && mouseX < 280 || !bufferFrames.isEmpty());
  }

  public void displayBuffer()
  {
    fill(127, 50);
    stroke(bufferColour);
    strokeWeight(2);
    rect(160, 30, 120, visibleFrames*25-15);

    textFont(f28);
    fill(255, 50);
    text("BUFFER", 165, 40, 115, visibleFrames*25-15);
  }

  public void drag()
  {
    //While dragging
    if (dragging)
    {
      //Display the dragged frames
      int i = 0;
      for (FrameDraggable frame : draggedFrames)
      {
        frame.display(mouseX-60, frameSize*(i++)+mouseY);
      }

      //When dragged over list, scroll up or down and/or indicate correct copy action
      if (mouseX > 20 && mouseX < 140)
      {
        if (mouseY < 20)
        {
          if (!(yoffset/frameSize > visibleFrames/4)) yoffset += 2*(20-mouseY);
        }
        if (mouseY > height-20)
        {
          if ( !(yoffset < -frameSize*(theFrames.size()-visibleFrames/1.5f))) yoffset -= 2*(mouseY-height+20);
        }

        //Scroll the remaining frames down when inserting:
        if (copyBehaviour.getValue() == 0)
        {
          for (int k = 0; k < theFrames.size (); k++)
          {
            if (mouseY >= frameSize*(k+0.5f)+yoffset && mouseY < frameSize*(k+1.5f)+yoffset)
            {
              for (int j = k; j < theFrames.size (); j++)
              {
                theFrames.get(j).reachValue(frameSize * draggedFrames.size());
              }
            }
          }
        }

        //Snap dragged frames to the location they might be dropped in:
        if (copyBehaviour.getValue() != 0)
        {
          int pickedFrame = PApplet.parseInt((mouseY - yoffset)/frameSize-0.5f);
          //println(pickedFrame);
          if (pickedFrame >= 0 && pickedFrame < theFrames.size())
          {
            float reachedValue = mouseY-yoffset;
            for (int k = 0; k < draggedFrames.size (); k++)
            {
              draggedFrames.get(k).reachValue(frameSize * draggedFrames.size());
            }
          }
        }
      }

      //When dragged over buffer, scroll up or down and/or indicate correct copy action
      if (mouseX > 160 && mouseX < 280)
      {
        if (mouseY < 20)
        {
          if (!(yoffsetbuf/frameSize > visibleFrames/4)) yoffsetbuf += 2*(20-mouseY);
        }
        if (mouseY > height-20)
        {
          if ( !(yoffsetbuf < -25*(bufferFrames.size()-visibleFrames/1.5f))) yoffsetbuf -= 2*(mouseY-height+20);
        }

        if (copyBehaviour.getValue() == 0)
        {
          for (int k = 0; k < bufferFrames.size (); k++)
          {
            if (mouseY >= frameSize*(k+0.5f)+yoffsetbuf && mouseY < frameSize*(k+1.5f)+yoffsetbuf)
            {
              for (int j = k; j < bufferFrames.size (); j++)
              {
                bufferFrames.get(j).reachValue(frameSize * draggedFrames.size());
              }
            }
          }
        }
      }
    }
  }

  public void droppedOverMain()
  {
    boolean wasEmpty = false;
    if (theFrames.isEmpty()) wasEmpty = true;


    //int pickedFrame = (int) (mouseY-(frameSize+5)-yoffset)/frameSize;
    int pickedFrame = PApplet.parseInt((mouseY - yoffset)/frameSize-0.5f);

    if (pickedFrame < 0)
    {


      switch ((int) copyBehaviour.getValue())
      {
      case 0:      //0: insert

        theFrames.addAll(0, draggedFrames);
        yoffset = yoffset - draggedFrames.size()*frameSize;
        break;
      case 1:      //1: overwrite
        for (int i = 0; i < draggedFrames.size (); i++)
        {
          if (i+pickedFrame < 0)
          {
            theFrames.add(i, draggedFrames.get(i));
          } else
          {
            if (i-pickedFrame < theFrames.size())
            {                   
              theFrames.set(i-pickedFrame, draggedFrames.get(i));
            } else
            {
              theFrames.add(draggedFrames.get(i));
            }
          }
        }
        break;
      case 2:    //2: merge
        for (int i = 0; i < draggedFrames.size (); i++)
        {
          if (i+pickedFrame < 0)
          {
            theFrames.add(i, draggedFrames.get(i));
          } else
          {
            if (i-pickedFrame < theFrames.size())
            {
              Frame oldFrame = theFrames.get(i-pickedFrame).frame;
              oldFrame.merge(draggedFrames.get(i).frame);
              theFrames.set(i-pickedFrame, new FrameDraggable(oldFrame));
            } else
            {
              theFrames.add(draggedFrames.get(i));
            }
          }
        }
        break;
      case 3:    //3: copy values
        for (int i = 0; i < draggedFrames.size (); i++)
        {
          if (i+pickedFrame < 0)
          {
            theFrames.add(i, draggedFrames.get(i));
          } else
          {
            if (i-pickedFrame < theFrames.size())
            {
              Frame oldFrame = theFrames.get(i-pickedFrame).frame;
              oldFrame.merge(draggedFrames.get(i).frame, copiedElements.getArrayValue());
              theFrames.set(i-pickedFrame, new FrameDraggable(oldFrame));
            } else
            {
              theFrames.add(draggedFrames.get(i));
            }
          }
        }
        break;
      }
    }

    if (pickedFrame >= 0 && pickedFrame < theFrames.size())
    {

      switch ((int) copyBehaviour.getValue())
      {
      case 0:      //0: insert
        theFrames.addAll(pickedFrame, draggedFrames);
        break;
      case 1:      //1: overwrite
        for (int i = 0; i < draggedFrames.size (); i++)
        {               
          if (i+pickedFrame < theFrames.size())
          {                   
            theFrames.set(i+pickedFrame, draggedFrames.get(i));
          } else
          {
            theFrames.add(draggedFrames.get(i));
          }
        }

        break;
      case 2:    //2: merge
        for (int i = 0; i < draggedFrames.size (); i++)
        {
          if (i+pickedFrame < theFrames.size())
          {
            Frame oldFrame = theFrames.get(i+pickedFrame).frame;
            oldFrame.merge(draggedFrames.get(i).frame);
            theFrames.set(i+pickedFrame, new FrameDraggable(oldFrame));
          } else
          {
            theFrames.add(draggedFrames.get(i));
          }
        }
        break;
      case 3:    //3: copy values
        for (int i = 0; i < draggedFrames.size (); i++)
        {

          if (i+pickedFrame < theFrames.size())
          {
            Frame oldFrame = theFrames.get(i+pickedFrame).frame;
            oldFrame.merge(draggedFrames.get(i).frame, copiedElements.getArrayValue());
            theFrames.set(i+pickedFrame, new FrameDraggable(oldFrame));
          } else
          {
            theFrames.add(draggedFrames.get(i));
          }
        }
        break;
      }
    }

    if (pickedFrame >= theFrames.size())
    {
      theFrames.addAll(theFrames.size(), draggedFrames);
    }



    if (wasEmpty) 
    {
      yoffset = mouseY-25;
      offvel = 0;
    }

    displayedFrame = draggedFrames.get(0).frame;
    draggedFrames.clear();
    highlightedFrame = max(1, min(pickedFrame, theFrames.size()));
    highlightedFrameBuf = -1;
  }

  public void droppedOverBuffer()
  {
    boolean wasEmpty = false;
    if (bufferFrames.isEmpty()) wasEmpty = true;
    int pickedFrame = PApplet.parseInt( (mouseY-yoffsetbuf)/frameSize-0.5f);

    if (pickedFrame < 0)
    {
      switch ((int) copyBehaviour.getValue())
      {
      case 0:      //0: insert
        bufferFrames.addAll(0, draggedFrames);
        yoffsetbuf = yoffsetbuf - draggedFrames.size()*frameSize;
        break;
      case 1:      //1: overwrite

        for (int i = 0; i < draggedFrames.size (); i++)
        {
          if (i+pickedFrame < 0)
          {
            bufferFrames.add(i, draggedFrames.get(i));
          } else
          {
            if (i-pickedFrame < bufferFrames.size())
            {                   
              bufferFrames.set(i-pickedFrame, draggedFrames.get(i));
            } else
            {
              bufferFrames.add(draggedFrames.get(i));
            }
          }
        }
        break;
      case 2:    //2: merge
        for (int i = 0; i < draggedFrames.size (); i++)
        {
          if (i+pickedFrame < 0)
          {
            bufferFrames.add(i, draggedFrames.get(i));
          } else
          {
            if (i-pickedFrame < bufferFrames.size())
            {
              Frame oldFrame = bufferFrames.get(i-pickedFrame).frame;
              oldFrame.merge(draggedFrames.get(i).frame);
              bufferFrames.set(i-pickedFrame, new FrameDraggable(oldFrame));
            } else
            {
              bufferFrames.add(draggedFrames.get(i));
            }
          }
        }
        break;
      case 3:    //3: copy values
        for (int i = 0; i < draggedFrames.size (); i++)
        {
          if (i+pickedFrame < 0)
          {
            bufferFrames.add(i, draggedFrames.get(i));
          } else
          {
            if (i-pickedFrame < bufferFrames.size())
            {
              Frame oldFrame = bufferFrames.get(i-pickedFrame).frame;
              oldFrame.merge(draggedFrames.get(i).frame, copiedElements.getArrayValue());
              bufferFrames.set(i-pickedFrame, new FrameDraggable(oldFrame));
            } else
            {
              bufferFrames.add(draggedFrames.get(i));
            }
          }
        }
        break;
      }
    }

    if (pickedFrame >= 0 && pickedFrame < bufferFrames.size())
    {

      switch ((int) copyBehaviour.getValue())
      {
      case 0:      //0: insert
        bufferFrames.addAll(pickedFrame, draggedFrames);
        break;
      case 1:      //1: overwrite
        for (int i = 0; i < draggedFrames.size (); i++)
        {               
          if (i+pickedFrame < bufferFrames.size())
          {                   
            bufferFrames.set(i+pickedFrame, draggedFrames.get(i));
          } else
          {
            bufferFrames.add(draggedFrames.get(i));
          }
        }

        break;
      case 2:    //2: merge
        for (int i = 0; i < draggedFrames.size (); i++)
        {
          if (i+pickedFrame < bufferFrames.size())
          {
            Frame oldFrame = bufferFrames.get(i+pickedFrame).frame;
            oldFrame.merge(draggedFrames.get(i).frame);
            bufferFrames.set(i+pickedFrame, new FrameDraggable(oldFrame));
          } else
          {
            bufferFrames.add(draggedFrames.get(i));
          }
        }
        break;
      case 3:    //3: copy values
        for (int i = 0; i < draggedFrames.size (); i++)
        {

          if (i+pickedFrame < bufferFrames.size())
          {
            Frame oldFrame = bufferFrames.get(i+pickedFrame).frame;
            oldFrame.merge(draggedFrames.get(i).frame, copiedElements.getArrayValue());
            bufferFrames.set(i+pickedFrame, new FrameDraggable(oldFrame));
          } else
          {
            bufferFrames.add(draggedFrames.get(i));
          }
        }
        break;
      }
    }

    if (pickedFrame >= bufferFrames.size())
    {
      bufferFrames.addAll(bufferFrames.size(), draggedFrames);
    }

    if (wasEmpty) 
    {
      yoffsetbuf = mouseY-25;
      offvelbuf = 0;
    }



    displayedFrame = draggedFrames.get(0).frame;
    draggedFrames.clear();
    toggleHighlighted(-1);
    toggleHighlightedBuf(-1);
  }


  public void addFrame()
  {
    int amount = PApplet.parseInt(cp5.get(Textfield.class, "nrOfInsertedFrames").getText());
    if (amount > 4096) amount = 4096;
    int colour = color(64, 64, 64);
    switch(PApplet.parseInt(copyBehaviour.getValue()))
    {
    case 1 : 
      colour = color(128, 64, 64);
      break;
    case 2 : 
      colour = color(64, 128, 64);
      break;
    case 3  : 
      colour = color(64, 64, 128);
      break;
    }
    for (int i = 0; i < amount; i++)
    {
      Frame frame = new Frame();
      frame.ildaVersion = 4;
      frame.frameName = "NewFrame";
      frame.companyName = "IldaViewer";
      frame.pointCount = 0;
      frame.frameNumber = i;
      frame.totalFrames = amount + frames.size();
      frame.scannerHead = 0;
      frame.formHeader();
      dragging = true;
      FrameDraggable aFrame = new FrameDraggable(frame);
      aFrame.source = 2;
      aFrame.colour = colour;
      draggedFrames.add(aFrame);
    }
  }

  public void deleteFrame()
  {
    if (highlightedFrame != -1)
    {
      for (int i = theFrames.size ()-1; i >= 0; i--)
      {
        if (theFrames.get(i).active || i == highlightedFrame)
        {
          theFrames.remove(i);
        }
      }
      if (highlightedFrame > 0 && highlightedFrame < theFrames.size())
      { 
        highlightedFrame--;
        displayedFrame = theFrames.get(highlightedFrame).frame;
      }
    }

    if (highlightedFrameBuf != -1)
    {
      for (int i = bufferFrames.size ()-1; i >= 0; i--)
      {
        if (bufferFrames.get(i).active || i == highlightedFrameBuf)
        {
          bufferFrames.remove(i);
        }
      }
      if (highlightedFrameBuf > 0 && highlightedFrameBuf < bufferFrames.size())
      {
        highlightedFrameBuf--;
        displayedFrame = bufferFrames.get(highlightedFrameBuf).frame;
      }
    }
  }

  public void toggleHighlighted(int i)
  {
    highlightedFrame = i;
  }

  public void toggleHighlightedBuf(int i)
  {    
    highlightedFrameBuf = i;
  }

  public void fitPalette()
  {
    if (highlightedFrame != -1)
    {
      for (int i = theFrames.size ()-1; i >= 0; i--)
      {
        if (theFrames.get(i).active || i == highlightedFrame)
        {
          Frame frame = theFrames.get(i).frame;
          for (Point point : frame.points)
          {
            point.paletteIndex = point.getBestFittingPaletteColourIndex(getActivePalette());
          }
        }
      }
    }

    if (highlightedFrameBuf != -1)
    {
      for (int i = bufferFrames.size ()-1; i >= 0; i--)
      {
        if (bufferFrames.get(i).active || i == highlightedFrameBuf)
        {
          Frame frame = bufferFrames.get(i).frame;
          frame.palette = true;
          for (Point point : frame.points)
          {
            point.paletteIndex = point.getBestFittingPaletteColourIndex(getActivePalette());
          }
        }
      }
    }
  }

  public void update3D()
  {
    if (displayedFrame != null) displayedFrame.drawFrame(showBlanking);
  }

  public void selectFrames()
  {
    for (FrameDraggable frame : theFrames)
    {
      frame.active = true;
    }
  }

  public void selectBuffer()
  {
    for (FrameDraggable frame : bufferFrames)
    {
      frame.active = true;
    }
  }

  public void deselectFrames()
  {
    for (FrameDraggable frame : theFrames)
    {
      frame.active = false;
    }
  }

  public void deselectBuffer()
  {
    for (FrameDraggable frame : bufferFrames)
    {
      frame.active = false;
    }
  }
}

class Draggable
{
  float yOffset;
  boolean active;
  float yOffVel;
  int sizeX;
  int sizeY;
  int colour;
  int originalPosition;
  int source;

  public Draggable()
  {
    sizeY = 25;
    active = false;
    colour = color(64);
  }

  public void display(float x, float y)
  {
    display(x, y, 255, false);
  }

  public void display(float x, float y, int alpha)
  {
    display(x, y, alpha, false);
  }

  public void display(float x, float y, int alpha, boolean highlighted)
  {
    int r = 255; 
    int g = 255; 
    int b = 255;

    //Highlight selected frames:
    if (active) 
    {
      r =  PApplet.parseInt(sin(PApplet.parseFloat(frameCount)/5)*127+128);
      g = 50;
      b = 50;     
      strokeWeight(5);
    } else
    {
      strokeWeight(1);
    }

    //Highlight current active frame (the one being displayed):
    if (highlighted)
    {
      b=0;
      strokeWeight(2);
    }

    //Display them boxes with text:
    stroke(r, g, b, alpha);
    fill((colour >> 16) & 0xFF, (colour >> 8) & 0xFF, colour & 0xFF, alpha);
    rect(x, y+yOffset, 120, 20);
  }

  public void toggleActive()
  {
    active = !active;
  }

  public void setInternalOffset(float offset)
  {
    yOffset = offset;
  }

  public void updateOffset()
  {
    yOffset += yOffVel;
    if (yOffVel < 0.25f) yOffVel = 0;
  }

  public void resetOffset()
  {
    if (yOffset!=0) yOffVel = -yOffset*0.25f;
  }

  public void addInternalOffset(float offset)
  {
    yOffset += offset;
  }

  public void reachValue(float offset)
  {
    if (yOffset != offset) yOffVel = (offset - yOffset)*0.25f;
  }

  public void setColour(int _colour)
  {
    int red = (_colour >> 16) & 0xFF;
    int green = (_colour >> 8) & 0xFF;
    int blue = _colour & 0xFF;
    colour = color(red, green, blue);
  }
}

class FrameDraggable extends Draggable
{
  Frame frame;
  public FrameDraggable(Frame _frame)
  {
    super();
    frame = _frame;
  }

  public void display(float x, float y)
  {
    display(x, y, 255, false);
  }

  public void display(float x, float y, int alpha, boolean highlighted)
  {
    super.display(x, y, alpha, highlighted);
    textAlign(CENTER);
    textFont(f10);
    //if (laserboyMode) fill(color(int((sin(float(i)/2+float(frameCount)/15)*0.5+0.5)*255), int((sin(float(i)+PI/2+float(frameCount)/15)*0.5+0.5)*255), int((sin(float(i)/2+3*PI/2+float(frameCount)/15)*0.5+0.5)*255)), alpha); 
    //else fill(255, alpha);
    fill(255, alpha);
    text("[" + frame.frameNumber + "]  " + frame.frameName, x+50, y+13+yOffset);
  }
}

class MainDropListener extends DropListener {

  boolean overMain = false;

  MainDropListener() {
    // set a target rect for drop event.
    int frameSize = 25;
    int visibleFrames = PApplet.parseInt((height-30)/frameSize);
    setTargetRect(20, 30, 120, visibleFrames*25-15);
  }

  public void draw() {
    if (overMain)
    {
      if (seqeditor != null) 
      {
        seqeditor.mainColour = color( PApplet.parseInt(sin(PApplet.parseFloat(frameCount)/5)*127+128), 50, 50);
        if (!seqeditor.shouldDisplayMain()) seqeditor.displayMain();
      }
    }
  }

  // if a dragged object enters the target area.
  // dropEnter is called.
  public void dropEnter() {
    overMain = true;
  }

  // if a dragged object leaves the target area.
  // dropLeave is called.
  public void dropLeave() {
    if (seqeditor != null) seqeditor.mainColour = color( 127);
    overMain = false;
  }

  public void dropEvent(DropEvent evt) {
    //Place frames in main list
    if (seqeditor != null && cp5.getWindow().getCurrentTab().getName().equals("seqeditor"))
    {
      overMain = false;

      if (evt.isFile())
      {
        File f = evt.file();
        try
        {

          if (f.isDirectory())
          {
            status.clear();
            //Load in all the files it can find.
            for (File file : f.listFiles ())
            {
              FileWrapper fl = new FileWrapper( file.getAbsolutePath(), true); 
              ArrayList<Frame> newFrames = fl.getFramesFromBytes();
              for (Frame frame : newFrames)
              {
                seqeditor.draggedFrames.add(new FrameDraggable(frame));
              }
            }
            loading = false;
          } else
          {
            FileWrapper fl = new FileWrapper( f.getAbsolutePath(), true); 
            ArrayList<Frame> newFrames = fl.getFramesFromBytes();
            for (Frame frame : newFrames)
            {
              seqeditor.draggedFrames.add(new FrameDraggable(frame));
            }
          }
        }
        catch(Exception e)
        {
          status.add("Something went wrong while dropping files. Try again or go cry.");
        }
      }
      if (seqeditor != null) seqeditor.droppedOverMain();
      status.clear();
      status.add("Frames added to main list.");
    }
  }
}


class BufferDropListener extends DropListener {

  boolean overBuffer = false;

  BufferDropListener() {
    // set a target rect for drop event.
    int frameSize = 25;
    int visibleFrames = PApplet.parseInt((height-30)/frameSize);
    setTargetRect(160, 30, 120, visibleFrames*25-15);
  }

  public void draw() {
    if (overBuffer)
    {
      if (seqeditor != null) 
      {
        seqeditor.bufferColour = color( PApplet.parseInt(sin(PApplet.parseFloat(frameCount)/5)*127+128), 50, 50);
        if (!seqeditor.shouldDisplayBuffer()) seqeditor.displayBuffer();
      }
    }
  }

  // if a dragged object enters the target area.
  // dropEnter is called.
  public void dropEnter() {
    overBuffer = true;
  }

  // if a dragged object leaves the target area.
  // dropLeave is called.
  public void dropLeave() {
    if (seqeditor != null) seqeditor.bufferColour = color( 127);
    overBuffer = false;
  }

  public void dropEvent(DropEvent evt) {

    //Add frames to the Buffer:
    if (seqeditor != null && cp5.getWindow().getCurrentTab().getName().equals("seqeditor"))
    {
      overBuffer = false;
      if (evt.isFile())
      {
        File f = evt.file();
        try
        {


          if (f.isDirectory())
          {
            status.clear();
            //Load in all the files it can find.
            for (File file : f.listFiles ())
            {
              FileWrapper fl = new FileWrapper( file.getAbsolutePath(), true); 
              ArrayList<Frame> newFrames = fl.getFramesFromBytes();
              for (Frame frame : newFrames)
              {
                seqeditor.draggedFrames.add(new FrameDraggable(frame));
              }
            }
            loading = false;
          }
          if (f.isFile())
          {
            FileWrapper fl = new FileWrapper( f.getAbsolutePath(), true); 
            ArrayList<Frame> newFrames = fl.getFramesFromBytes();
            for (Frame frame : newFrames)
            {
              seqeditor.draggedFrames.add(new FrameDraggable(frame));
            }
          }
        }

        catch(Exception e)
        {
          status.add("Something went wrong while dropping files. Try again or go cry.");
        }
      }
      if (seqeditor != null) seqeditor.droppedOverBuffer();
      status.clear();
      status.add("Frames added to buffer list.");
    }
  }
}

class SeqeditorDropListener extends DropListener {
  boolean dragging = false;
  Draggable draggable = new Draggable();

  SeqeditorDropListener() {
    // set a target rect for drop event.

    setTargetRect(0, 0, width, height);
  }

  public void draw() {
    /*
    if (dragging)
     {
     draggable.display(mouseX, mouseY);
     }
     */
  }

  // if a dragged object enters the target area.
  // dropEnter is called.
  public void dropEnter() {
    if (cp5.getWindow().getCurrentTab().getName().equals("seqeditor")) 
    {
      if (seqeditor != null) seqeditor.draggedFrames.clear();
      dragging = true;
      status.clear();
      status.add("Drop file in the main or buffer frame list.");
    }
  }

  // if a dragged object leaves the target area.
  // dropLeave is called.
  public void dropLeave() {
    dragging = false;
  }

  public void dropEvent(DropEvent theEvent) {

    //Don't do anything
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "IldaViewer" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
